#!/bin/bash
echo "Installing xf4vnc...."
echo ""
echo "This install program will install the replacement Xvnc Xserver and"
echo "the vnc.so module for use with XFree86, only if it detects the standard"
echo "/usr/X11R6 directory. If not, then you'll need to modify this script."
echo ""
echo "It will also install the modular 'vncviewer' and a sample application"
echo "'vncevent' which when used will allow the user to accept or reject"
echo "incoming connections."
echo ""
echo "All parts of the installation are prompted, so you can choose which"
echo "pieces you want to install."
echo ""
echo "NOTE: It WILL OVERWRITE EXISTING xf4vnc INSTALLATIONS!!!!"
echo ""
echo "Also, this install script will make all the required changes to your"
echo "XF86Config file and save a new one to /root/XF86Config.xf4vnc for you"
echo "to try before overwriting your old one."
echo ""
echo "This script MUST BE run as 'root'"
echo ""
echo "Hit <return> to continue or <CTRL+C> to exit...."
read
echo ""
echo "Do you want to install the vnc.so module for XFree86 ?"
read KEY
if [ "$KEY" == "y" ] || [ "$KEY" == "Y" ]; then
	echo -n "Installing vnc.so for XFree86...."
	if [ -e "/usr/X11R6/lib/modules" ]; then
		cp -f vnc.so /usr/X11R6/lib/modules/vnc.so
	else
		echo -n "Failed to install vnc.so...."
	fi
	echo "done"
	echo -n "Installing Vnc extension library...."
	if [ -e "/usr/X11R6/lib" ]; then
		cp -f libVncExt.so.2.0 /usr/X11R6/lib
		ln -sf /usr/X11R6/lib/libVncExt.so.2.0 /usr/X11R6/lib/libVncExt.so.2
		ln -sf /usr/X11R6/lib/libVncExt.so.2.0 /usr/X11R6/lib/libVncExt.so
	else
		echo -n "Failed to install Vnc extension library...."
	fi
	echo "done"
	echo -n "Installing Vnc extension headers...."
	if [ -e "/usr/X11R6/include/X11/extensions" ]; then
		cp -f vnc*.h /usr/X11R6/include/X11/extensions
	else
		echo -n "Failed to install Vnc extension headers...."
	fi
	echo "done"
	echo -n "Installing vncevent program...."
	if [ -e "/usr/X11R6/bin" ]; then
		cp -f vncevent /usr/X11R6/bin
	else
		echo -n "Failed to install vncevent...."
	fi
	echo "done"
	./xf4vnc
fi
echo ""
echo "Do you want to install 'Xvnc' ?"
read KEY
if [ "$KEY" == "y" ] || [ "$KEY" == "Y" ]; then
	echo -n "Installing Xvnc...."
	if [ -e "/usr/X11R6/bin" ]; then
		cp -f Xvnc /usr/X11R6/bin
	else
		echo -n "Failed to install Xvnc...."
	fi
	echo "done"
fi
echo ""
echo "Do you want to install xf4vnc's unique modular vncviewer ?"
read KEY
if [ "$KEY" == "y" ] || [ "$KEY" == "Y" ]; then
	echo -n "Installing xf4vnc's unique vncviewer...."
	if [ -e "/usr/X11R6/bin" ]; then
		cp -f vncviewer /usr/X11R6/bin
		# Has to be copied to a valid library search path. Easiest is..
		cp -f *.so /usr/lib
	else
		echo -n "Failed to install vncviewer...."
	fi
	echo "done"
fi
echo ""
echo "Installation Complete."
echo ""
