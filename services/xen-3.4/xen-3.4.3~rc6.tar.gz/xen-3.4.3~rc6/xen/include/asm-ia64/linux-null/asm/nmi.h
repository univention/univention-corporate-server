#ifndef __IA64_NMI_H__
#define __IA64_NMI_H__

#define register_guest_nmi_callback(a)  (-ENOSYS)
#define unregister_guest_nmi_callback() (-ENOSYS)

#endif /* __IA64_NMI_H__ */
