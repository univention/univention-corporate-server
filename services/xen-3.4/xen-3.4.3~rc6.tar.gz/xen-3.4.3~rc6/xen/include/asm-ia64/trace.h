#ifndef __ASM_TRACE_H__
#define __ASM_TRACE_H__

#endif /* __ASM_TRACE_H__ */
