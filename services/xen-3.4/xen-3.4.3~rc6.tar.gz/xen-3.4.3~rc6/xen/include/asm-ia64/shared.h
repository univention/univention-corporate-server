#ifndef __XEN_ASM_SHARED_H__
#define __XEN_ASM_SHARED_H__

#endif /* __XEN_ASM_SHARED_H__ */
