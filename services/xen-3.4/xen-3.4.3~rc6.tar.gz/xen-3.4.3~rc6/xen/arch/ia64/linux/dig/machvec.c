#define MACHVEC_PLATFORM_NAME		dig
#define MACHVEC_PLATFORM_HEADER		<asm/machvec_dig.h>
#include <asm/machvec_init.h>
