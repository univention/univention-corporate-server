This directory holds installers (mostly service packs) specific to
Windows XP.  You need to download them from Microsoft, and possibly
modify install/scripts/winxp-updates.bat to invoke them.
