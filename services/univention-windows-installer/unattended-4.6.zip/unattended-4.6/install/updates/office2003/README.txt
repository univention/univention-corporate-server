This directory holds installers (mostly service packs) specific to
Microsoft Office 2003.  You need to download them from Microsoft,
and possibly modify install/scripts/ofc2003.bat to invoke them.
