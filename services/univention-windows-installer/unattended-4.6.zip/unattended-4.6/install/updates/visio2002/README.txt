This directory holds installers (mostly service packs) specific to
Microsoft Visio 2002.  You need to download them from Microsoft,
and possibly modify install/scripts/visio2002.bat to invoke them.
