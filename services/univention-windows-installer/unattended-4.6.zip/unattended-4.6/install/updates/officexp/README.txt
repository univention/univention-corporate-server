This directory holds installers (mostly service packs) specific to
Microsoft Office XP.  You need to download them from Microsoft,
and possibly modify install/scripts/officexp.bat to invoke them.
