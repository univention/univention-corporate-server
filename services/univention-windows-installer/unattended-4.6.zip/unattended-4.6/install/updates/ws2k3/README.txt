This directory holds installers (mostly service packs) specific to
Windows Server 2003.  You need to download them from Microsoft, and possibly
modify install/scripts/ws2k3-updates.bat to invoke them.
