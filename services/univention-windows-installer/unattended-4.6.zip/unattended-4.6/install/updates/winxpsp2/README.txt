This directory holds installers (mostly hotfixes and other updates)
specific to Windows XP Service Pack 2.
