This directory holds patches (mostly hotfixes and other updates)
that are not specific to any operation system (they apply to all).
You need to download them from Microsoft, and possibly modify the
scripts in install/scripts/ to invoke them.
