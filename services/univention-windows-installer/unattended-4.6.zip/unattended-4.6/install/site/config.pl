# File to hold site-specific customizations.

# Enable maximum warnings and disallow sloppy constructs.
use warnings;
use strict;

#
# PUT YOUR CHANGES HERE
#

# Make this file evaluate to "true".
1;
