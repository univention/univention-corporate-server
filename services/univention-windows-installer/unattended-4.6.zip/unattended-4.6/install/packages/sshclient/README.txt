This directory holds the install files for SSH Secure Shell for Workstations.
You need to download it from ftp.ssh.com. You might also
need to modify the .iss file to install it.