This directory holds a copy of the Microsoft Visio Professional 2002
installation media.  Just copy the entire CD to this directory.
