This directory holds the installer for Microsoft DirectX v9.0b
You need to populate it with installer, and possibly modify the
contents of the scripts/ directory to invoke it.
