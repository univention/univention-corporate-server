This directory holds a copy of the Microsoft Office XP
installation media.  Just copy the entire CD to this directory.
