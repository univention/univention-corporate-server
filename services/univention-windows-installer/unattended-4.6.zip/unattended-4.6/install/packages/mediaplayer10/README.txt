This directory holds the installer for Windows Media Player 10.  You
need to download it from Microsoft
(http://www.microsoft.com/windowsmedia/) or let the "prepare" script
download it for you.
