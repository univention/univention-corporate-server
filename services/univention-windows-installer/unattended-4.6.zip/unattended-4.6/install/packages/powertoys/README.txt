This directory holds a copy of Microsofts Power Toys installs.
Just download all power toys that you want to install and
modify /install/scripts/powertoys.bat to install the ones you
want.
