This directory holds the install files for Media Player v9.
You need to download it from Microsoft. You might also
need to modify the script in install/scripts/ to install it.
