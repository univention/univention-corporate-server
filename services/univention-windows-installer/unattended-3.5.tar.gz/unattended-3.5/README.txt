Welcome to the distribution for <http://unattended.sourceforge.net/>.
You will find complete documentation there, or in the html/ directory
here (which is just a copy of the Web site).

This top-level directory contains:

  README.txt  - This file

  LICENSE.txt - The license for this stuff

  NEWS.txt    - A history of release notes, more or less

  Makefile    - A Makefile for my use, not yours; sorry

  bootdisk/   - Directory holding the boot disk sources and Makefile

  install/    - Directory holding the initial \\ntinstall\install
                share, aka. Z:\ drive; see the documentation

  html/       - A copy of the Web pages as previously mentioned
