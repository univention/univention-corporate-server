This directory will hold the completed floppy disk images.
