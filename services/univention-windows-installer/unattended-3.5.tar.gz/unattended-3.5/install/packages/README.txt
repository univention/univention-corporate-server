This directory holds the installers for the applications.
You need to populate it with installers, and possibly modify the
contents of the scripts/ directory to invoke them.
