This directory holds a copy of the Microsoft Office 2000
installation media.  Just copy the entire CD to this directory.
