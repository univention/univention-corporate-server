This directory holds the install files for Internet Explorer
v6 Service Pack 1.  You need to download it from Microsoft
and then run:

ie6setup.exe /c:"ie6wzd.exe /d /s:""#E"

You might also need to modify the script in install/scripts/
to install it.
