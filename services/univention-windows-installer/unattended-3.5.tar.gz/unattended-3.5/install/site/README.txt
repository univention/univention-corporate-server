This directory holds site-specific configuration information, like
license keys, passwords, and custom registry patches.  You will need
to populate before some of the stuff in Z:\scripts will work.
