This folder is where you put copies of your OS media.

You should create subfolders here with names like "winxp", or
"win2ksp4".  (Actually, you can name them whatever you like;
Unattended will figure out what they are from their contents.)

For more information, please see the documentation.
