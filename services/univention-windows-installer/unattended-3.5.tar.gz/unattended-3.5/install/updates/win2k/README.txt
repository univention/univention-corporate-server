This directory holds installers (mostly service packs) specific to
Windows 2000.  You need to download them from Microsoft, and possibly
modify install/scripts/win2k-updates.bat to invoke them.
