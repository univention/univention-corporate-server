This directory holds the updates and hotfixes.
You need to populate it with installers, and possibly modify the
contents of the scripts/ directory to invoke them.
