This directory holds patches (mostly hotfixes and other updates)
specific to Internet Explorer v6 Service Pack 1.  You need to 
download them from Microsoft, and possibly modify the scripts 
in install/scripts/ to invoke them.
