This directory holds patches (mostly hotfixes and other updates)
specific to Media Player v9.  You need to download them from
Microsoft, and possibly modify the scripts in install/scripts/
to invoke them.
