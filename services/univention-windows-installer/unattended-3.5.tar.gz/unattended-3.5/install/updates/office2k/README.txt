This directory holds installers (mostly service packs) specific to
Microsoft Office 2000.  You need to download them from Microsoft,
and possibly modify install/scripts/office2k.bat to invoke them.
