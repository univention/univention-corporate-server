/**
 * Javascript code for finding all tables with classname "striped" and
 * dynamically striping their row colors.
 *
 * $Horde: ingo/js/src/stripe.js,v 1.1 2007/02/13 00:16:50 slusarz Exp $
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */

/* We do everything onload so that the entire document is present
 * before we start searching it for tables. */
Event.observe(window, 'load', table_init);

function table_init()
{
    $A(document.getElementsByTagName('TABLE')).each(function(e) {
        if (Element.hasClassName(e, 'striped')) {
            table_stripe(e);
        }
    });
}

function table_stripe(table)
{
    var classes = ['rowEven', 'rowOdd'];

    // Tables can have more than one tbody element; get all child
    // tbody tags and interate through them.
    $A(table.childNodes).each(function(t) {
        if (t.tagName == 'TBODY') {
            $A(t.childNodes).each(function(c) {
                if (c.tagName == 'TR') {
                    Element.removeClassName(c, classes[1]);
                    Element.addClassName(c, classes[0]);
                    classes.reverse(true);
                }
            });
        }
    });
}
