<?php
/**
 * Ingo_Driver_null:: Implements a null api -- useful for just testing
 * the UI and storage.
 *
 * $Horde: ingo/lib/Driver/null.php,v 1.15 2006/08/14 02:44:46 slusarz Exp $
 *
 * See the enclosed file LICENSE for license information (ASL).  If you
 * did not receive this file, see http://www.horde.org/licenses/asl.php.
 *
 * @author  Brent J. Nordquist <bjn@horde.org>
 * @package Ingo
 */

class Ingo_Driver_null extends Ingo_Driver {

    /**
     * Whether this driver allows managing other users' rules.
     *
     * @var boolean
     */
    var $_support_shares = true;

}
