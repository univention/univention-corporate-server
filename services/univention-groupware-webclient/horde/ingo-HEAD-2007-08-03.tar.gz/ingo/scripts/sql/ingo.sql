-- $Horde: ingo/scripts/sql/ingo.sql,v 1.6 2007/04/25 17:54:17 jan Exp $

CREATE TABLE ingo_rules (
  rule_id INT NOT NULL,
  rule_owner VARCHAR(255) NOT NULL,
  rule_name VARCHAR(255) NOT NULL,
  rule_action INT NOT NULL,
  rule_value VARCHAR(255),
  rule_flags INT,
  rule_conditions TEXT,
  rule_combine INT,
  rule_stop INT,
  rule_active INT DEFAULT 1 NOT NULL,
  rule_order INT DEFAULT 0 NOT NULL,
-- 
  PRIMARY KEY (rule_id)
);

CREATE INDEX rule_owner_idx ON ingo_rules (rule_owner);


CREATE TABLE ingo_lists (
  list_owner VARCHAR(255) NOT NULL,
  list_blacklist INT DEFAULT 0,
  list_address VARCHAR(255) NOT NULL
);

CREATE INDEX list_idx ON ingo_lists (list_owner, list_blacklist);


CREATE TABLE ingo_forwards (
  forward_owner VARCHAR(255) NOT NULL,
  forward_addresses TEXT,
  forward_keep INT DEFAULT 0 NOT NULL,
-- 
  PRIMARY KEY (forward_owner)
);


CREATE TABLE ingo_vacations (
  vacation_owner VARCHAR(255) NOT NULL,
  vacation_addresses TEXT,
  vacation_subject VARCHAR(255),
  vacation_reason TEXT,
  vacation_days INT DEFAULT 7,
  vacation_start INT,
  vacation_end INT,
  vacation_excludes TEXT,
  vacation_ignorelists INT DEFAULT 1,
-- 
  PRIMARY KEY (vacation_owner)
);


CREATE TABLE ingo_spam (
  spam_owner VARCHAR(255) NOT NULL,
  spam_level INT DEFAULT 5,
  spam_folder VARCHAR(255),
-- 
  PRIMARY KEY (spam_owner)
);
