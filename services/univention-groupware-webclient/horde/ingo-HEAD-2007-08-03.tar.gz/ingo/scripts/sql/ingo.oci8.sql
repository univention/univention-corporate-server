-- $Horde: ingo/scripts/sql/ingo.oci8.sql,v 1.3 2007/04/25 17:54:17 jan Exp $

CREATE TABLE ingo_rules (
  rule_id INT NOT NULL,
  rule_owner VARCHAR2(255) NOT NULL,
  rule_name VARCHAR2(255) NOT NULL,
  rule_action INT NOT NULL,
  rule_value VARCHAR2(255),
  rule_flags INT,
  rule_conditions CLOB,
  rule_combine INT,
  rule_stop INT,
  rule_active INT DEFAULT 1 NOT NULL,
  rule_order INT DEFAULT 0 NOT NULL,
-- 
  PRIMARY KEY (rule_id)
);

CREATE INDEX rule_owner_idx ON ingo_rules (rule_owner);


CREATE TABLE ingo_lists (
  list_owner VARCHAR2(255) NOT NULL,
  list_blacklist INT DEFAULT 0,
  list_address VARCHAR2(255) NOT NULL
);

CREATE INDEX list_idx ON ingo_lists (list_owner, list_blacklist);


CREATE TABLE ingo_forwards (
  forward_owner VARCHAR2(255) NOT NULL,
  forward_addresses CLOB,
  forward_keep INT DEFAULT 0 NOT NULL,
-- 
  PRIMARY KEY (forward_owner)
);


CREATE TABLE ingo_vacations (
  vacation_owner VARCHAR2(255) NOT NULL,
  vacation_addresses CLOB,
  vacation_subject VARCHAR2(255),
  vacation_reason CLOB,
  vacation_days INT DEFAULT 7,
  vacation_start INT,
  vacation_end INT,
  vacation_excludes CLOB,
  vacation_ignorelists INT DEFAULT 1,
-- 
  PRIMARY KEY (vacation_owner)
);


CREATE TABLE ingo_spam (
  spam_owner VARCHAR2(255) NOT NULL,
  spam_level INT DEFAULT 5,
  spam_folder VARCHAR2(255),
-- 
  PRIMARY KEY (spam_owner)
);
