ALTER TABLE ingo_vacations ADD vacation_start INT;
ALTER TABLE ingo_vacations ADD vacation_end INT;
