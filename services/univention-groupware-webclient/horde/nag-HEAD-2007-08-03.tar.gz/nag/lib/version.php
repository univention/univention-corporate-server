<?php define('NAG_VERSION', 'H3 (2.2-cvs)') ?>
