<?php

$block_name = _("Menu List");
$block_type = 'tree';

/**
 * $Horde: nag/lib/Block/tree_menu.php,v 1.1 2006/05/24 04:02:20 chuck Exp $
 *
 * @package Horde_Block
 */
class Horde_Block_nag_tree_menu extends Horde_Block {

    var $_app = 'nag';

    function _buildTree(&$tree, $indent = 0, $parent = null)
    {
        global $registry;

        $tree->addNode($parent . '__new',
                       $parent,
                       _("New Task"),
                       $indent + 1,
                       false,
                       array('icon' => 'add.png',
                             'icondir' => $registry->getImageDir(),
                             'url' => Horde::applicationUrl('task.php?actionID=add_task')));

        $tree->addNode($parent . '__search',
                       $parent,
                       _("Search"),
                       $indent + 1,
                       false,
                       array('icon' => 'search.png',
                             'icondir' => $registry->getImageDir('horde'),
                             'url' => Horde::applicationUrl('search.php')));
    }

}
