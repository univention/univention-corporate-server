<?php
/**
 * $Horde: nag/lib/prefs.php,v 1.9 2007/08/01 04:11:06 chuck Exp $
 *
 * Copyright 2001-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

function handle_tasklistselect($updated)
{
    $default_tasklist = Util::getFormData('default_tasklist');
    if (!is_null($default_tasklist)) {
        $tasklists = Nag::listTasklists();
        if (is_array($tasklists) && isset($tasklists[$default_tasklist])) {
            $GLOBALS['prefs']->setValue('default_tasklist', $default_tasklist);
            return true;
        }
    }

    return false;
}

function handle_showsummaryselect($updated)
{
    $GLOBAL['prefs']->setValue('summary_categories', Util::getFormData('summary_categories'));
    return true;
}

function handle_defaultduetimeselect($updated)
{
    $GLOBALS['prefs']->setValue('default_due_time', Util::getFormData('default_due_time'));
    return true;
}
