-- $Horde: nag/scripts/upgrades/2006-10-29_add_completed_date.sql,v 1.1 2006/10/31 18:08:23 chuck Exp $
--
-- You can simply execute this file in your database.

ALTER TABLE nag_tasks ADD task_completed_date INT;
