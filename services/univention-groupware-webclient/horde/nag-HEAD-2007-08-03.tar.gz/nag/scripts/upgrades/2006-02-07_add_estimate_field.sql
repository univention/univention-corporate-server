-- $Horde: nag/scripts/upgrades/2006-02-07_add_estimate_field.sql,v 1.2 2006/04/18 11:58:09 jan Exp $
--
-- You can simply execute this file in your database.

ALTER TABLE nag_tasks ADD task_estimate FLOAT;
