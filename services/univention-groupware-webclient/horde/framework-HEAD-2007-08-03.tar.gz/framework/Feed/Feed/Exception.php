<?php
/**
 * @category Horde
 * @package Horde_Feed
 */

/**
 * @category Horde
 * @package Horde_Feed
 */
class Horde_Feed_Exception extends Exception {}
