<?php
/**
 * @category Horde
 * @package Horde_Feed
 *
 * Portions Copyright 2005-2007 Zend Technologies USA Inc. (http://www.zend.com)
 * Copyright 2007 The Horde Project (http://www.horde.org/)
 */

/**
 * Concrete class for working with RSS items.
 *
 * @category Horde
 * @package Horde_Feed
 */
class Horde_Feed_Entry_Rss extends Horde_Feed_Entry_Abstract {

    /**
     * The XML string for an "empty" RSS entry.
     *
     * @var string
     */
    protected $_emptyXml = '<item/>';

}
