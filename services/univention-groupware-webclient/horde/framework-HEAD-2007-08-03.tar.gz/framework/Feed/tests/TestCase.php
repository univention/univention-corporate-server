<?php
/**
 * @category Horde
 * @package Horde_Feed
 * @subpackage UnitTests
 */

/** Horde_Loader */
require_once 'Horde/Loader.php';

/** Horde_Feed */
require_once dirname(dirname(__FILE__)) . '/Feed.php';
require_once dirname(dirname(__FILE__)) . '/Feed/Abstract.php';
require_once dirname(dirname(__FILE__)) . '/Feed/Atom.php';
require_once dirname(dirname(__FILE__)) . '/Feed/Exception.php';
require_once dirname(dirname(__FILE__)) . '/Feed/Rss.php';
require_once dirname(dirname(__FILE__)) . '/Feed/Entry/Abstract.php';
require_once dirname(dirname(__FILE__)) . '/Feed/Entry/Atom.php';
require_once dirname(dirname(__FILE__)) . '/Feed/Entry/Rss.php';
