<?php
/**
 * @category Horde
 * @package Horde_Feed
 * @subpackage UnitTests
 */

/** Horde_Feed_TestCase */
require_once dirname(__FILE__) . '/TestCase.php';

class Horde_Feed_ReadTest extends PHPUnit_Framework_TestCase
{

    protected $_feedDir;

    public function setUp()
    {
        $this->_feedDir = dirname(__FILE__) . '/_data';
    }

    public function testAtomGoogle()
    {
        $this->_readAtomValid('AtomTestGoogle.xml');
    }

    public function testAtomMozillazine()
    {
        $this->_readAtomValid('AtomTestMozillazine.xml');
    }

    public function testAtomOReilly()
    {
        $this->_readAtomValid('AtomTestOReilly.xml');
    }

    public function testAtomPlanetPHP()
    {
        $this->_readAtomValid('AtomTestPlanetPHP.xml');
    }

    public function testAtomSample1()
    {
        $this->_readAtomValid('AtomTestSample1.xml');
    }

    public function testAtomSample2()
    {
        $this->_readAtomValid('AtomTestSample2.xml');
    }

    public function testAtomSample3()
    {
        $this->_readInvalid('AtomTestSample3.xml');
    }

    public function testAtomSample4()
    {
        $this->_readAtomValid('AtomTestSample4.xml');
    }

    public function testRssHarvardLaw()
    {
        $this->_readRssValid('RssTestHarvardLaw.xml');
    }

    public function testRssPlanetPHP()
    {
        $this->_readRssValid('RssTestPlanetPHP.xml');
    }

    public function testRssSlashdot()
    {
        $this->_readRssValid('RssTestSlashdot.xml');
    }

    public function testRssCNN()
    {
        $this->_readRssValid('RssTestCNN.xml');
    }

    public function testRss091Sample1()
    {
        $this->_readRssValid('RssTest091Sample1.xml');
    }

    public function testRss092Sample1()
    {
        $this->_readRssValid('RssTest092Sample1.xml');
    }

    public function testRss100Sample1()
    {
        $this->_readRssValid('RssTest100Sample1.xml');
    }

    public function testRss100Sample2()
    {
        $this->_readRssValid('RssTest100Sample2.xml');
    }

    public function testRss200Sample1()
    {
        $this->_readRssValid('RssTest200Sample1.xml');
    }

    protected function _readAtomValid($filename)
    {
        $feed = Horde_Feed::readFile($this->_feedDir . DIRECTORY_SEPARATOR . $filename);
        $this->assertTrue($feed instanceof Horde_Feed_Atom);
    }

    protected function _readRssValid($filename)
    {
        $feed = Horde_Feed::readFile($this->_feedDir . DIRECTORY_SEPARATOR . $filename);
        $this->assertTrue($feed instanceof Horde_Feed_Rss);
    }

    protected function _readInvalid($filename)
    {
        try {
            $feed = Horde_Feed::readFile($this->_feedDir . DIRECTORY_SEPARATOR . $filename);
        } catch (Exception $e) {
        }

        $this->assertTrue($e instanceof Horde_Feed_Exception, 'Expected Horde_Feed_Exception to be thrown');
    }

}
