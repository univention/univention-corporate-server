#!@php_bin@
<?php

if (empty($_SERVER['argv'][1])) {
    $self = $_SERVER['argv'][0];
    echo "Usage: $self <feed url>\n\nExample:\n  $self http://graphics8.nytimes.com/services/xml/rss/nyt/HomePage.xml\n";
    exit(1);
}

/* Get a Horde framework include_path set up. */
require 'Horde/Loader.php';

$feed = Horde_Feed::readUri($_SERVER['argv'][1]);
echo count($feed) . " entries:\n\n";
foreach ($feed as $i => $entry) {
    echo ($i + 1) . '. ' . $entry->title() . "\n";
}

exit(0);
