<?php
/**
 * The SpellChecker_pspell:: class provides a driver for the 'pspell' PHP
 * extension.
 *
 * $Horde: framework/SpellChecker/SpellChecker/pspell.php,v 1.11 2007/07/06 17:48:36 chuck Exp $
 *
 * Copyright 2005-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Chuck Hagenbuch <chuck@horde.org>
 * @package SpellChecker
 */
class SpellChecker_pspell extends SpellChecker {

    /**
     * @var resource
     */
    var $_pspell;

    /**
     * @var boolean
     */
    var $_open = false;

    /**
     * @param string
     */
    function spellCheck($text)
    {
        if ($this->_html) {
            $text = strip_tags(trim($text));
            $text = @html_entity_decode($text, ENT_QUOTES, $this->_output_encoding);
        }

        $words = $this->_getWords($text);
        if (!count($words)) {
            return array('bad' => array(), 'suggestions' => array());
        }

        if (is_a(($result = $this->_open()), 'PEAR_Error')) {
            return $result;
        }

        $bad = array();
        $suggestions = array();
        foreach ($words as $word) {
            if (!pspell_check($this->_pspell, $word) &&
                !$this->_inLocalDictionary($word)) {
                $bad[] = $word;
                $suggestions[] = array_slice(pspell_suggest($this->_pspell, $word), 0, $this->_maxSuggestions);
            }
        }

        return array('bad' => $bad, 'suggestions' => $suggestions);
    }

    /**
     *
     */
    function _open()
    {
        if ($this->_pspell) {
            return true;
        }

        $config = pspell_config_create($this->_locale);

        switch ($this->_suggestMode) {
        case SPELLCHECKER_SUGGEST_FAST:
            pspell_config_mode($config, PSPELL_FAST);
            break;

        case SPELLCHECKER_SUGGEST_NORMAL:
            pspell_config_mode($config, PSPELL_NORMAL);
            break;

        case SPELLCHECKER_SUGGEST_SLOW:
            pspell_config_mode($config, PSPELL_BAD_SPELLERS);
            break;
        }

        $te = ini_set('track_errors', true);
        $this->_pspell = @pspell_new_config($config);
        ini_set('track_errors', $te);
        if (!$this->_pspell) {
            require_once 'PEAR.php';
            return PEAR::raiseError($php_errormsg);
        }

        return true;
    }

}
