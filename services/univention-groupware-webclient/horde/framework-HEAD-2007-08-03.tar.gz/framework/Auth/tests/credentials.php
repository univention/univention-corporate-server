<?php
/**
 * @package Horde_Auth
 */

$encryptions = array('plain',
                     'msad',
                     'sha',
                     'crypt',
                     'crypt-des',
                     'crypt-md5',
                     'crypt-blowfish',
                     'md5-base54',
                     'ssha',
                     'smd5',
                     'aprmd5',
                     'md5-hex');

$passwords = array('foobar',
                   '" f o o b a r " ',
                   'iEPX+SQWIR3p67lj/0zigSWTKHg=',
                   '8e3IWstJmsmxs',
                   '45MibW6/G3XEY',
                   '$1$537a3a0e$CWyLVJdQKfxbKPBv/Efzm0',
                   '*0OayF9ttbxIs',
                   '3858f62230ac3c915f300c664312c63f',
                   'BtvNhphkPvT/kkgbIrdodDPowMRnQ2ZnMUxNLy9uOXFqSVBTSktxTw==',
                   'MyBOmmPSkSnuWjDEGDEfBTYxS0hDQ0s4Ry93TWxHaz0=',
                   '$apr1$11CBbKXP$AvvMGBjr81bC/NSMZIxrG.',
                   '3858f62230ac3c915f300c664312c63f');

$salts = array('',
               '',
               '',
               '8e',
               '45',
               '$1$537a3a0e$',
               '*0OayF9ttbxIs',
               '',
               'Ly9uOXFqSVBTSktxTw==',
               'Q0s4Ry93TWxHaz0=',
               '11CBbKXP',
               '');
