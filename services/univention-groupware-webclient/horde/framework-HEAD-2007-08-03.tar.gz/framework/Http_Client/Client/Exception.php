<?php
/**
 * @package Horde_Http_Client
 */
class Horde_Http_Client_Exception extends Exception {
}
