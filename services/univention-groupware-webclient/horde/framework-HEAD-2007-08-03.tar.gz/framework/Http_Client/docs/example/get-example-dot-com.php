<?php
/**
 * Basic example for fetching a page with Horde_Http_Client
 *
 * @package Horde_Http
 */

require dirname(dirname(dirname(__FILE__))) . '/Http.php';

$client = new Horde_Http_Client();
$response = $client->GET('http://www.example.com/');
var_dump($response);
echo $response->getBody();
