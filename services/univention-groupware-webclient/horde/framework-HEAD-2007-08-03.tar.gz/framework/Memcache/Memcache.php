<?php
/**
 * The max storage size of the memcache server.  This should be slightly
 * smaller than the actual value due to overhead.  By default, the max slab
 * size of memcache (as of 2.1.2) is 1 MB.
 */
define('MEMCACHE_MAX_SIZE', 1000000);

/**
 * The Horde_memcache:: class provides easy access for Horde code to a
 * centrally configured memcache installation.
 *
 * memcached website: http://www.danga.com/memcached/
 *
 * $Horde: framework/Memcache/Memcache.php,v 1.8 2007/08/01 04:53:23 slusarz Exp $
 *
 * Configuration parameters (set in $conf['memcache']):<pre>
 *   'compression' - Compress data inside memcache?
 *                   DEFAULT: false
 *   'c_threshold' - The minimum value length before attempting to compress.
 *                   DEFAULT: none
 *   'hostspec'    - The memcached host(s) to connect to.
 *                   DEFAULT: 'localhost'
 *   'persistent'  - Use persistent DB connections?
 *                   DEFAULT: false
 *   'prefix'      - The prefix to use for the memcache keys.
 *                   DEFAULT: $_SERVER['SERVER_NAME'] or $_SERVER['HOSTNAME']
 *   'port'        - The port(s) memcache is listening on.
 *                   DEFAULT: 11211
 *   'weight'      - The weight to use for each memcached host.
 *                   DEFAULT: none (equal weight to all servers)
 * </pre>
 *
 * Copyright 2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @category Horde
 * @author  Michael Slusarz <slusarz@curecanti.org>
 * @author  Didi Rieder <adrieder@sbox.tugraz.at>
 * @since   Horde 3.2
 * @package Horde_Memcache
 */
class Horde_Memcache {

    /**
     * Memcache object.
     *
     * @var Memcache
     */
    var $_memcache;

    /**
     * Memcache defaults.
     *
     * @var array
     */
    var $_params = array(
        'compression' => 0,
        'hostspec' => 'localhost',
        'persistent' => false,
        'port' => 11211,
    );

    /**
     * Active server list.
     *
     * @var array
     */
    var $_servers = array();

    /**
     * Active locks.
     *
     * @var array
     */
    var $_locks = array();

    /**
     * Singleton.
     */
    function &singleton()
    {
        static $instance;

        if (!isset($instance)) {
            $instance = new Horde_Memcache();
        }

        return $instance;
    }

    /**
     * Constructor.
     */
    function Horde_Memcache()
    {
        $this->_params = array_merge($this->_params, $GLOBALS['conf']['memcache']);
        if (empty($this->_params['prefix'])) {
            $this->_params['prefix'] = ($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : $_SERVER['HOSTNAME'];
        }

        $this->_memcache = new Memcache;
        for ($i = 0, $n = count($this->_params['hostspec']); $i < $n; ++$i) {
            if ($this->_memcache->addServer($this->_params['hostspec'][$i], $this->_params['port'][$i], !empty($this->_params['persistent']), !empty($this->_params['weight'][$i]) ? $this->_params['weight'][$i] : 1)) {
                $this->_servers[] = $this->_params['hostspec'][$i] . ':' . $this->_params['port'][$i];
            }
        }

        if (!empty($this->_params['c_threshold'])) {
            $this->_memcache->setCompressThreshold($this->_params['c_threshold']);
        }

        /* Check if any of the connections worked. */
        if (empty($this->_servers)) {
            Horde::logMessage('Could not connect to any defined memcache servers.' , __FILE__, __LINE__, PEAR_LOG_ERR);
        } else {
            Horde::logMessage('Connected to the following memcache servers for memcache SessionHandler:' . implode($this->_servers, ', '), __FILE__, __LINE__, PEAR_LOG_DEBUG);
        }
    }

    /**
     * Delete a key.
     *
     * @see Memcache::delete()
     *
     * @param string $key       The key.
     * @param integer $timeout  Expiration time in seconds.
     *
     * @return boolean  True on success.
     */
    function delete($key, $timeout = 0)
    {
        $os = $this->get('horde_memcache_os');
        if ($os && isset($os[$key])) {
            $res = true;
            for ($i = 0; $i <= $os[$key]; ++$i) {
                if (!$this->_memcache->delete($this->_params['prefix'] . (($i) ? ($key . '_s' . $i) : $key))) {
                    $res = false;
                }
            }
            unset($os[$key]);
            $this->_memcache->set($this->_params['prefix'] . 'horde_memcache_os', $os, 0, 0);
            return $res;
        }

        return $this->_memcache->delete($this->_params['prefix'] . $key, $timeout);
    }

    /**
     * Get data associated with a key.
     *
     * @see Memcache::get()
     *
     * @param string $key  The key.
     *
     * @return mixed  The string on success, false on failure.
     */
    function get($key)
    {
        $os = $this->_memcache->get($this->_params['prefix'] . 'horde_memcache_os');
        if ($key == 'horde_memcache_os') {
            return $os;
        }

        $data = '';

        for ($i = 0, $end = (($os && isset($os[$key])) ? $os[$key] : 0); $i <= $end; ++$i) {
            $res =  $this->_memcache->get($this->_params['prefix'] . (($i) ? ($key . '_s' . $i) : $key));
            if (!$res)  {
                return $res;
            }
            $data .= $res;
        }

        $old_error = error_reporting(0);
        $data = unserialize($data);
        error_reporting($old_error);
        return $data;
    }

    /**
     * Set the value of a key.
     *
     * @see Memcache::set()
     *
     * @param string $key       The key.
     * @param string $var       The data to store.
     * @param integer $timeout  Expiration time in seconds.
     *
     * @return boolean  True on success.
     */
    function set($key, $var, $expire = 0)
    {
        $old_error = error_reporting(0);
        $var = serialize($var);
        error_reporting($old_error);
        $len = strlen($var);

        for ($i = 0; ($i * MEMCACHE_MAX_SIZE) < $len; ++$i) {
            $res = $this->_memcache->set($this->_params['prefix'] . (($i) ? ($key . '_s' . $i) : $key), substr($var, $i * MEMCACHE_MAX_SIZE, MEMCACHE_MAX_SIZE), empty($this->_params['compression']) ? 0 : MEMCACHE_COMPRESSED, $expire);
            if (!$res) {
                $this->delete($key);
                for ($j = 1; $j < $i; ++$j) {
                    $this->delete($key . '_s' . $j);
                }
                $i = 0;
                break;
            }
        }

        $os = $this->get('horde_memcache_os');
        if ($os && isset($os[$key])) {
            if ($os[$key] != $i) {
                if ($os[$key] > $i) {
                    for ($j = $i; $j <= $os[$key]; ++$j) {
                        $this->delete($key . '_s' . $j);
                    }
                }
                if ($i) {
                    $os[$key] = $i;
                } else {
                    unset($os[$key]);
                }
                $this->_memcache->set($this->_params['prefix'] . 'horde_memcache_os', $os, 0, 0);
            }
        } elseif ($i > 1) {
            $os[$key] = $i - 1;
            $this->_memcache->set($this->_params['prefix'] . 'horde_memcache_os', $os, 0, 0);
        }

        return $res;
    }

    /**
     * Replace the value of a key.
     *
     * @see Memcache::replace()
     *
     * @param string $key       The key.
     * @param string $var       The data to store.
     * @param integer $timeout  Expiration time in seconds.
     *
     * @return boolean  True on success, false if key doesn't exist.
     */
    function replace($key, $var, $expire = 0)
    {
        $len = strlen($var);
        if ($len > MEMCACHE_MAX_SIZE) {
            $os = $this->get('horde_memcache_os');
            if ($os && isset($os[$key])) {
                return $this->set($key, $var, $expire);
            }
            return false;
        }

        return $this->_memcache->replace($this->_params['prefix'] . $key, $var, empty($this->_params['compression']) ? 0 : MEMCACHE_COMPRESSED, $expire);
    }

    /**
     * Obtain lock on a key.
     *
     * @param string $key  The key to lock.
     */
    function lock($key)
    {
        $key = $this->_params['prefix'] . $key . '_l';
        while ($this->_memcache->add($key, 1, 0, 10) === false) {
            usleep(100);
        }
        $this->_locks[$key] = true;
    }

    /**
     * Release lock on a key.
     *
     * @param string $key  The key to lock.
     */
    function unlock($key)
    {
        $key = $this->_params['prefix'] . $key . '_l';
        if (isset($this->_locks[$key])) {
            $this->_memcache->delete($key);
            unset($this->_locks[$key]);
        }
    }

}
