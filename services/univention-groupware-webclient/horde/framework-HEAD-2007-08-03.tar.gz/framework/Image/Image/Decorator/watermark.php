<?php
/**
 * Watermark decorator for the Horde_Image package.
 *
 * $Horde: framework/Image/Image/Decorator/watermark.php,v 1.4 2005/07/03 04:06:44 selsky Exp $
 *
 * @author  Chuck Hagenbuch <chuck@horde.org>
 * @package Horde_Image
 */
class Horde_Image_Decorator_watermark {

    /**
     * Draw the watermark.
     */
    function draw(&$image)
    {
    }

}
