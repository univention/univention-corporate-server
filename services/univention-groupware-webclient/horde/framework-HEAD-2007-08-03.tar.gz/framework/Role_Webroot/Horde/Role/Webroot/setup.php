<?php

class Horde_Role_Webroot_setup_postinstall {

    var $_pkg;
    var $_ui;
    var $_config;
    var $_lastverion;
    var $_registry;

    function init(&$config, &$pkg, $lastversion)
    {
        $this->_config = &$config;
        $this->_registry = &$config->getRegistry();
        $this->_ui = &PEAR_Frontend::singleton();
        $this->_pkg = &$pkg;
        $this->_lastversion = $lastversion;
        return true;
    }

    function run($answers, $phrase)
    {
        switch ($phrase) {
        case 'setup':
            if ($answers['webroot'] != '') {
                if (is_dir($answers['webroot'])) {
                    $this->_ui->outputData('Setting the horde_dir configuration setting to ' . $answers['webroot']);
                    $this->_config->set('horde_dir', $answers['webroot']);
                    $result = $this->_config->store();
                    if (is_a($result, 'PEAR_Error')) {
                        $this->_ui->outputData($result->getMessage());
                        return false;
                    }
                    return true;
                } else {
                    $this->_ui->outputData('Please choose an existing directory. ' . $this->_ui->bold('Installation failed!'));
                    return false;
                }
            }
            return false;
            break;
        }
    }
}
