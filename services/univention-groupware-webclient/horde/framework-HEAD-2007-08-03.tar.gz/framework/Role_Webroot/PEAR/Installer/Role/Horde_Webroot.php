<?php
class PEAR_Installer_Horde_Role_Webroot extends PEAR_Installer_Role_Common {}
