<?php

/**
 * The SyncML_Device:: class provides functionality that is
 * potentially (client) device dependant.
 *
 * So if a sync client needs any kind of special data of the data sent
 * to it or received from it, this is done here. There are two source
 * of information to identify an device: The first (and better) one is
 * the DevInf device info sent by the device upon a get request. If
 * DevInf is not supported or sent by the client, the SourceURI of the
 * device may be sufficent to identify it.
 *
 * Information about a few devices already working with SyncML::
 *
 * P800/P900/P910:
 * ---------------
 * Charset:
 * This device is able to handle UTF-8 and sends its XML packages in UTF8.
 * However even though the XML itself is UTF-8, it expects the enclosed
 * vcard-data to be ISO-8859-1 unless explicitly stated otherwise (using the
 * CHARSET option, which is deprecated for VCARD 3.0)
 *
 * Encoding:
 * String values are encoded "QUOTED-PRINTABLE"
 *
 * Other:
 * This devices handles tasks and events in one database.
 *
 * Copyright 2005-2007 Karsten Fourmont <karsten@horde.org>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * $Horde: framework/SyncML/SyncML/Device.php,v 1.35 2007/06/27 17:23:02 jan Exp $
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @package SyncML
 */
class SyncML_Device {

    function factory($driver)
    {
        $driver = basename($driver);

        if (empty($driver) || ($driver == 'none') || ($driver == 'default')) {
            $GLOBALS['backend']->logMessage('using default device class',
                                        __FILE__, __LINE__, PEAR_LOG_DEBUG);
            return new SyncML_Device();
        }

        include_once 'SyncML/Device/' . $driver . '.php';

        $class = 'SyncML_Device_' . $driver;
        if (class_exists($class)) {
            $device = new $class();
        } else {
            return false;
        }

        $GLOBALS['backend']->logMessage('created device class ' . $class,
                                        __FILE__, __LINE__, PEAR_LOG_DEBUG);
        return $device;
    }

    function &singleton($driver)
    {
        static $instances = array();

        if (!isset($instances[$driver])) {
            $instances[$driver] = SyncML_Device::factory($driver);
        }

        return $instances[$driver];
    }

    /**
     * When a client sends data during a sync but does not provide
     * information about the contenttype with this individual item,
     * this function returns the contenttype the item is supposed to be in.
     *
     * As this is only used to parse to the horde's importdata api functions,
     * some simple guesses for the contenttype are completely sufficient:
     * Horde does not care whether data is text/x-vcalendar or text/calendar.
     *
     */
    function getPreferredContentType($databaseURI)
    {
        $database = $GLOBALS['backend']->_normalize($databaseURI);

        /* Use some wild guessings. */
        if (strpos($database, 'contact') !== false ||
                  strpos($database, 'card') !== false) {
            return 'text/x-vcard';
        } elseif (strpos($database, 'note') !== false ||
                  strpos($database, 'memo') !== false) {
            return 'text/x-vnote';
        } elseif (strpos($database, 'task') !== false) {
            return 'text/x-vtodo';
        } elseif (strpos($database, 'cal') !== false ||
                  strpos($database, 'event') !== false) {
            return 'text/calendar';
        }
    }

    /**
     * Returns the preferrred contenttype of the client for the given
     * sync data type (contacts/tasks/notes/calendar).
     *
     * The result is passed as an option to the Horde API export functions.
     * Please note that this is not the contentType ultimately passed to the
     * client but rather the contentType presented to the Horde API export
     * functions.
     *
     * After the data is retrieved from horde, convertServer2Client can do
     * some post-processing and set the correct contentType acceptable for
     * the client if necessary.
     *
     * The default implementation tries to extract the contenttype from the
     * presented device info. If this does not work, some default are used.
     *
     * If the client does not provice proper DevInf data, this function may
     * have to be overwritten to return the correct values.
     *
     * ServerSyncURI: The server database of the sync:
     *                contacts|notes|calendar|tasks
     * sourceSyncURI: The URI for the client database. This is needed as
     *                the DevInf is arranged by sourceSyncURIs
     */

    function getPreferredContentTypeClient($serverSyncURI, $sourceSyncURI)
    {
        $di = $_SESSION['SyncML.state']->getDeviceInfo();
        $ds = $di->getDataStore($sourceSyncURI);
        if (!empty($ds)) {
            $r = $ds->getPreferredRXContentType();
            if (!empty($ds)) {
                return $r;
            }
        }

        $database = $GLOBALS['backend']->_normalize($serverSyncURI);

        /* No Info in DevInf. Use some wild guessings: */
        if (strpos($database, 'contact') !== false ||
            strpos($database, 'card') !== false) {
            return 'text/x-vcard';
        } elseif (strpos($database, 'note') !== false ||
                  strpos($database, 'memo') !== false) {
            // SynCML conformance suite expects this rather than text/x-vnote
            return 'text/plain';
        } elseif (strpos($database, 'task') !== false) {
            return 'text/x-vtodo';
        } elseif (strpos($database, 'cal') !== false ||
                  strpos($database, 'event') !== false) {
            return 'text/calendar';
        }
    }

    /**
     * Convert the content received from the client for the horde backend.
     *
     * Currently strips uid (primary key) information as client and
     * server might use different ones.
     *
     * Charset conversions might be added here too.
     *
     * @param string $content       The content to convert
     * @param string $contentType   The contentType of the content
     *
     * @return array                array($newcontent, $newcontentType):
     *                              the converted content and the
     *                              (possibly changed) new ContentType.
     */
    function convertClient2Server($content, $contentType)
    {
        $l = "\ninput received from client ($contentType)\n";
        if (strstr($contentType,'sif/') !== false) {
            // sync4fj sif/* data is base64_encoded.
            $l .= base64_decode($content) . "\n";
        } else {
            $l .= $content . "\n";
        }
        $GLOBALS['backend']->logFile(SYNCML_LOGFILE_DATA, $l);

        // Always remove client UID. UID will be seperately passed in
        // XML.
        $content = preg_replace('/(\r\n|\r|\n)UID:.*?(\r\n|\r|\n)/', '\1', $content, 1);

        return array($content, $contentType);
    }

    /**
     * Converts the content from the backend to a format suitable for the
     * client device.
     *
     * Strips the uid (primary key) information as client and server might use
     * different ones.
     *
     * Charset conversions might be added here too.
     *
     * @param string $content       The content to convert
     * @param string $contentType   The contentType of content as returned from
     *                              the backend
     * @return array                array($newcontent, $newcontentType, $newEncodingType):
     *                              the converted content and the
     *                              (possibly changed) new ContentType and EncodingType
     *                              (like b64 as used by Funambol/Sync4J).
     */

    function convertServer2Client($content, $contentType)
    {
        global $backend;
        if (is_array($contentType)) {
            $contentType = $contentType['ContentType'];
        }

        $l = "\noutput received from horde backend "
            . "($contentType):\n" . $content . "\n";
        $GLOBALS['backend']->logFile(SYNCML_LOGFILE_DATA, $l);

        /* Always remove server UID. UID will be seperately passed in XML. */
        $content = preg_replace('/(\r\n|\r|\n)UID:.*?(\r\n|\r|\n)/', '\1', $content, 1);

        if ($this->useLocalTime()) {
            $content = preg_replace_callback('/\d{8}T\d{6}Z/','convertUTC2LocalTime', $content);
        }

        return array($content, $contentType, null);
    }

    /**
     * Some devices like the Sony Ericsson P800/P900/P910 handle
     * vtodos (tasks) and vevents in the same "calendar" sync.  This
     * requires special actions on our side as we store this in
     * different databases (nag and kronolith).  This function
     * determines whether the client does it like that.  Currently
     * this is done by checking the DevInf information. For different
     * clients there may be different ways to find out how the client
     * likes its tasks.
     */
    function handleTasksInCalendar()
    {
        // Default: tasks and events are seperate databases.
        return false;
    }

    /**
     * Send individual status response for each Add,Delete,Replace.
     * The P800 class of devices seem to have trouble with too many
     * status responses. So omit them for these (and only these),
     */
    function omitIndividualSyncStatus()
    {
        // Default: send status response
        return false;
    }

    /**
     * Specifies if the payload data (VCALENDAR...) is enclosed in
     * \\[CDATA[ when sending via XML.
     * VCALENDAR data may contain xml special characters like &amp;, &lt; or
     * &gt; So when sending these via xml trouble may occur.
     * So the data should be enclosed in \\[CDATA[,
     * see http://en.wikipedia.org/wiki/CDATA
     * This applies only for XML, not for WBXML devices. Generally it should
     * be set to true. However the Funambol Sync4j client chokes on the cdata
     * so for this device it has to be set to false. Syn4j uses base64
     * encoding and so the problems with escaping does not occur.
     */
    function useCdataTag()
    {
        // Default: use it for xml
        return true;
    }

    /**
     * Some devices accept datetimes only in local time format:
     * DTSTART:20061222T130000
     * instead of the more robust (and default) UTC time:
     * DTSTART:20061222T110000Z
     */
    function useLocalTime()
    {
        // Default: use UTC
        return false;
    }

}

/** Converts a utc timestamp like
 *  "20061222T110000Z" into a local timestamp like
 *  "20061222T130000"
 *  @TODO: currently uses server timezone. Should user user pref timezone instead.
 */
function convertUTC2LocalTime($utc)
{
    $dateParts = explode('T', $utc[0]);
    $date = Horde_iCalendar::_parseDate($dateParts[0]);
    $time = Horde_iCalendar::_parseTime($dateParts[1]);

    // We don't know the timezone so assume local timezone.
    // @FIXME: shouldn't this be based on the user's timezone
    // preference rather than the server's timezone?
    $ts = @gmmktime($time['hour'], $time['minute'], $time['second'],
                          $date['month'], $date['mday'], $date['year']);

    return date('Ymd\THis',$ts);
}
