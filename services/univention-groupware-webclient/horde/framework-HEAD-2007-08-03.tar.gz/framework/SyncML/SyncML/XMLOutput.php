<?php

/**
 * This class creates the actual XML data and passes it on to a ContentHandler
 * for optional WBXML encoding.
 * Each member function creates one type of SyncML artefact
 * (like a Status response).
 * Currently some of the information is retrieved from state. Maybe remove
 * these dependencies (by providing the data as parameter) for an even cleaner
 * implementation.
 * The SyncML_XMLOutput class takes automatically care of creating a unique
 * CmdID for each command created.
 *
 * $Horde: framework/SyncML/SyncML/XMLOutput.php,v 1.13 2007/01/28 08:49:15 karsten Exp $
 *
 * @package SyncML
 */

class SyncML_XMLOutput {

    /**
     * The CmdID provides a unique ID for each command in a syncml packet.
     */
    var $_msg_CmdID;

    /**
     *  The outputhandler to whom the XML is passed: like  XML_WBXML_Encoder
     */
    var $_output;

    var $_uri;

    /**
     * The final output as procuded by the _output Encoder. Either an
     * XML string or a WBXML string.
     */
    function getOutput()
    {
        return $this->_output->getOutput();
    }

    /**
     * The length of the output as produced by the Encoder. To limit the
     * size of individual messages.
     */
    function getOutputSize()
    {
        return $this->_output->getOutputSize();
    }

    /**
     * To we create wbxml or not?
     */
    function isWBXML()
    {
        return is_a($this->_output, 'XML_WBXML_Encoder');
    }

    function &singleton()
    {
        static $instance;
        if (!isset($instance)) {
            $instance = new SyncML_XMLOutput();
        }
        return $instance;
    }

    function init(&$theoutputhandler)
    {
        $this->_output = $theoutputhandler;
        $this->_msg_CmdID = 1;

    }

    /** creates a SyncHdr output.
     * All required data is retrieved from state.
     */
    function outputHeader()
    {
        $attrs = array();
        $this->_uriMeta = $_SESSION['SyncML.state']->getURIMeta();

        $this->_output->startElement($this->_uri, 'SyncHdr', $attrs);

        $this->_output->startElement($this->_uri, 'VerDTD', $attrs);
        $chars = $_SESSION['SyncML.state']->getVerDTD();
        $this->_output->characters($chars);
        $this->_output->endElement($this->_uri, 'VerDTD');

        $this->_output->startElement($this->_uri, 'VerProto', $attrs);
        $chars = $_SESSION['SyncML.state']->getProtocolName();
        $this->_output->characters($chars);
        $this->_output->endElement($this->_uri, 'VerProto');

        $this->_output->startElement($this->_uri, 'SessionID', $attrs);
        $this->_output->characters($_SESSION['SyncML.state']->getSessionID());
        $this->_output->endElement($this->_uri, 'SessionID');

        $this->_output->startElement($this->_uri, 'MsgID', $attrs);
        $this->_output->characters($_SESSION['SyncML.state']->getMsgID());
        $this->_output->endElement($this->_uri, 'MsgID');

        $this->_output->startElement($this->_uri, 'Target', $attrs);
        $this->_output->startElement($this->_uri, 'LocURI', $attrs);
        // Source URI sent from client is Target for the server
        $this->_output->characters($_SESSION['SyncML.state']->getSourceURI());
        $this->_output->endElement($this->_uri, 'LocURI');
        if ($_SESSION['SyncML.state']->getLocName()) {
            $this->_output->startElement($this->_uri, 'LocName', $attrs);
            $this->_output->characters($_SESSION['SyncML.state']->getLocName());
            $this->_output->endElement($this->_uri, 'LocName');
        }
        $this->_output->endElement($this->_uri, 'Target');

        $this->_output->startElement($this->_uri, 'Source', $attrs);
        $this->_output->startElement($this->_uri, 'LocURI', $attrs);
        // Target URI sent from client is Source for the server
        $this->_output->characters($_SESSION['SyncML.state']->getTargetURI());
        $this->_output->endElement($this->_uri, 'LocURI');
        $this->_output->endElement($this->_uri, 'Source');

        /*
        Do not send RespURI Element. It's optional and may be misleading:
        $this->_targetURI is data from the client and not guaranteed to be
        the correct URL for access. Let the client just stay with the same
        URL it has used for the previous request(s).
        */
        //$this->_output->startElement($this->_uri, 'RespURI', $attrs);
        //$this->_output->characters($_SESSION['SyncML.state']->getTargetURI());
        //$this->_output->endElement($this->_uri, 'RespURI');

        // @Todo: omit this in SyncML1.0?
        $this->_output->startElement($this->_uri, 'Meta', $attrs);

        // Dummy Max MsqSize, this is just put in to make the packet
        // work, it is not a real value.
        $this->_output->startElement($this->_uriMeta, 'MaxMsgSize', $attrs);
        $chars = SERVER_MAXMSGSIZE; // 1Meg
        $this->_output->characters($chars);
        $this->_output->endElement($this->_uriMeta, 'MaxMsgSize');


        // MaxObjSize, required by protocol for SyncML1.1 and higher.
        if ($_SESSION['SyncML.state']->getVersion() > 0) {
            $this->_output->startElement($this->_uriMeta, 'MaxObjSize', $attrs);
            $this->_output->characters(SERVER_MAXOBJSIZE);
            $this->_output->endElement($this->_uriMeta, 'MaxObjSize');
        }
        $this->_output->endElement($this->_uri, 'Meta');

        $this->_output->endElement($this->_uri, 'SyncHdr');
    }

    function outputInit()
    {
        $this->_uri = $_SESSION['SyncML.state']->getURI();

        $this->_output->startElement($this->_uri, 'SyncML', array());
    }

    function outputBodyStart()
    {
        $this->_output->startElement($this->_uri, 'SyncBody', array());
    }

    function outputFinal()
    {
        $this->_output->startElement($this->_uri, 'Final', array());
        $this->_output->endElement($this->_uri, 'Final');
    }

    function outputEnd()
    {
        $this->_output->endElement($this->_uri, 'SyncBody', array());
        $this->_output->endElement($this->_uri, 'SyncML', array());
    }


    function outputStatus($cmdRef, $cmd, $data,
                         $targetRef = '', $sourceRef = '',
                         $syncAnchorNext = '',
                         $syncAnchorLast = '')
    {
        $attrs = array();

        $this->_output->startElement($this->_uri, 'Status', $attrs);
        $this->_outputCmdID();

        $this->_output->startElement($this->_uri, 'MsgRef', $attrs);
        $chars = $_SESSION['SyncML.state']->getMsgID();
        $this->_output->characters($chars);
        $this->_output->endElement($this->_uri, 'MsgRef');

        $this->_output->startElement($this->_uri, 'CmdRef', $attrs);
        $chars = $cmdRef;
        $this->_output->characters($chars);
        $this->_output->endElement($this->_uri, 'CmdRef');

        $this->_output->startElement($this->_uri, 'Cmd', $attrs);
        $chars = $cmd;
        $this->_output->characters($chars);
        $this->_output->endElement($this->_uri, 'Cmd');

        if (!empty($targetRef)) {
            $this->_output->startElement($this->_uri, 'TargetRef', $attrs);
            $this->_output->characters($targetRef);
            $this->_output->endElement($this->_uri, 'TargetRef');
        }

        if (!empty($sourceRef)) {
            $this->_output->startElement($this->_uri, 'SourceRef', $attrs);
            $this->_output->characters($sourceRef);
            $this->_output->endElement($this->_uri, 'SourceRef');
        }

        // If we are responding to the SyncHdr and we are not
        // authorized then request basic authorization.
        if ($cmd == 'SyncHdr' && !$_SESSION['SyncML.state']->isAuthorized()) {
            // keep RESPONSE_CREDENTIALS_MISSING, otherwise set to RESPONSE_INVALID_CREDENTIALS
            $data = ($data== RESPONSE_CREDENTIALS_MISSING)
                ? RESPONSE_CREDENTIALS_MISSING
                : RESPONSE_INVALID_CREDENTIALS;

            $this->_output->startElement($this->_uri, 'Chal', $attrs);
            $this->_output->startElement($this->_uri, 'Meta', $attrs);

            $metainfuri = $_SESSION['SyncML.state']->getURIMeta();

            $this->_output->startElement($metainfuri, 'Type', $attrs);
            $this->_output->characters('syncml:auth-basic');
            $this->_output->endElement($metainfuri, 'Type');

            $this->_output->startElement($metainfuri, 'Format', $attrs);
            $this->_output->characters('b64');
            $this->_output->endElement($metainfuri, 'Format');

            $this->_output->endElement($this->_uri, 'Meta');
            $this->_output->endElement($this->_uri, 'Chal');

        }

        $this->_output->startElement($this->_uri, 'Data', $attrs);
        $this->_output->characters($data);
        $this->_output->endElement($this->_uri, 'Data');

        if (!empty($syncAnchorNext) || !empty($syncAnchorNLast)) {
            $this->_output->startElement($this->_uri, 'Item', $attrs);
            $this->_output->startElement($this->_uri, 'Data', $attrs);

            $metainfuri = $_SESSION['SyncML.state']->getURIMeta();
            $this->_output->startElement($metainfuri, 'Anchor', $attrs);

            if (!empty($syncAnchorLast)) {
              $this->_output->startElement($metainfuri, 'Last', $attrs);
              $this->_output->characters($syncAnchorLast);
              $this->_output->endElement($metainfuri, 'Last');
            }

            if (!empty($syncAnchorNext)) {
              $this->_output->startElement($metainfuri, 'Next', $attrs);
              $this->_output->characters($syncAnchorNext);
              $this->_output->endElement($metainfuri, 'Next');
            }

            $this->_output->endElement($metainfuri, 'Anchor');

            $this->_output->endElement($this->_uri, 'Data');
            $this->_output->endElement($this->_uri, 'Item');
        }

        $this->_output->endElement($this->_uri, 'Status');

    }

    function outputDevInf($cmdRef)
    {
        $attrs = array();

        $this->_output->startElement($this->_uri, 'Results', $attrs);
        $this->_outputCmdID();

        $this->_output->startElement($this->_uri, 'MsgRef', $attrs);
        $chars = $_SESSION['SyncML.state']->getMsgID();
        $this->_output->characters($chars);
        $this->_output->endElement($this->_uri, 'MsgRef');

        $this->_output->startElement($this->_uri, 'CmdRef', $attrs);
        $chars = $cmdRef;
        $this->_output->characters($chars);
        $this->_output->endElement($this->_uri, 'CmdRef');

        $this->_output->startElement($this->_uri, 'Meta', $attrs);
        $this->_output->startElement($_SESSION['SyncML.state']->getURIMeta(), 'Type', $attrs);
        if ($_SESSION['SyncML.state']->isWBXML()) {
            $this->_output->characters(MIME_SYNCML_DEVICE_INFO_WBXML);
        } else {
            $this->_output->characters(MIME_SYNCML_DEVICE_INFO_XML);
        }

        $this->_output->endElement($_SESSION['SyncML.state']->getURIMeta(), 'Type');
        $this->_output->endElement($this->_uri, 'Meta');

        $this->_output->startElement($this->_uri, 'Item', $attrs);
        $this->_output->startElement($this->_uri, 'Source', $attrs);
        $this->_output->startElement($this->_uri, 'LocURI', $attrs);
        $this->_output->characters($_SESSION['SyncML.state']->getDevInfURI());
        $this->_output->endElement($this->_uri, 'LocURI');
        $this->_output->endElement($this->_uri, 'Source');

        $this->_output->startElement($this->_uri, 'Data', $attrs);

        /* DevInf data is stored in wbxml not as a seperate codepage but
         * rather as a complete wbxml stream as opaque data.  So we need a
         * new Handler. */
        $devinfoutput = $this->_output->createSubHandler();

        $devinfoutput->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'DevInf', $attrs);
        $devinfoutput->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerDTD', $attrs);
        $devinfoutput->characters($_SESSION['SyncML.state']->getVerDTD());
        $devinfoutput->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerDTD', $attrs);
        $devinfoutput->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'Man', $attrs);
        $devinfoutput->characters('The Horde Project (http://www.horde.org)');
        $devinfoutput->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'Man', $attrs);
        $devinfoutput->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'DevID', $attrs);
        $devinfoutput->characters(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost');
        $devinfoutput->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'DevID', $attrs);
        $devinfoutput->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'DevTyp', $attrs);
        $devinfoutput->characters('server');
        $devinfoutput->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'DevTyp', $attrs);

        if ($_SESSION['SyncML.state']->getVersion() > 0) {
            $devinfoutput->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'SupportLargeObjs', $attrs);
            $devinfoutput->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'SupportLargeObjs', $attrs);

            $devinfoutput->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'SupportNumberOfChanges', $attrs);
            $devinfoutput->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'SupportNumberOfChanges', $attrs);
        }
        $this->_writeDataStore('notes', 'text/x-vnote', '1.1', $devinfoutput,
                               array('text/plain' => '1.0'));
        $this->_writeDataStore('contacts', 'text/x-vcard', '3.0', $devinfoutput,
                               array('text/x-vcard' => '2.1'));
        $this->_writeDataStore('tasks', 'text/calendar', '2.0', $devinfoutput,
                               array('text/x-vcalendar' => '1.0'));
        $this->_writeDataStore('calendar', 'text/calendar', '2.0', $devinfoutput,
                               array('text/x-vcalendar' => '1.0'));
        $devinfoutput->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'DevInf', $attrs);

        $this->_output->opaque($devinfoutput->getOutput());
        $this->_output->endElement($this->_uri, 'Data');
        $this->_output->endElement($this->_uri, 'Item');
        $this->_output->endElement($this->_uri, 'Results');
    }

    /**
     * Writes DevInf data for one DataStore.
     *
     * @param string $sourceref: data for SourceRef element.
     * @param string $mimetype: data for &lt;(R|T)x-Pref&gt;&lt;CTType&gt;
     * @param string $version: data for &lt;(R|T)x-Pref&gt;&lt;VerCT&gt;
     * @param string &$output contenthandler that will received the output.
     * @param array $additionaltypes: array of additional types for Tx and Rx;
     *              format array('text/vcard' => '2.0')
     */
    function _writeDataStore($sourceref, $mimetype, $version,&$output,
                             $additionaltypes = false)
    {
        $attrs = array();

        $_SESSION['SyncML.state'] = &$_SESSION['SyncML.state'];

        $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'DataStore', $attrs);
        $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'SourceRef', $attrs);
        $output->characters($sourceref);
        $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'SourceRef', $attrs);

        $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'Rx-Pref', $attrs);
        $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'CTType', $attrs);
        $output->characters($mimetype);
        $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'CTType', $attrs);
        $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerCT', $attrs);
        $output->characters($version);
        $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerCT', $attrs);
        $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'Rx-Pref', $attrs);

        if (is_array($additionaltypes)) {
            foreach ($additionaltypes as $ct => $ctver){
                $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'Rx', $attrs);
                $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'CTType', $attrs);
                $output->characters($ct);
                $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'CTType', $attrs);
                $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerCT', $attrs);
                $output->characters($ctver);
                $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerCT', $attrs);
                $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'Rx', $attrs);
            }
        }

        $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'Tx-Pref', $attrs);
        $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'CTType', $attrs);
        $output->characters($mimetype);
        $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'CTType', $attrs);
        $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerCT', $attrs);
        $output->characters($version);
        $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerCT', $attrs);
        $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'Tx-Pref', $attrs);

        if (is_array($additionaltypes)) {
            foreach ($additionaltypes as $ct => $ctver){
                $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'Tx', $attrs);
                $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'CTType', $attrs);
                $output->characters($ct);
                $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'CTType', $attrs);
                $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerCT', $attrs);
                $output->characters($ctver);
                $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'VerCT', $attrs);
                $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'Tx', $attrs);
            }
        }

        $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'SyncCap', $attrs);
        // We support all sync Types from 1-6:
        // two way, slow, refresh|update from client|server
        for ($i=1; $i<=6; ++$i) {
            $output->startElement($_SESSION['SyncML.state']->getURIDevInf() , 'SyncType', $attrs);
            $output->characters($i);
            $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'SyncType', $attrs);
        }
        $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'SyncCap', $attrs);
        $output->endElement($_SESSION['SyncML.state']->getURIDevInf() , 'DataStore', $attrs);
    }

    function outputAlert($alertCode, $clientDB = '', $serverDB = '', $lastAnchor = '', $nextAnchor = '')
    {
        $attrs = array();

        $this->_output->startElement($this->_uri, 'Alert', $attrs);
        $this->_outputCmdID();

        $this->_output->startElement($this->_uri, 'Data', $attrs);
        $chars = $alertCode;
        $this->_output->characters($chars);
        $this->_output->endElement($this->_uri, 'Data');

        $this->_output->startElement($this->_uri, 'Item', $attrs);

        if (!empty($clientDB)) {
            $this->_output->startElement($this->_uri, 'Target', $attrs);
            $this->_output->startElement($this->_uri, 'LocURI', $attrs);
            $this->_output->characters($clientDB);
            $this->_output->endElement($this->_uri, 'LocURI');
            $this->_output->endElement($this->_uri, 'Target');
        }

        if (!empty($serverDB)) {
            $this->_output->startElement($this->_uri, 'Source', $attrs);
            $this->_output->startElement($this->_uri, 'LocURI', $attrs);
            $this->_output->characters($serverDB);
            $this->_output->endElement($this->_uri, 'LocURI');
            $this->_output->endElement($this->_uri, 'Source');
        }

        $this->_output->startElement($this->_uri, 'Meta', $attrs);

        $this->_output->startElement($_SESSION['SyncML.state']->getURIMeta(), 'Anchor', $attrs);

        $this->_output->startElement($_SESSION['SyncML.state']->getURIMeta(), 'Last', $attrs);
        $this->_output->characters($lastAnchor);
        $this->_output->endElement($_SESSION['SyncML.state']->getURIMeta(), 'Last');

        $this->_output->startElement($_SESSION['SyncML.state']->getURIMeta(), 'Next', $attrs);
        $this->_output->characters($nextAnchor);
        $this->_output->endElement($_SESSION['SyncML.state']->getURIMeta(), 'Next');

        $this->_output->endElement($_SESSION['SyncML.state']->getURIMeta(), 'Anchor');


        // MaxObjSize, required by protocol for SyncML1.1 and higher.
        if ($_SESSION['SyncML.state']->getVersion() > 0) {
            $this->_output->startElement($_SESSION['SyncML.state']->getURIMeta(), 'MaxObjSize', $attrs);
            $this->_output->characters(SERVER_MAXOBJSIZE);
            $this->_output->endElement($_SESSION['SyncML.state']->getURIMeta(), 'MaxObjSize');
        }
        $this->_output->endElement($this->_uri, 'Meta');

                $this->_output->endElement($this->_uri, 'Item');
        $this->_output->endElement($this->_uri, 'Alert');

    }


    function outputGetDevInf()
    {
        $attrs = array();

        $this->_output->startElement($this->_uri, 'Get', $attrs);
        $this->_outputCmdID();

        $this->_output->startElement($this->_uri, 'Meta', $attrs);
        $this->_output->startElement($_SESSION['SyncML.state']->getURIMeta(), 'Type', $attrs);
        $attrs = array();
        if ($_SESSION['SyncML.state']->isWBXML()) {
            $chars = MIME_SYNCML_DEVICE_INFO_WBXML;
        } else {
            $chars = MIME_SYNCML_DEVICE_INFO_XML;
        }
        $this->_output->characters($chars);
        $this->_output->endElement($_SESSION['SyncML.state']->getURIMeta(), 'Type');
        $this->_output->endElement($this->_uri, 'Meta');

        $this->_output->startElement($this->_uri, 'Item', $attrs);
        $this->_output->startElement($this->_uri, 'Target', $attrs);
        $this->_output->startElement($this->_uri, 'LocURI', $attrs);
        $this->_output->characters($_SESSION['SyncML.state']->getDevInfURI());
        $this->_output->endElement($this->_uri, 'LocURI');
        $this->_output->endElement($this->_uri, 'Target');
        $this->_output->endElement($this->_uri, 'Item');

        $this->_output->endElement($this->_uri, 'Get');
    }

    /**
     * Output a single Sync command (Add, Delete, Replace).
     */
    function outputSyncCommand($command,
                           $content=null, $contentType = null,
                           $encodingType = null,
                           $cuid = null, $suid = null)
    {
        $attrs = array();

        $this->_output->startElement($this->_uri, $command, $attrs);
        $this->_outputCmdID();

        if (isset($contentType)) {
            $this->_output->startElement($this->_uri, 'Meta', $attrs);
            $this->_output->startElement($_SESSION['SyncML.state']->getURIMeta(), 'Type', $attrs);
            $this->_output->characters($contentType);
            $this->_output->endElement($_SESSION['SyncML.state']->getURIMeta(), 'Type');
            $this->_output->endElement($this->_uri, 'Meta');
        }

        if (isset($content)
            || isset($cuid) || isset($suid)) {
            $this->_output->startElement($this->_uri, 'Item', $attrs);
            if ($suid != null) {
                $this->_output->startElement($this->_uri, 'Source', $attrs);
                $this->_output->startElement($this->_uri, 'LocURI', $attrs);
                $this->_output->characters($suid);
                $this->_output->endElement($this->_uri, 'LocURI');
                $this->_output->endElement($this->_uri, 'Source');
            }

            if ($cuid != null) {
                $this->_output->startElement($this->_uri, 'Target', $attrs);
                $this->_output->startElement($this->_uri, 'LocURI', $attrs);
                $this->_output->characters($cuid);
                $this->_output->endElement($this->_uri, 'LocURI');
                $this->_output->endElement($this->_uri, 'Target');
            }

            if (!empty($encodingType)) {
                $this->_output->startElement($this->_uri, 'Meta', $attrs);
                $this->_output->startElement($_SESSION['SyncML.state']->getURIMeta(), 'Format', $attrs);
                $this->_output->characters($encodingType);
                $this->_output->endElement($_SESSION['SyncML.state']->getURIMeta(), 'Format');
                $this->_output->endElement($this->_uri, 'Meta');
            }
            if (isset($content)) {
                $this->_output->startElement($this->_uri, 'Data', $attrs);
                if($this->isWBXML()) {
                    $this->_output->characters($content);
                } else {
                    $device = $_SESSION['SyncML.state']->getDevice();
                    if ($device->useCdataTag()) {
                        /* Enclose data in CDATA if possible to avoid */
                        /* problems with &,< and >. */
                        $this->_output->characters('<![CDATA[' . $content . ']]>');
                    } else {
                        $this->_output->characters($content);
                    }
                }
                $this->_output->endElement($this->_uri, 'Data');
            }
            $this->_output->endElement($this->_uri, 'Item');
        }

        $this->_output->endElement($this->_uri, $command);
    }

    function outputSyncStart($clientLocURI,$serverLocURI, $numberOfChanges = null)
    {
        $attrs = array();

        $this->_output->startElement($this->_uri, 'Sync', $attrs);
        $this->_outputCmdID();

        $this->_output->startElement($this->_uri, 'Target', $attrs);
        $this->_output->startElement($this->_uri, 'LocURI', $attrs);
        $this->_output->characters($clientLocURI);
        $this->_output->endElement($this->_uri, 'LocURI');
        $this->_output->endElement($this->_uri, 'Target');

        $this->_output->startElement($this->_uri, 'Source', $attrs);
        $this->_output->startElement($this->_uri, 'LocURI', $attrs);
        $this->_output->characters($serverLocURI);
        $this->_output->endElement($this->_uri, 'LocURI');
        $this->_output->endElement($this->_uri, 'Source');

        if (is_int($numberOfChanges)) {
            $this->_output->startElement($this->_uri, 'NumberOfChanges', $attrs);
            $this->_output->characters($numberOfChanges);
            $this->_output->endElement($this->_uri, 'NumberOfChanges');
        }

    }

    function outputSyncEnd()
    {
        $this->_output->endElement($this->_uri, 'Sync');
    }


    //  internal helper functions:

    function _outputCmdID() {
        $attrs = array();

        $this->_output->startElement($this->_uri, 'CmdID', $attrs);
        $this->_output->characters($this->_msg_CmdID);
        $this->_msg_CmdID += 1;
        $this->_output->endElement($this->_uri, 'CmdID');

    }

    /**
     * Output a single <ele>$str</ele> element.
     */
    function _singleEle($tag, $str, $uri = null)
    {
        if (empty($uri)) {
            $uri = $this->_uri;
        }
        $attrs = array();
        $this->_output->startElement($uri, $tag, $attrs);
        $this->_output->characters($str);
        $this->_output->endElement($uri, $tag);
    }
}
