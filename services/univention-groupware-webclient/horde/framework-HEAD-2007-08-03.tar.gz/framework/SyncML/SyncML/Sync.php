<?php
/**
 * $Horde: framework/SyncML/SyncML/Sync.php,v 1.43 2007/07/25 20:44:33 karsten Exp $
 *
 * Copyright 2003-2007 Anthony Mills <amills@pyramid6.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Anthony Mills <amills@pyramid6.com>
 * @since   Horde 3.0
 * @package SyncML
 */

/** @see SyncML_Sync::_state */
define('STATE_INIT', 0);
define('STATE_SYNC', 1);
define('STATE_MAP', 2);
define('STATE_COMPLETED', 3);

class SyncML_Sync {

    /**
     * Target (server) URI (database). One of contacts, notes, calendar, tasks.
     *
     * @var string
     */
    var $_targetLocURI;

    /**
     * Source (client) URI (database).
     *
     * @var string
     */
    var $_sourceLocURI;

    var $_syncType;

    /**
     * Counts the <Sync>s sent by the server.
     *
     * @var integer
     */
    var $_syncsSent = 0;

    /**
     * Counts the <Sync>s received by the server. Currently unused.
     *
     * @var integer
     */
    var $_syncsReceived = 0;

    /**
     * Map data is expected whenever an add is sent to the client.
     *
     * @var boolean
     */
    var $_expectingMapData = false;

    /**
     * State of the current sync.
     *
     * A sync starts in STATE_INIT and moves on to the next state with every
     * <Final> received from the client: STATE_INIT, STATE_SYNC, STATE_MAP,
     * STATE_COMPLETED.  STATE_MAP doesn't occur for _FROM_CLIENT syncs.
     *
     * @var constant
     */
    var $_state = STATE_INIT;

    /**
     * Sync Anchors determine the interval from which changes are retrieved.
     *
     * @var integer
     */
    var $_clientAnchorNext;

    var $_serverAnchorLast;
    var $_serverAnchorNext;

    /**
     * Counts for [server|client] adds/replaces/deletes and errors.
     *
     * @var integer
     */
    var $_client_add_count = 0;
    var $_client_replace_count = 0;
    var $_client_delete_count = 0;

    /**
     * Add due to client replace request when map entry is not found. Happens
     * during SlowSync.
     *
     * @var integer
     */
    var $_client_addreplaces = 0;

    var $_server_add_count = 0;
    var $_server_replace_count = 0;
    var $_server_delete_count = 0;
    var $_errors = 0;

    var $_server_adds;
    var $_server_replaces;
    var $_server_deletes;

    /**
     * For clients handling tasks and events in one database (like P900), we
     * need to seperately store the server tasks adds. So when we get a map
     * command from the client, we know wheter to put this in tasks or
     * calendar.
     */
    var $_server_task_adds;

    function SyncML_Sync($syncType, $serverURI, $clientURI, $serverAnchorLast,
                         $serverAnchorNext, $clientAnchorNext)
    {
        $this->_syncType = $syncType;
        $this->_targetLocURI = $serverURI;
        $this->_sourceLocURI = $clientURI;
        $this->_clientAnchorNext = $clientAnchorNext;
        $this->_serverAnchorLast = $serverAnchorLast;
        $this->_serverAnchorNext = $serverAnchorNext;
    }

    /**
     * Here's where the actual processing of a client-sent Sync Item takes
     * place. Entries are added, deleted or replaced from the server database
     * by using Horde API (Registry) calls.
     *
     * @todo maybe this should be moved to SyncItem
     */
    function handleClientSyncItem(&$output, &$item)
    {
        global $backend;

        $backend->logMessage('Handling client sent ' . $item->getElementType(),
                                        __FILE__, __LINE__, PEAR_LOG_DEBUG);

        /* if size of item is set: check it first */
        if ($item->getSize()>0) {
            if (strlen($item->getContent()) != $item->getSize() &&
                /* For some strange reason the SyncML conformance test suite
                 * sends an item with length n and size tag=n+1 and expects us
                 * the accept it. Happens in test 1301.  So ignore this to be
                 * conformant (and wrong). */
                strlen($item->getContent())+1 != $item->getSize() ) {
                $item->setResponseCode(RESPONSE_SIZE_MISMATCH);
                $GLOBALS['backend']->logMessage('Item Size mismatch size tag=' . $item->getSize() . ' but actual size is ' . strlen($item->getContent()),
                                                __FILE__, __LINE__, PEAR_LOG_ERR);
                $this->_errors++;
                return false;
            }
        }

        $device = $_SESSION['SyncML.state']->getDevice();
        $hordedatabase = $database = $this->_targetLocURI;
        if ($GLOBALS['backend']->_normalize($database) == 'calendar' &&
            $device->handleTasksInCalendar()) {
            $tasksincalendar = true;
            /* Check if the client sends us a vtodo in a calendar sync. */
            if (preg_match('/(\r\n|\r|\n)BEGIN[^:]*:VTODO/',
                           "\n" . $item->getContent())) {
                $hordedatabase = $this->_taskdDbUriForCalendarDbUri($database);
             }
        } else {
            $tasksincalendar = false;
        }

        /* Use contentType explicitly specified in this sync command. */
        $contentType = $item->getContentType();

        /* If not provided, use default from device info. */
        if (!$contentType) {
            $contentType = $device->getPreferredContentType($hordedatabase);
        }

        if ($item->getElementType() != 'Delete') {
            list($content, $contentType) = $device->convertClient2Server($item->getContent(), $contentType);
        }

        $cuid = $item->getCuid();
        $suid = false;

        if ($item->getElementType() =='Add') {
            /* Handle client add requests.
             *
             * @todo: check if this $cuid is already present and then maybe do
             * an replace instead? */
            $suid = $backend->addEntry($hordedatabase, $content, $contentType, $cuid);
            if (!is_a($suid, 'PEAR_Error')) {
                $this->_client_add_count++;
                $item->setResponseCode(RESPONSE_ITEM_ADDED);
                $backend->logMessage('added client entry as ' . $suid,
                                     __FILE__, __LINE__, PEAR_LOG_DEBUG);
            } else {
                $this->_errors++;
                /* @todo: better response code. */
                $item->setResponseCode(RESPONSE_NO_EXECUTED);
                $backend->logMessage('Error in adding client entry:' . $suid->message, __FILE__, __LINE__, PEAR_LOG_ERR);
            }

        } elseif ($item->getElementType() =='Delete') {
            /* Handle client delete requests. */
            $ok = $backend->deleteEntry($database, $cuid);
            if (!$ok && $tasksincalendar) {
                $backend->logMessage('special tasks delete ' . $suid . ' due to client request', __FILE__, __LINE__, PEAR_LOG_DEBUG);
                $ok = $backend->deleteEntry($this->_taskdDbUriForCalendarDbUri($database), $cuid);
            }

            if ($ok) {
                $this->_client_delete_count++;
                $item->setResponseCode(RESPONSE_OK);
                $backend->logMessage('deleted entry ' . $suid . ' due to client request', __FILE__, __LINE__, PEAR_LOG_DEBUG);
            } else {
                $this->_errors++;
                $item->setResponseCode(RESPONSE_ITEM_NO_DELETED);
                $backend->logMessage('Failure deleting client entry, maybe gone already on server.', __FILE__, __LINE__, PEAR_LOG_DEBUG);
            }

        } elseif ($item->getElementType() == 'Replace') {
            /* Handle client replace requests. */
            $suid = $backend->replaceEntry($hordedatabase, $content,
                                           $contentType, $cuid);

            if (!is_a($suid, 'PEAR_Error')) {
                $this->_client_replace_count++;
                $item->setResponseCode(RESPONSE_OK);
                $backend->logMessage('replaced entry ' . $suid . ' due to client request', __FILE__, __LINE__, PEAR_LOG_DEBUG);
            } else {
                $backend->logMessage($suid->message, __FILE__, __LINE__, PEAR_LOG_DEBUG);

                /* Entry may have been deleted; try adding it. */
                $suid = $backend->addEntry($hordedatabase, $content,
                                           $contentType, $cuid);
                if (!is_a($suid, 'PEAR_Error')) {
                    $this->_client_addreplaces++;
                    $item->setResponseCode(RESPONSE_ITEM_ADDED);
                    $backend->logMessage('add after replace request. suid=' . $suid, __FILE__, __LINE__, PEAR_LOG_DEBUG);
                } else {
                    $this->_errors++;
                    /* @todo: better response code. */
                    $item->setResponseCode(RESPONSE_NO_EXECUTED);
                    $backend->logMessage('Error in adding client entry due to replace request:' . $suid->message, __FILE__, __LINE__, PEAR_LOG_ERR);
                }
            }
        } else {
            $backend->logMessage('Unexpected elementType: ' . $item->getElementType(),
                                 __FILE__, __LINE__, PEAR_LOG_ERR);
        }

        return $suid;
    }

    /**
     * Creates a <Sync> output containing the server changes.
     */
    function createSyncOutput(&$output)
    {
        global $backend, $messageFull;

        $backend->logMessage('server create sync output for syncType=' . $this->_targetLocURI,
                             __FILE__, __LINE__, PEAR_LOG_DEBUG);

        /* If sync data from client only, nothing to be done here. */
        if($this->_syncType == ALERT_ONE_WAY_FROM_CLIENT ||
           $this->_syncType == ALERT_REFRESH_FROM_CLIENT) {
            return;
        }

        /* If one sync has been sent an no pending data: bail out. */
        if ($this->_syncsSent>0 && !$this->hasPendingElements()) {
            return;
        }

        /* $messageFull will be set to true to indicate that there's no room
         * for other data in this message. If it's false (empty) and there are
         * pending Sync data, the final command will sent the pending data.
         *
         * @todo: This global data should be moved to a global object. */
        $messageFull = false;

        $state = &$_SESSION['SyncML.state'];
        $device = &$state->getDevice();
        $contentType = $device->getPreferredContentTypeClient($this->_targetLocURI,
                                                              $this->_sourceLocURI);

        /* If server modifications are not retrieved yet (first Sync element),
         * do it now. */
        if (!is_array($this->_server_adds)) {
            $backend->logMessage('Compiling server changes from '
                                 . date("Y-m-d H:i:s",$this->_serverAnchorLast)
                                 . ' to '
                                 . date("Y-m-d H:i:s",$this->_serverAnchorNext),
                                 __FILE__, __LINE__, PEAR_LOG_DEBUG);

            $r = $this->_retrieveChanges($this->_targetLocURI,
                                         $this->_server_adds,
                                         $this->_server_replaces,
                                         $this->_server_deletes);
            if (is_a($r, 'PEAR_Error')) {
                return;
            }

            /* If tasks are handled inside calendar, do the same again for
             * tasks. Merge resulting arrays. */
            if ($this->_targetLocURI == 'calendar' &&
                $device->handleTasksInCalendar()) {
                $backend->logMessage('Handling tasks in calendar sync',
                                     __FILE__, __LINE__, PEAR_LOG_DEBUG);

                $this->_server_task_adds = $deletes2 = $replaces2 = array();
                $r = $this->_retrieveChanges('tasks',
                                             $this->_server_task_adds,
                                             $replaces2,
                                             $deletes2);
                if (is_a($r, 'PEAR_Error')) {
                    return;
                }
                $this->_server_adds = array_merge($this->_server_adds,
                                                  $this->_server_task_adds);
                $this->_server_replaces = array_merge($this->_server_replaces,
                                                      $replaces2);
                $this->_server_deletes = array_merge($this->_server_deletes,
                                                     $deletes2);

                $contentType2 = $device->getPreferredContentTypeClient(
                    'tasks',
                    $this->_sourceLocURI);
            }

            $numChanges = count($this->_server_adds)
                + count($this->_server_replaces)
                + count($this->_server_deletes);
            $backend->logMessage('sending ' . $numChanges . ' server changes '
                                 . 'for syncType=' . $this->_targetLocURI,
                                 __FILE__, __LINE__, PEAR_LOG_DEBUG);

            /* Now we know the number of Changes and can send them to the
             * client. */
            $di = $_SESSION['SyncML.state']->getDeviceInfo();
            if ($di->supportNumberOfChanges()) {
                $output->outputSyncStart($this->_sourceLocURI,
                                         $this->_targetLocURI,
                                         $numChanges);
            } else {
                $output->outputSyncStart($this->_sourceLocURI,
                                         $this->_targetLocURI);
            }
        } else {
            /* Package continued. Sync in subsequent message. */
            $output->outputSyncStart($this->_sourceLocURI,
                                     $this->_targetLocURI);
        }

        /* We sent a Sync. So at least we espect a status response and thus
         * another message from the client. */
        $GLOBALS['message_expectresponse'] = true;

        /* Copy the changes so we can modify the $this->_server_adds etc
         * inside the foreach loop by deleteing completed elements. */
        $adds     = $this->_server_adds;
        $replaces = $this->_server_replaces;
        $deletes  = $this->_server_deletes;

        if (count($adds) >0) {
            $this->_expectingMapData = true;
        }

        /* Handle deletions. */
        foreach ($deletes as $suid => $cuid) {
            /* Check if we have space left in the message. */
            if ($state->getMaxMsgSize() - $output->getOutputSize() < MSG_TRAILER_LEN) {
                $backend->logMessage('max msg size ('
                                     . $state->getMaxMsgSize()
                                     . ') approached on delete. Cursize='
                                     . $output->getOutputSize(),
                                     __FILE__, __LINE__, PEAR_LOG_DEBUG);
                $messageFull = true;
                $output->outputSyncEnd();
                $this->_syncsSent += 1;
                return;
            }
            unset($this->_server_deletes[$suid]);
            $backend->logMessage("delete: cuid=$cuid suid=$suid",
                                 __FILE__, __LINE__, PEAR_LOG_DEBUG);
            /* Create a Delete request for client. */
            $output->outputSyncCommand('Delete', null, null, null, $cuid, null);
            $this->_server_delete_count++;
        }

        /* Handle additions. */
        foreach ($adds as $suid => $cuid) {
            $backend->logMessage("add: $suid", __FILE__, __LINE__, PEAR_LOG_DEBUG);

            $syncDB = isset($this->_server_task_adds[$suid]) ? 'tasks' : $this->_targetLocURI;
            $ct = isset($this->_server_task_adds[$suid]) ? $contentType2 : $contentType;

            $c = $backend->retrieveEntry($syncDB, $suid, $ct);
            /* Item in history but not in database. Strange, but can
             * happen. */
            if (!is_a($c, 'PEAR_Error')) {
                list($clientContent, $clientContentType, $clientEncodingType) =
                    $device->convertServer2Client($c, $contentType);
                /* Check if we have space left in the message. */
                if (($state->getMaxMsgSize() - $output->getOutputSize() - strlen($clientContent)) < MSG_TRAILER_LEN) {
                    $backend->logMessage('max msg size ('
                                         . $state->getMaxMsgSize()
                                         . ') approached on add. Cursize='
                                         . $output->getOutputSize(),
                                         __FILE__, __LINE__, PEAR_LOG_DEBUG);
                    if (strlen($clientContent) + MSG_DEFAULT_LEN > $state->getMaxMsgSize()) {
                        $backend->logMessage('Data item will not fit in message. Partial sending not implemented yet. Item will not be sent!',
                                             __FILE__, __LINE__, PEAR_LOG_WARNING);
                        /* @todo: implement partial sending instead of
                         * dropping item! */
                        unset($this->_server_adds[$suid]);
                    }
                    $messageFull = true;
                    $output->outputSyncEnd();
                    $this->_syncsSent += 1;
                    return;
                }

                /* @todo: on SlowSync send Replace instead! */
                // $output->outputSyncCommand($refts == 0 ? 'Replace' : 'Add',
                $output->outputSyncCommand('Add', $clientContent,
                                           $clientContentType,
                                           $clientEncodingType,
                                           null, $suid);
                $this->_server_add_count++;
            } else {
                $backend->logMessage('api export call for ' . $suid . ' failed:  ' . $c->getMessage(),
                                     __FILE__, __LINE__, PEAR_LOG_ERR);
            }
            unset($this->_server_adds[$suid]);
        }

        /* Handle Replaces. */
        foreach ($replaces as $suid => $cuid) {
            if (!$cuid) {
                // @todo: create an "add" here instead?
                unset($this->_server_replaces[$suid]);
                continue;
            }

            $syncDB = isset($replaces2[$suid]) ? 'tasks' : $this->_targetLocURI;
            $ct = isset($replaces2[$suid]) ? $contentType2 : $contentType;

            $c = $backend->retrieveEntry($syncDB, $suid, $ct);
            /* Item in history but not in database. Strange, but can
             * happen. */
            if (!is_a($c, 'PEAR_Error')) {
                $backend->logMessage("replace: $suid",
                                     __FILE__, __LINE__, PEAR_LOG_DEBUG);
                list($clientContent, $clientContentType, $clientEncodingType) =
                    $device->convertServer2Client($c, $contentType);
                /* Check if we have space left in the message. */
                if (($state->getMaxMsgSize() - $output->getOutputSize() - strlen($clientContent)) < MSG_TRAILER_LEN) {
                    $backend->logMessage('max msg size ('
                                         . $state->getMaxMsgSize()
                                         . ') approached on replace. Cursize='
                                         . $output->getOutputSize(),
                                         __FILE__, __LINE__, PEAR_LOG_DEBUG);
                    if (strlen($clientContent) + MSG_DEFAULT_LEN > $state->getMaxMsgSize()) {
                        $backend->logMessage('Data item will not fit in message. Partial sending not implemented yet. Item will not be sent!',
                                         __FILE__, __LINE__, PEAR_LOG_WARNING);
                        /* @todo: implement partial sending instead of
                         * dropping item! */
                        unset($this->_server_replaces[$suid]);
                    }
                    $messageFull = true;
                    $output->outputSyncEnd();
                    $this->_syncsSent += 1;
                    return;
                }
                $output->outputSyncCommand('Replace', $clientContent,
                                           $clientContentType,
                                           $clientEncodingType,
                                           $cuid, null);
                $this->_server_replace_count++;
            }
            unset($this->_server_replaces[$suid]);
        }

        /* Finished! Send closing </Sync>. */
        $output->outputSyncEnd();
        $this->_syncsSent += 1;
    }

    function _retrieveChanges($syncDB, &$adds, &$replaces, &$deletes)
    {
        global $backend;

        $adds = $replaces = $deletes = array();

        $r = $backend->getServerChanges($syncDB,
                                        $this->_serverAnchorLast,
                                        $this->_serverAnchorNext,
                                        $adds, $replaces, $deletes);

        if (is_a($r, 'PEAR_Error')) {
            $backend->logMessage($r, __FILE__, __LINE__, PEAR_LOG_ERR);
            return $r;
        }

        // Reduce duplicate adds or replaces:
        $copy = $adds;
        foreach ($copy as $suid => $cuid) {
            if (isset($deletes[$suid])) {
                // Delete will be sent, no need for add.
                unset($adds[$suid]);
            }
        }
        $copy = $replaces;
        foreach ($copy as $suid => $cuid) {
            if (isset($adds[$suid]) || isset($deletes[$suid])) {
                // Delete or add will be sent, no need to modify.
                unset($replaces[$suid]);
            }
        }

        return true;
    }

    /**
     * Notifies the sync that a final has been received by the client.
     *
     * Depending on the current state of the sync this can mean various
     * things:
     * a) Init phase (Alerts) done. Next package contaings actual syncs.
     * b) Sync sending from client done. Next package are maps (or finish
     *    or finish if ONE_WAY_FROM_CLIENT sync
     * c) Maps finished, completly done.
     */
    function handleFinal(&$output)
    {
        $GLOBALS['backend']->logMessage('HandleFinal for state=' . $this->_state,
                                        __FILE__, __LINE__, PEAR_LOG_DEBUG);

        switch ($this->_state) {
        case STATE_INIT:
            $this->_state = STATE_SYNC;
            break;
        case STATE_SYNC:
            /* Received all client Sync data, now we are allowed to send
             * server sync data.
             *
             * Funambol connector 3.0.x expects server sync data to be sent
             * _not_ in response to a <Sync> but rather after an explicit
             * NextMessage alert.
             *
             * @todo: create a getDevice()->useSentyncDataLate() method
             * instead of this. */
            if (!is_a($_SESSION['SyncML.state']->getDevice(), 'SyncML_Device_sync4j')) {
                /* Now send client changes to server: this will produce the
                 * <sync> response: */
                $this->createSyncOutput($output);
            } else {
                /* We still have a sync to send. Don't send <Final> yet.
                 *
                 * Normaly SyncML.php would automatically send the pending
                 * data and Final at the end of this message.  Avoid this by
                 * marking the message as "full". This is a hack. */
                $GLOBALS['messageFull'] = true;
                $GLOBALS['backend']->logMessage('Not yet sending server sync data: '
                                                . 'special Funambol handling.',
                                                __FILE__, __LINE__, PEAR_LOG_DEBUG);
            }

            // FROM_CLIENT_SYNC doeesn't require a MAP package:
            if ($this->_syncType == ALERT_ONE_WAY_FROM_CLIENT ||
                $this->_syncType == ALERT_REFRESH_FROM_CLIENT ||
                !$this->_expectingMapData) {
                $this->_state = STATE_COMPLETED;
            } else {
                $this->_state = STATE_MAP;
            }
            break;
        case STATE_MAP:
            $this->_state = STATE_COMPLETED;
            break;
        }
    }

    /**
     * Returns true if there are still outstanding server sync items to
     * be sent to the client.
     *
     * This is the case if the MaxMsgSize has been reached and the pending
     * elements are to be sent in another message.
     */
    function hasPendingElements()
    {
        if (!is_array($this->_server_adds)) {
            /* Changes not compiled yet: not pending: */
            return false;
        }

        return (count($this->_server_adds) + count($this->_server_replaces) + count($this->_server_deletes)) > 0;
    }

    function addSyncReceived()
    {
        $this->_syncsReceived++;
    }

    /* Currently unused */
    function getSyncsReceived()
    {
        return $this->_syncsReceived;
    }

    function isComplete()
    {
        return $this->_state == STATE_COMPLETED;
    }

    /**
     * Completes a sync once everything is done: store the sync anchors so the
     * next sync can be a delta sync and produce some debug info.
     */
    function closeSync()
    {
        $GLOBALS['backend']->writeSyncAnchors($this->_targetLocURI,
                                              $this->_clientAnchorNext,
                                              $this->_serverAnchorNext);

        $s = sprintf('Successful sync of %s! Summary: failures=%d; '
                     . 'client(Add,Replace,Delete,AddReplaces)=%d,%d,%d,%d; '
                     . 'server(Add,Replace,Delete)=%d,%d,%d',
                     $this->_targetLocURI,
                     $this->_errors,
                     $this->_client_add_count,
                     $this->_client_replace_count,
                     $this->_client_delete_count,
                     $this->_client_addreplaces,
                     $this->_server_add_count,
                     $this->_server_replace_count,
                     $this->_server_delete_count);

        $GLOBALS['backend']->logMessage($s , __FILE__, __LINE__, PEAR_LOG_INFO);
    }

    function getServerLocURI()
    {
        return $this->_targetLocURI;
    }

    function getClientLocURI()
    {
        return $this->_sourceLocURI;
    }

    function getClientAnchorNext()
    {
        return $this->_clientAnchorNext;
    }

    function getServerAnchorNext()
    {
        return $this->_serverAnchorNext;
    }

    function getServerAnchorLast()
    {
        return $this->_serverAnchorLast;
    }

    function createUidMap($databaseURI, $cuid, $suid)
    {
        $device = &$_SESSION['SyncML.state']->getDevice();

        if (strtolower(substr($databaseURI,0,8)) == 'calendar' &&
            $device->handleTasksInCalendar() &&
            isset($this->_server_task_adds[$suid])) {
            $db = $this->_taskdDbUriForCalendarDbUri($databaseURI);
        } else {
            $db = $databaseURI;
        }

        $GLOBALS['backend']->createUidMap($db, $cuid, $suid);

        $GLOBALS['backend']->logMessage('created Map for cuid=' . $cuid
                                        . ' and suid=' . $suid
                                        . ' in db ' . $db,
                                        __FILE__, __LINE__, PEAR_LOG_DEBUG);

    }

    /**
     * Converts a calendar databaseURI to a tasks databaseURI for devices with
     * handleTasksInCalendar.
     */
    function _taskdDbUriForCalendarDbUri($databaseURI)
    {
        return preg_replace('/^calendar/', 'tasks', $databaseURI);
    }

}
