<?php

require_once 'SyncML/State.php';

/**
 * The SyncML_Command class provides a super class fo SyncBody
 * commands.
 *
 * $Horde: framework/SyncML/SyncML/Command.php,v 1.17 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2003-2007 Anthony Mills <amills@pyramid6.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Anthony Mills <amills@pyramid6.com>
 * @since   Horde 3.0
 * @package SyncML
 */
class SyncML_Command {

    /**
     * @var integer
     */
    var $_cmdID;

    /**
     * Stack for holding the xml elements during creation of the object from
     * the xml event flow.
     *
     * @var array
     */
    var $_Stack = array();

    /**
     * @var string
     */
    var $_chars;

    /**
     * Name of the command. Like 'Put'.
     * Gets automatically set in the factory method.
     */
    var $_cmdName;

    /**
     * Reference to XMLOutputHandler to create the output.
     * Gets automatically set in the factory method.
     */
    var $_outputHandler;


    function startElement($uri, $element, $attrs)
    {
        $this->_Stack[] = $element;
    }

    function endElement($uri, $element)
    {
        switch (count($this->_Stack)) {
        case 2:
            if ($element == 'CmdID') {
                $this->_cmdID = intval(trim($this->_chars));
            }
            break;
        }

        if (isset($this->_chars)) {
            unset($this->_chars);
        }

        array_pop($this->_Stack);
    }

    function characters($str)
    {
        if (isset($this->_chars)) {
            $this->_chars = $this->_chars . $str;
        } else {
            $this->_chars = $str;
        }
    }

    function getCommandName()
    {
        return $this->_cmdName;
    }

    function &factory($command, &$outputHandler, $params = null)
    {
        include_once 'SyncML/Command/' . $command . '.php';
        $class = 'SyncML_Command_' . $command;
        if (class_exists($class)) {
            $cmd =& new $class($params);
            $cmd->_cmdName = $command;
            $cmd->_outputHandler = &$outputHandler;
        } else {
            $GLOBALS['backend']->logMessage('Class definition of '
                                                . $class . ' not found.',
                                            __FILE__, __LINE__, PEAR_LOG_ERR);
            require_once 'PEAR.php';
            $cmd = PEAR::raiseError('Class definition of ' . $class . ' not found.');
        }

        return $cmd;
    }

    /** This method is supposed to implement the actual business logic of
     * the command once the XML parsing is complete. This is called by
     * the SyncML_Handler.
     * Pure virtual function.
     */
    function handleCommand()
    {

    }
}


