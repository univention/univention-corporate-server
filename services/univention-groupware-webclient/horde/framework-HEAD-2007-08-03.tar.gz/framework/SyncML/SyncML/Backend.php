<?php
/**
 *
 * Copyright 2005-2007 Karsten Fourmont <karsten@horde.org>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * $Horde: framework/SyncML/SyncML/Backend.php,v 1.44 2007/07/25 20:48:55 karsten Exp $
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @package SyncML
 *
 * A SyncML Backend provides the interface between the SyncML protocol as
 * provided by the SyncML pear package and an actual calendar or address book
 * application. This "actual application" is called the "data store" in this
 * description.
 *
 * The backend provides the following groups of functions:
 *
 * 1) Access to the datastore: read, add,replace and delete of entries.
 *    Also retrieve information about changes in data store
 *    This is done via the retrieveEntry, addEntry, replaceEntry, deleteEntry
 *    and getServerChanges functions.
 *
 * 2) User Management functions.
 *    This is the checkAuthorization function to verify that a given user/
 *    password combination is allowed access to the backend data store and
 *    the setUser function which does a "login" to the backend data store if
 *    required by the type of backend data store. Please note that the password
 *    is only transferred once in a sync session, so when handling the
 *    subsequent packets messages, the user may need to be "logged in" without
 *    a password. (Or the session management keeps the user "logged in").
 *
 * 3) Maintainig the Client ID <-> Server ID map.
 *    The SyncML protocol does not require clients and servers to use the
 *    same primary keys for the data entries. So a map has to be in place
 *    to convert between client primary keys (called cuid's here) and server
 *    primary keys (called suid's). It's up to the server to maintain this map.
 *    Functions for this are createUidMap, getCuid, getSuid and getChangeTS.
 *
 * 4) Sync Anchor Handling
 *    After a successful initial sync, the client and server sync timestamps
 *    are stored. This allows to perform subsequent syncs as delta sync, where
 *    only new changes are replicated. Servers as well as clients need to be
 *    ablt to store two sync anchors (the client's and the server's) for a
 *    sync.
 *    Functions for this are readSyncAnchors and writeSyncAnchors
 *
 * 5) Test supporting functions
 *    The Syncml module comes with its own testing framework. All you need to
 *    do is implement two functions (testSetup and testTearDown) and you are
 *    able to test your backend with all the test cases that are part of the
 *    module.
 *
 * 6)  Miscellaneous  functions
 *     This involves session handling (sessionStart and sessionClose), logging
 *     (logMessage and logFile), timestamp creation (getCurrentTimeStamp) and
 *     charset handling (getCharset, setCharset) and database identification
 *     (isValidDatabaseURI). For all of these functions, a default
 *     implementation isprovided in Backend.php
 *
 * If you want to create a backend for your own appliction, you can either
 * derive from Backend.php and implement everything in groups 1 to 5 or you
 * derive from Sql.php Sql.php implements an example backend based on direct
 * database access ussing the pear MDB2 package. In this case you only need
 * to implement groups 1 to 3 and can use the implementation from Sql.php as
 * a guideline for these functions.
 *
 * Key Concepts
 * ------------
 * In order to successfully create a backend, some understanding of a few
 * key concepts in SyncML and the SyncML PEAR package are certainly helpful.
 * So here's some stuff that should make some issues clear (or at lest less
 * obfuscated):
 *
 * 1) DatabaseURIs and Databases
 *    The SyncML protocol itself is completly independant from the data that is
 *    replicated. Normally the data is calendar or address book entries but it
 *    may really be anything from browser bookmarks to comeplete database
 *    tables. An ID (string name) of the dabtase you want to actually replicate
 *    has to be configured in the client. Typically that's something like
 *    'calendar' or 'tasks'. Client and server must agree on these names.
 *    In addition this string may be used to provide additional arguments.
 *    These are provided in a HTTP GET query style: like
 *    tasks?ignorecompletedtasks to replicate only pending tasks. Such a
 *    "sync identifier" is called a DatabaseURI and is really a database name
 *    plus some additional options.
 *    The PEAR SyncML package completly ignores these options and simply passes
 *    them on to the backend. It's up to the backend to deside what to do with
 *    them. However when dealing with the internal maps (cuid<->suid and sync
 *    anchors), it's most likely to use the database name only rather than the
 *    full databaseURI. The map information saying that server entry
 *    20070101203040xxa@mypc.org has id 768 in the client device is valid for
 *    the database "tasks", not for "tasks?somesillyoptions". So what you
 *    normally do is calling some kind of
 *    $database=$this->_normalize($databaseURI) in every backend functions that
 *    deals with databaseURIs and use $database afterwards. However actual
 *    usage of options is up to the backend implementation. SyncML works fine
 *    without.
 *
 * 2) Suid and Guid mapping
 *    This is the mapping of client IDs to server IDs and vice versa.
 *    Please note that this map is per user and per client device: the server
 *    entry 20070101203040xxa@mypc.org may have ID 720 in your Palm and
 *    AA10FC3A in your Smartphone.
 *
 * 3) Sync Anchors
 *    @TODO describe sync anchors
 *    To be Done. Have a look at the syncml spec
 *    http://www.openmobilealliance.org/tech/affiliates/syncml/syncmlindex.html
 *    to find out more.
 *
 * 4) Changes and Timestamps
 *    @TODO description of Changes and Timestamps, "mirroring effect"
 *    This is real tricky stuff.
 *    First it's important to know, that the SyncML protocol requires the
 *    ending timestamp of the sync timeframe to be  exchanged _before_ the
 *    actual syncing starts. So all changes made during a sync have timestamps
 *    that are in the timeframe for the next upcoming sync.
 *    Data exchange in a sync session works in two steps:
 *    1st) the clients sends its changes to the server
 *    2nd) the server sends its changes to the client.
 *
 *    So when in step 2), the backend datastore api is called with a request
 *    like "give me all changes in the server since the last sync".
 *    Thus you also get the changes induced by the client in step 1) as well.
 *    You have to somehow "tag" them to avoid echoing (and thus duplicatinging)
 *    them back to the client. Simply storing the guids in the session is not
 *    sufficient: the changes are made _after_ the end time
 *    stamp (see a)) of the current sync so you'll dupe them in the next sync.
 *    The current implementation deals with this as follows: whenever a
 *    client induced change is done in the backend, the timestamp for this change
 *    is stored in t cuid<->suid map in an additional field. That's the perfect
 *    place as the tagging needs to be done "per client device": when I receive
 *    an add from my PocketPC I must not send it back as an add to this device,
 *    but to my Smartphone I must send it.
 *    This is sorted out during the getServerChanges process: if a found change
 *    has a timestamp that's the same as in the guid<->suid map, it came from
 *    the client and must not be added to the list of changes to be sent
 *    to this client.
 *    See the description of getChangeTS for some more information.
 *    As I said, tricky stuff indeed.
 *
 * 5) Messages and Packages
 *    One Message is one HTTP Request. One Package is one "logical message":
 *    one sync step. Normally the two coincide. However due to message size
 *    restrictions one package may be transferred in multiple messages
 *    (http requests).
 *
 * 7) Server mode, client mode and test mode.
 *    Per default, a backend is used for an SyncML server. Regearding the
 *    SyncML protocol, the working of client and server is where similar,
 *    expcept that
 *    a) the client initiates the sync requests and the server respons to them,
 *       and
 *    b) the server must maintain the client id<->server id map.
 *
 *    Currently the SyncML package is designed to create servers. But is's
 *    an obvious (and straightforward) extension to do it for clients as well.
 *    And as a client has actually less work to do than a server, the backend
 *    should work for servers _and_ clients. During the sessionStart, the
 *    backend gets a parameter to let it know wheter it's in client or server
 *    mode (or test, see below). When in client mode, it should behave
 *    slightly different:
 *    a) the client doesn't do suid<->cuid mapping, so all invokatinos to
 *       the map creation functions createUidMap, getCuid, getSuid and
 *       getChangeTS should be omitted
 *    b) the client has only cuids, no server ids (suids). So all arguments
 *       are considered cuids even when named suid. See the Sql.php
 *       implementation, it's actually not that difficult.
 *
 *    Finally there's the test mode. The test cases consist of replaying
 *    pre-corded sessions. For that to work, the test script must "simulate
 *    user entries in the server data store. To do so, it creates a
 *    backend in test mode. This behaves similar to a client: when
 *    an server entry is created (modified) using addEntry (replaceEntry),
 *    no map entry must be done.
 *    The test backend uses also two functions testSetup and testTearDown
 *    to create a clean (empty) enviroment for the test user syncmltest.
 *    See the Sql.php implementation for details.
**/

// Types of logfiles. See logFile method.
define ('SYNCML_LOGFILE_CLIENTMESSAGE', 1);
define ('SYNCML_LOGFILE_SERVERMESSAGE', 2);
define ('SYNCML_LOGFILE_DEVINF',        3);
define ('SYNCML_LOGFILE_DATA',          4);


define ('SYNCML_BACKENDMODE_SERVER',  1);
define ('SYNCML_BACKENDMODE_CLIENT',  2);
define ('SYNCML_BACKENDMODE_TEST',    3);

class SyncML_Backend {

    var $_logtext;

    var $_debugDir;

    var $_debugFiles;

    var $_logLevel;

    var $_charset;

    // Store packet numbber for debug output
    var $_packetNum;

    var $_user;

    /*
     * The ID of the client Device ID. This is used for all data access
     * as an ID to allow distinguish syncs with different devices.
     * The _user together with the _syncDeviceID is used as an additional key for
     * all persistence operations.
     *
     */
    var $_syncDeviceID;


    var $_backendMode;

    /**
     * Constructor. Sets up the default logging mechanism.
     * @param array $params: an assoc array with parameters. The following
     *                       are supported by the Backend.php default
     *                       implementation. Individual backends may support
     *                       more or other parameters.
     *                       debug_dir: a directory to write debug output to.
     *                       Must be writeable by the webserver.
     *                       debug_files: If true, log all incoming and
     *                       outgoing packets and data conversion and devinf
     *                       log in debug_dir
     *                       log_level: PEAR_LOG_*. Only log log entries with
     *                       at least this  level. Defaults to PEAR_LOG_INFO
     */
    function SyncML_Backend($params)
    {
            if (!empty($params['debug_dir']) && is_dir($params['debug_dir'])) {
                $this->_debugDir = $params['debug_dir'];
                $this->_logtext = '';
            } else {
                $this->_debugDir = null;
                $this->_logtext = null;
            }

            $this->_debugFiles = !empty($params['debug_files']);
            $this->_logLevel   = isset($params['log_level']) ? $params['log_level'] : PEAR_LOG_INFO;

            $this->logMessage('Backend of class ' . get_class($this) . ' created',
                              __FILE__, __LINE__, PEAR_LOG_DEBUG);
     }

    /**
     * Attempts to return a concrete Backend instance based on $driver.
     *
     * @param string $driver The type of concrete Backend subclass to return.
     *                       The code is dynamically included from
     *                       Backend/$driver.php if now path is given or
     *                       directly with include_once($driver . '.php')
     *                       if a path is included. So make sure this parameter
     *                       is "safe" and not directly taken from web input.
     *                       The class in the file must be named
     *                       'SyncML_Backend_' . basename($driver) and extend
     *                       SyncML_Backend.
     *
     * @param array $params  A hash containing any additional configuration or
     *                       connection parameters a subclass might need.
     *
     * @return Backend The newly created concrete Backend instance, or false
     *                 on an error.
     */
    function factory($driver, $params = null)
    {

        if (empty($driver) || ($driver == 'none')) {
            return false;
        }

        if( basename($driver) == $driver) {
            include_once 'SyncML/Backend/' . $driver . '.php';
        } else {
            include_once $driver . '.php';
        }

        $driver = basename($driver);

        $class = 'SyncML_Backend_' . $driver;
        if (class_exists($class)) {
            $backend = new $class($params);
        } else {
            return false;
        }

        return $backend;
    }

    /**
     * Sets the charset. All data passed to the backend uses this charset and
     * data returned from the backend must use this charset, too.
     */
    function setCharset($c)
    {
        $this->_charset = $c;
    }

    function getCharset()
    {
        return $this->_charset;
    }

    function getSyncDeviceID()
    {
        return $this->_syncDeviceID;
    }

    /**
     * Sets the user used for this session.
     * setUser is called by SyncML right after the sessionStart when either
     * authorization is accepted (via checkAuthorization) or a valid user
     * has been retrieved from the state.
     * The _user together with the _SyncDeviceID is used as an additional key for
     * all persistence operations.
     * @TODO: describe that setUser may have to to a "login", when the backend
     * doesn't keep auth state within a session or even then when in test mode.
     */
    function setUser($user)
    {
        $this->_user = $user;
    }

    function getUser()
    {
        return $this->_user;
    }

    /**
     * Starts a php session with the given session id.
     *
     * The _syncDeviceID together with _user is used as an additional key for
     * all persistence operations. The user is set later as it may be
     * retrieved from the session state.

     * @param string $session_id The session_id to use. Only for server mode.
     * @TODO: needs more description of parameters and what the three
     * backend modes actually do and how the differ.
     */
    function sessionStart($syncDeviceID, $sessionId, $backendMode = SYNCML_BACKENDMODE_SERVER)

    {
        $this->_syncDeviceID = $syncDeviceID;
        $this->_backendMode = $backendMode;

        // Only the server needs to start a session:
        if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
            $sid = md5($syncDeviceID . $sessionId);

            session_id($sid);
            @session_start();
        }
    }

    /**
     * Close the php session.
     */
    function sessionClose()
    {
        // Only the server needs to start a session:
        if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
            session_unset();
            session_destroy();
        }
    }

    /** Checks if $databaseURI is a valid database URI than can be synced with
     * this backend.
     * This default implementation accepts tasks, calendar, notes and contacts.
     * However individual backends may offer replication of different or
     * completly other databases (like browser bookmars or cooking recipes).
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *
     * @return boolean      true on valid uri, false on invalid uri.
     */
    function isValidDatabaseURI($databaseURI)
    {
        $database = $this->_normalize($databaseURI);
        switch(strtolower($database)) {
            case 'tasks';
            case 'calendar';
            case 'notes';
            case 'contacts';
                return true;
            default:
                $this->logMessage('Invalid Database: ' . $database
                            . '. Try tasks, calendar, notes or contacts.',
                            __FILE__, __LINE__, PEAR_LOG_ERR);
                return false;
        }
    }

    /**
     * Get entries that have been modified in the server database.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     * @param integer $from_ts        Start timestamp.
     * @param integer $to_ts          Exclusive end timestamp. Not yet
     *                                implemented.
     * @param array  &$adds           Output array: assoc array of
     *                                adds suid=>0
     * @param array  &$mods           Output array: assoc array of
     *                                modifications suid=>cuid
     * @param array  &$dels           Output array: assoc array of
     *                                deletions suid=>cuid
     * @return mixed                  true on success or a PEAR_Error object.
     */

    function getServerChanges($databaseURI, $from_ts, $to_ts,
                              &$adds, &$mods, &$dels)
    {
        die ("Not implemented!");
    }

    /**
     * Retrieves an entry from the backend.
     *
     * @param string $databaseURI URI of Database to sync. Like
     *                            calendar, tasks, contacts or notes.
     *                            May include optional parameters:
     *                            tasks?options=ignorecompleted.
     * @param string $suid       Server unique id of the entry: for horde
     *                           this is the guid.
     * @param string contentType Content-Type: the mime type in which the
     *                           function shall return the data
     *
     * @return mixed             A string with the data entry or
     *                           or a PEAR_Error object.
     */
    function retrieveEntry($databaseURI, $suid, $contentType)
    {
        die ("Not implemented!");
    }

    /**
     * Adds an entry into the server database.
     *
     * @param string $databaseURI  URI of Database to sync. Like
     *                             calendar, tasks, contacts or notes.
     *                             May include optional parameters:
     *                             tasks?options=ignorecompleted.
     * @param string $content      The actual data
     * @param string $contentType  Mimetype of $content
     * @param string $cuid         Only for server mode: Client ID ofthis entry.
     *                             Used for map.
     *
     * @return array  PEAR_Error or suid (Horde guid) of new entry
     */
    function addEntry($databaseURI, $content, $contentType, $cuid)
    {
        die ("Not implemented!");
    }

    /**
     * Replaces an entry in the server database.
     *
     * @param string $databaseURI  URI of Database to sync. Like
     *                             calendar, tasks, contacts or notes.
     *                             May include optional parameters:
     *                             tasks?options=ignorecompleted.
     * @param string $content      The actual data
     * @param string $contentType  Mimetype of $content
     * @param string $cuid         Client ID of this entry
     *
     * @return array  PEAR_Error or suid (Horde guid) of modified entry.
     */
    function replaceEntry($databaseURI, $content, $contentType, $cuid)
    {
        die ("Not implemented!");
    }

    /**
     * Deletes an entry from the server database.
     *
     * @param string $databaseURI URI of Database to sync. Like
     *                            calendar, tasks, contacts or notes.
     *                            May include optional parameters:
     *                            tasks?options=ignorecompleted.
     * @param string $cuid      Client ID of the entry
     *
     * @return boolean          true on success or false on failed (item not found)
     */
    function deleteEntry($databaseURI, $cuid)
    {
        die ("Not implemented!");
    }


    /** Checks the authorization and does a "login" on the backend if
     * necessary.
     * Returns true on auth accepted, false otherwise.
     * For some types of authentications (notably auth:basic) the username
     * gets extracted from the auth data and is then stored in username.
     * For security reason the caller must ensure that this is the username
     * that is used for the session, overriding any username specified in
     * &lt;LocName&gt;.
     *
     * Please note that checkAuthorization is only called on the first
     * sync message. On subsequent messages the login state is taken from
     * the state and no additional checkAuthorization is done.
     *
     * @param string username    username as provided in the SyncHdr.
     *                           May be overwritten by credData
     * @param string creadData   Auth data provided by Cred/Data in the SyncHdr.
     * @param string credFormat  Format of data as Cread/Meta/Format in the
     *                           SyncHdr. Typically 'b64'.
     * @param string credType    Auth type as provided by Cred/Meta/Type in the
     *                           SyncHdr. Typically 'syncml:auth-basic'
     *
     * @return boolean true on valid uri, false on invalid uri.
     */
    function checkAuthorization(&$username,$credData, $credFormat, $credType)
    {
        die ("Not implemented!");
    }

    /**
     * After a successful sync: store Sync anchors to allow two way sync
     * on next sync.
     * The backend has to store the parameters in its persistence engine
     * where user, syncDevideID and database are the keys while client and
     * server anchor ar the payload. See readSyncAnchors for retrival
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key for the sync
     *                                anchor.
     * @param string clientAnchorNext The client anchor as sent by the client.
     * @param string serverAnchorNext The anchor as used internally by the
     *                                server.
     */
    function writeSyncAnchors($databaseURI,
                              $clientAnchorNext, $serverAnchorNext)
    {
    }


    /**
     *
     * Reads the previously written sync anchors from the database
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key for the sync
     *                                anchor.
     * @return mixed                  array(clientanchor,serveranchor) as
     *                                stored in previous writeSyncAnchor
     *                                request. Or false if no data found.
     */
    function readSyncAnchors($databaseURI)
    {
    }

    /**
     * Create a map entries to map between server and client IDs.
     * If an entry already exists, it is overwritten.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param integer timestamp       Optional timestamp. This can be used to 'tag'
     *                                changes made in the backend during the sync
     *                                process. This allows to identify these and
     *                                ensure, that these changes are not replicated
     *                                back to the client (and thus duplicated).
     *                                See key concept "Changes and timestamps".
     */
    function createUidMap($databaseURI, $cuid, $suid, $ts=0)
    {
    }

    /**
     * Retrieves the Server ID for a given Client ID from the map.
     * All three parameters combined are the key to the map.
     * This function is used internally by the backend, typically by
     * deleteEntry and replaceEntry as these are invoked with a client id.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param string cuid             The client ID.
     *
     * @return mixed                  The server ID string or false if no
     *                                entry is found.
     *
     * @access private
     *
     */
    function getSuid($databaseURI, $cuid)
    {
    }

    /**
     * Retrieves the Client ID for a given Server ID from the map.
     * All three parameters combined are the key to the map.
     * This function is used internally by the backend, typically by
     * getServerChanges as this function is supposed to return client IDs
     * for changes and deletions.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param string suid             The server ID.
     *
     * @return mixed                  The client ID string or false if no
     *                                entry is found.
     *
     * @access private
     *
     */
    function getCuid($databaseURI, $suid)
    {
    }

    /**
     * Returns a timestamp stored in the map for a given Server ID.
     * The timestamp is the timestamp of the last change to this server ID
     * that was done inside a sync session (as a result of a change received
     * by the server). It's important to distinguish changes in the backend
     * a) made by the user during normal operation and
     * b) changes made by SyncML to reflect client updates.
     * When the server is sending its changes it is only allowed to send
     * type a). However the history feature in the backend my not know if
     * a change is of type a) or type b). So the timestamp is used to
     * differentiate between the two.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param string suid             The server ID.
     *
     * @return mixed                  The previously stored timestamp or false
     *                                if no entry is found.
     *
     * @access private
     *
     */
    function getChangeTS($databaseURI, $suid)
    {
    }


    /**
     * Erases all mapping entries for one user / syncDevideID / database
     * so a SlowSync really syncs everything properly and no old
     * mapping entries remain.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     */
    function eraseMap($databaseURI)
    {
    }

    /**
     * Logs a message in the backend.
     * This is internal server logging and no output for the user..
     *
     * @param mixed $message     Either a string or a PEAR_Error object.
     * @param string $file       What file was the log function called from
     *                           (e.g. __FILE__)?
     * @param integer $line      What line was the log function called from
     *                           (e.g. __LINE__)?
     * @param integer $priority  The priority of the message. One of:
     * <pre>
     * PEAR_LOG_EMERG
     * PEAR_LOG_ALERT
     * PEAR_LOG_CRIT
     * PEAR_LOG_ERR
     * PEAR_LOG_WARNING
     * PEAR_LOG_NOTICE
     * PEAR_LOG_INFO
     * PEAR_LOG_DEBUG
     * </pre>
     */
    function logMessage($message, $file = __FILE__, $line = __LINE__,
                        $priority = PEAR_LOG_INFO)
    {
        if($priority > $this->_logLevel)  {
            return;
        }

        // Internal logging to logtext
        if (is_string($this->_logtext)) {
            switch ($priority) {
            case PEAR_LOG_EMERG:
                $t = 'EMERG:  ';
                break;
            case PEAR_LOG_ALERT:
                $t = 'ALERT:  ';
                break;
            case PEAR_LOG_CRIT:
                $t = 'CIRT:   ';
                break;
            case PEAR_LOG_ERR:
                $t = 'ERR:    ';
                break;
            case PEAR_LOG_WARNING:
                $t = 'WARNING:';
                break;
            case PEAR_LOG_NOTICE:
                $t = 'NOTICE: ';
                break;
            case PEAR_LOG_INFO:
                $t = 'INFO:   ';
                break;
            case PEAR_LOG_DEBUG:
                $t = 'DEBUG:  ';
                break;
            default:
                $t = 'UNKNOWN:';
            }
            if (is_string($message)) {
                $t .= $message;
            } elseif(is_a($message, 'PEAR_Error')) {
                $t .= $message->message;
            }
            $this->_logtext .= $t . "\n";
        }
    }

    function logFile($type, $content, $isWBXML=false, $isSessionClose = false)
    {
        if (empty($this->_debugDir) || !$this->_debugFiles) {
            return;
        }

        switch ($type)
        {
            case SYNCML_LOGFILE_CLIENTMESSAGE:
                $filename = 'syncml_client_';
                $mode = 'wb';
                break;
            case SYNCML_LOGFILE_SERVERMESSAGE:
                $filename = 'syncml_server_';
                $mode = 'wb';
                break;
            case SYNCML_LOGFILE_DEVINF:
                $filename = 'devinf.txt';
                $mode = 'wb';
                break;
            case SYNCML_LOGFILE_DATA:
                $filename = 'data.txt';
                $mode = 'a';
                break;
            default:
                // Unkown type. Use $type as filename:
                $filename = $type;
                $mode = 'a';
                break;
        }

        if ($type === SYNCML_LOGFILE_CLIENTMESSAGE
                || $type === SYNCML_LOGFILE_SERVERMESSAGE) {
            $packetNum = @intval(file_get_contents($this->_debugDir . '/syncml.packetnum'));

            if (empty($packetNum)) {
                $packetNum = 10;
            }
            if ($isWBXML) {
                $filename .= $packetNum . '.wbxml';
            } else {
                $filename .= $packetNum . '.xml';
            }
        }

        /* Write file */
        $fp = @fopen($this->_debugDir . '/' . $filename, $mode);
        if ($fp) {
            @fwrite($fp, $content);
            @fclose($fp);
        }


        /* Increase packet number. */
        if ($type === SYNCML_LOGFILE_SERVERMESSAGE) {
           $this->logMessage('Finished at ' . date("Y-m-d H:i:s")
                               . '. Packet logged in '
                               . $this->_debugDir . '/' . $filename,
                                __FILE__, __LINE__, PEAR_LOG_DEBUG);

            $fp = @fopen($this->_debugDir . '/syncml.packetnum', 'w');
            if ($fp) {
                /* when one complete session is finished: go to next 10th */
                if ($isSessionClose) {
                    $packetNum +=  10 - $packetNum % 10;                } else {
                    $packetNum += 1;
                }
                fwrite($fp, $packetNum);
                fclose($fp);
            }

        }
    }

    /**
     * Cleanup function called after all message processing is
     * finished. Allows for things like closing db or flushing logs.
     * When running in test mode, tearDown must be called rather than close.
     */
    function close()
    {
        if (!empty($this->_debugDir)) {
            $f = @fopen($this->_debugDir . '/syncml_log.txt', 'a');
            if ($f) {
                fwrite($f, $this->_logtext . "\n");
                fclose($f);
            }
        }
    }


    /**
     * Returns the current timestamp in the same format as used
     * by getServerChanges.
     * Backends can use their own way to represent timestamps,
     * like unix epoch integers or UTC Datetime strings.
     *
     * @return mixed  a timestamp of the current time.
     */
    function getCurrentTimeStamp()
    {
        // Use unix epoch as default method for timestamps:
        return time();
    }

    /**
     *
     * Create a clean test environment in the backend.
     * Ensure there's a user with the given credentials
     * and an completly empty data store and map.
     *
     * @param string $user This user accout has to be created in the backend.
     * @param string $pwd  The password for user $user.
     *
     */
    function testSetup($user, $pwd)
    {
        die ("testsetup not implemented!");
    }

    /**
     * Tear down the test environment after the test is run.
     * Should remove the testuser created during testSetup and all its data.
     */
    function testTearDown()
    {
        die ("testTearDown not implemented!");
    }

    /** Normalize a databaseURI to a database name.
     * So _normalize('tasks?ignorecompleted') should return just tasks.
     */
    function _normalize($databaseURI)
    {
        return strtolower(basename(preg_replace('|\?.*$|', '', $databaseURI)));
    }
}
