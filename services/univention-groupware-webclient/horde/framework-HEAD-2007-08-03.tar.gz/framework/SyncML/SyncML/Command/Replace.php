<?php

require_once 'SyncML/Command.php';

/**
 * $Horde: framework/SyncML/SyncML/Command/Replace.php,v 1.15 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2003-2007 Anthony Mills <amills@pyramid6.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Anthony Mills <amills@pyramid6.com>
 * @since   Horde 3.0
 * @package SyncML
 */
class SyncML_Command_Replace extends SyncML_Command {

    function output($currentCmdID, &$output)
    {
        return $currentCmdID;
    }

}
