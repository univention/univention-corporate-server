<?php

require_once 'SyncML/Command.php';

/**
 * The SyncML_Command_Final class.
 *
 * $Horde: framework/SyncML/SyncML/Command/Final.php,v 1.27 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2003-2007 Karsten Fourmont <karsten@horde.org>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @author  Anthony Mills <amills@pyramid6.com>
 * @since   Horde 3.0
 * @package SyncML
 */
class SyncML_Command_Final extends SyncML_Command {

    function handleCommand()
    {
        // If the client hasn't sent us device info, request it now.
        // @TODO: only do this once, not in every msg if the client does not implement DevInf.
        $di = $_SESSION['SyncML.state']->getDeviceInfo();
        if (empty($di->_Man)) {
            $this->_outputHandler->outputGetDevInf();
        }

        $_SESSION['SyncML.state']->handleFinal($this->_outputHandler);
        $GLOBALS['backend']->logMessage('Received Final from client.', __FILE__, __LINE__, PEAR_LOG_DEBUG);
    }

}
