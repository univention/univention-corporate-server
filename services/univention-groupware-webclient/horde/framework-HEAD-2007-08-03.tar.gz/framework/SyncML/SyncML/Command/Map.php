<?php

require_once 'SyncML/Command.php';

/**
 * The SyncML_Map class provides a SyncML implementation of
 * the Map command as defined in SyncML Representation Protocol,
 * version 1.0.1 5.5.8.
 *
 * $Horde: framework/SyncML/SyncML/Command/Map.php,v 1.17 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2004-2007 Karsten Fourmont <karsten@horde.org>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @since   Horde 3.0
 * @package SyncML
 */
class SyncML_Command_Map extends SyncML_Command {


   function handleCommand()
    {

        // create Status response
        $this->_outputHandler->outputStatus($this->_cmdID,$this->_cmdName,
                                            RESPONSE_OK,
                                            $this->_targetLocURI,
                                            $this->_sourceLocURI);
    }

    /* Member variables and XML parsing functions */

    /**
     * @var string
     */
    var $_sourceLocURI;

    /**
     * @var string
     */
    var $_targetLocURI;

    var $_mapTarget;
    var $_mapSource;

    /**
     * Setter for property sourceURI.
     *
     * @param string $sourceURI  New value of property sourceURI.
     */
    function setSourceLocURI($sourceURI)
    {
        $this->_sourceURI = $sourceURI;
    }

    function getTargetLocURI()
    {
        return $this->_targetURI;
    }

    /**
     * Setter for property targetURI.
     *
     * @param string $targetURI  New value of property targetURI.
     */
    function setTargetURI($targetURI)
    {
        $this->_targetURI = $targetURI;
    }

    function startElement($uri, $element, $attrs)
    {
        parent::startElement($uri, $element, $attrs);

        switch (count($this->_Stack)) {
        case 2:
            if ($element == 'MapItem') {
                unset($this->_mapTarget);
                unset($this->_mapSource);
            }
            break;
        }
    }

    function endElement($uri, $element)
    {
        global $backend;
        if (!isset($this->_chars)) {
            $this->_chars = '';
        }

        switch (count($this->_Stack)) {
        case 1:
            $state = &$_SESSION['SyncML.state'];
            $sync = & $state->getSync($this->_targetLocURI);
            break;

        case 2:
            if ($element == 'MapItem') {
                $state = &$_SESSION['SyncML.state'];
                $sync = & $state->getSync($this->_targetLocURI);
                if (!$state->isAuthorized()) {
                    $backend->logMessage('Not Authorized in MapItem!',
                                         __FILE__, __LINE__, PEAR_LOG_ERR);
                } else {
                    // @TODO: move business logic to handleCommand
                    $sync->createUidMap($this->_targetLocURI,
                                        $this->_mapSource,
                                        $this->_mapTarget);
                }
            }
            break;

        case 3:
            if ($element == 'LocURI') {
                if ($this->_Stack[1] == 'Source') {
                    $this->_sourceLocURI = trim($this->_chars);
                } elseif ($this->_Stack[1] == 'Target') {
                    $this->_targetLocURI = trim($this->_chars);
                }
            }
            break;

        case 4:
            if ($element == 'LocURI') {
                if ($this->_Stack[2] == 'Source') {
                    $this->_mapSource = trim($this->_chars);
                } elseif ($this->_Stack[2] == 'Target') {
                    $this->_mapTarget = trim($this->_chars);
                }
            }
            break;
        }

        parent::endElement($uri, $element);
    }

}
