<?php

require_once 'SyncML/Command.php';

/**
 * The class SyncML_Command_SyncElement stores information from the Add,
 * Delete and Replace elements found inside a sync command.
 *
 * $Horde: framework/SyncML/SyncML/Command/SyncElement.php,v 1.12 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2005-2007 The horde project (www.horde.org)
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @since   Horde 3.0
 * @package SyncML
 */

/**
 * The class SyncML_Command_SyncElement stores information about
 * the items inside a sync element (Add|Delete|Replace).
 *
 * Instances of this class are created during the XML parsing by
 * SyncML_Command_Sync.
 *
 * @package SyncML
 */

class SyncML_SyncElement
{

    /**
     * Add, Delete or Replace, inherited from
     * SyncML_Command_SyncElement.
     */
    var $_elementType;

    var $_cuid;

    /**
     * Optional, may be provided by parent element or even not at all.
     */
    var $_contentType;

    var $_content;

    var $_cmdID;

    /**
     * ResponseCode to be sent as status response.
     * This is set when "processing" the item.
     */
    var $_responseCode;

    var $_size;

    /**
     * The Sync object for this element is part of.
     *
     * @var object SyncML_Sync
     */
    var $_sync;

    function SyncML_SyncElement(&$sync, $elementType, $cmdID, $size)
    {
        $this->_sync = &$sync;
        $this->_elementType = $elementType;
        $this->_cmdID = $cmdID;
        $this->_size = $size;
        $this->_cuid = null;
        $this->_contentType = null;
        $this->_content = '';

    }

    function getCuid()
    {
        return $this->_cuid;
    }

    function setCuid($cuid)
    {
        $this->_cuid = $cuid;
    }

    function getCmdID()
    {
        return $this->_cmdID;
    }

    function setCmdID($c)
    {
        $this->_cmdID = $c;
    }

    function getContent()
    {
        return $this->_content;
    }

    function addContent($c)
    {
        $this->_content .= $c;
    }

    function getContentType()
    {
        return $this->_contentType;
    }

    function setContentType($ct)
    {
        $this->_contentType = $ct;
    }

    function getElementType()
    {
        return $this->_elementType;
    }

    function getResponseCode()
    {
        return $this->_responseCode;
    }

    function setResponseCode($r)
    {
        $this->_responseCode = $r;
    }

    function getSize()
    {
        return $this->_size;
    }

    function &getSync()
    {
        return $this->_sync;
    }
}

