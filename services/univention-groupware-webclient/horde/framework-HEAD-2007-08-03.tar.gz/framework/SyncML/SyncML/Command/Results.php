<?php

require_once 'SyncML/Command/Put.php';

/**
 * $Horde: framework/SyncML/SyncML/Command/Results.php,v 1.24 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2003-2007 Anthony Mills <amills@pyramid6.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Nathan P Sharp
 * @since   Horde 3.0
 * @package SyncML
 */

// Currently SyncML_Command_Results behaves the same as SyncML_Command_Put.
// The only results we get are the same devinf as fort the Put command.

class SyncML_Command_Results extends SyncML_Command_Put {
}
