<?php

require_once 'SyncML/Command.php';

/**
 * The SyncML_SyncHdr class provides a SyncML implementation of
 * the SyncHdr as defined in SyncML Representation Protocol,
 *
 * $Horde: framework/SyncML/SyncML/Command/SyncHdr.php,v 1.3 2007/01/14 19:31:34 karsten Exp $
 *
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @since   Horde 3.0
 * @package SyncML
 */

class SyncML_Command_SyncHdr extends SyncML_Command
{

    function setupState()
    {
        $GLOBALS['backend']->sessionStart($this->_sourceURI,
                                          $this->_sessionID);

        // do we have a session state already or not?
        // Create or Get State
        if (!isset($_SESSION['SyncML.state'])) {
            // Create a new state if one does not already exist.
            $GLOBALS['backend']->logMessage('New session created: '
                              . session_id(),
                              __FILE__, __LINE__, PEAR_LOG_DEBUG);

            $_SESSION['SyncML.state'] = &new SyncML_State($this->_sourceURI,
                                                          $this->_locName,
                                                          $this->_sessionID);
        } else {
            $GLOBALS['backend']->logMessage('Existing session continued: '
                              . session_id(),
                              __FILE__, __LINE__, PEAR_LOG_DEBUG);
        }

        $_SESSION['SyncML.state']->setVersion($this->_version);
        $_SESSION['SyncML.state']->setMsgID($this->_msgID);

        $_SESSION['SyncML.state']->setTargetURI($this->_targetURI);
        $_SESSION['SyncML.state']->setSourceURI($this->_sourceURI);
        $_SESSION['SyncML.state']->setSessionID($this->_sessionID);

        if (!empty($this->_maxMsgSize)) {
            $_SESSION['SyncML.state']->setMaxMsgSize($this->_maxMsgSize);
        }
    }

    /* Member variables and XML parsing functions */

    /**
     * Defined in SyncML Representation Protocol, version 1.1 5.1.9. User name.
     *
     * @var string
     */
    var $_locName;

    /**
     * Defined in SyncML Representation Protocol, version 1.1 5.1.18
     *
     * @var string
     */
    var $_sessionID;

    /**
     * Defined in SyncML Representation Protocol, version 1.1.  Must be 1.0 (0)
     * or 1.1 (1) or 1.2 (2).
     *
     * @var string
     */
    var $_version;

    /**
     * Defined in SyncML Representation Protocol, version 1.1 5.1.12
     *
     * @var string
     */
    var $_msgID;

    /**
     * Defined in SyncML Representation Protocol, version 1.1 5.1.10
     *
     * @var string
     */
    var $_targetURI;

    /**
     * Defined in SyncML Representation Protocol, version 1.1 5.1.10, 5.1.20
     *
     * @var string
     */
    var $_sourceURI;

    var $_credData;

    var $_credFormat;

    var $_credType;

    var $_maxMsgSize;

    /* Getter methods */

    function getCredData()
    {
        return $this->_credData;
    }

    function getCredFormat()
    {
        return $this->_credFormat;
    }
    function getCredType()
    {
        return $this->_credType;
    }

    function getLocName()
    {
        return $this->_locName;
    }
    /** XML parsing function called on closing tag. Stores the data into
     *  the appropriate class member. No business logic in here, please!
     */
    function endElement($uri, $element)
    {

        switch (count($this->_Stack)) {
        case 2:
            if ($element == 'VerProto') {
                // </VerProto></SyncHdr></SyncML>
                if (trim($this->_chars) == 'SyncML/1.1') {
                    $this->_version = 1;
                } elseif (trim($this->_chars) == 'SyncML/1.2') {
                    $this->_version = 2;
                } else {
                    $this->_version = 0;
                }
            } elseif ($element == 'SessionID') {
                // </SessionID></SyncHdr></SyncML>
                $this->_sessionID = trim($this->_chars);
            } elseif ($element == 'MsgID') {
                // </MsgID></SyncHdr></SyncML>
                $this->_msgID = intval(trim($this->_chars));
            }
            break;

        case 3:
            if ($element == 'LocURI') {
                if ($this->_Stack[1] == 'Source') {
                    // </LocURI></Source></SyncHdr></SyncML>
                    $this->_sourceURI = trim($this->_chars);
                } elseif ($this->_Stack[1] == 'Target') {
                    // </LocURI></Target></SyncHdr></SyncML>
                    $this->_targetURI = trim($this->_chars);
                }
            } elseif ($element == 'LocName') {
                if ($this->_Stack[1] == 'Source') {
                    // </LocName></Source></SyncHdr></SyncML>
                    $this->_locName = trim($this->_chars);
                }
            } elseif ($element == 'Data') {
                    // </Data></Cred></SyncHdr></SyncML>
                if ($this->_Stack[1] == 'Cred') {
                    $this->_credData = trim($this->_chars);
                }
            } elseif ($element == 'MaxMsgSize') {
                // </MaxMsgSize></Meta></SyncHdr></SyncML>
                $this->_maxMsgSize = intval($this->_chars);
            }
            break;

        case 4:
            if ($this->_Stack[1] == 'Cred') {
                if ($element == 'Format') {
                    // </Format></Meta></Cred></SyncHdr></SyncML>
                    $this->_credFormat = trim($this->_chars);
                } elseif ($element == 'Type') {
                    // </Type></Meta></Cred></SyncHdr></SyncML>
                    $this->_credType = trim($this->_chars);
                }
            }
            break;
        }

        parent::endElement($uri, $element);
    }

}
