<?php

require_once 'SyncML/Command.php';
require_once 'SyncML/Command/SyncElement.php';

/**
 * $Horde: framework/SyncML/SyncML/Command/Sync.php,v 1.50 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2005-2007 Karsten Fourmont <karsten@horde.org>
 *
 * The command handler for the &gt;Sync&lt; command is the central
 * class to dispatch sync messages.
 *
 * During parsing of the received XML, the actual sync commands (Add,
 * Replace, Delete) from the client are stored in the _syncElements
 * attribute.  When the output method of SyncML_Command_Sync is
 * called, these elements are processed and the resulting status
 * messages created.
 *
 * Then the server modifications are sent back to the client by the
 * handleSync method which is called from within the output method.
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @since   Horde 3.0
 * @package SyncML
 */
class SyncML_Command_Sync extends Syncml_Command
{

   function handleCommand()
    {
        // Handle unauthorized first.
        if (!$_SESSION['SyncML.state']->isAuthorized()) {
            $this->_outputHandler->outputStatus($this->_cmdID,$this->_cmdName,
                                            RESPONSE_INVALID_CREDENTIALS);
                return;
        }


        $state =& $_SESSION['SyncML.state'];

        $sync =& $state->getSync($this->_targetURI);
        $sync->addSyncReceived();

        if (!is_object($sync)) {
            $GLOBALS['backend']->logMessage('No sync object found for URI = '
                                                . $this->_targetURI,
                                            __FILE__, __LINE__, PEAR_LOG_ERR);
            // @TODO: create meaningful status code here.
        }

        /* @TODO: Check: do we send a status for every sync or only once after
         * one sync is completed?
         * SE K750 expects Status response to be sent before Sync output
         * by server is produced.
         */
        $this->_outputHandler->outputStatus($this->_cmdID,$this->_cmdName,
                                            RESPONSE_OK,
                                            $this->_targetURI,
                                            $this->_sourceURI);

        // Here's where client modifications are processed:
        $device = $state->getDevice();
        $omit = $device->omitIndividualSyncStatus();
        foreach ($this->_syncElements as $item) {
            $result = $sync->handleClientSyncItem($this->_outputHandler, $item);
            if (!$omit) {
                $this->_outputStatus($item);
            }
        }

        // Last item had <MoreData> Tag: produce appropriate response
        if ($this->_itemMoreData) {
            $this->_outputHandler->outputStatus(
                    $_SESSION['SyncML.state']->curSyncItem->getCmdID(),
                    $_SESSION['SyncML.state']->curSyncItem->getElementType(),
                    RESPONSE_CHUNKED_ITEM_ACCEPTED_AND_BUFFERED,
                    '',
                    $_SESSION['SyncML.state']->curSyncItem->getCuid()
            );
            // @TODO: check if we have to send Alert NEXT_MESSAGE here!
        }

      }

    /**
     * Creates the &lt;Status&gt; response for one Add|Replace|Delete
     * SyncElement
     *
     * @param SyncML_SyncElement element The element for which the status is
     *                                   to be created.
     */
    function _outputStatus($element)
    {
    // @TODO: produce valid status
        $this->_outputHandler->outputStatus($element->getCmdID(),
                                            $element->getElementType(),
                                            $element->getResponseCode(),
                                            '',
                                            $element->getCuid());
    }
    /* Member variables and XML parsing functions */

    /**
     * @var array
     */
    var $_syncElements = array();

    /**
     * contacts, calendar, tasks or notes
     *
     * @var string
     */
    var $_targetURI;

    // per Element data:
    var $_contentType;
    var $_itemCmdID;
    var $_elementType;

    // temp data during sync item creation:
    var $_curItem;
    var $_itemMoreData; // flag
    var $_itemSize;

    function getTargetURI()
    {
        return $this->_targetURI;
    }

    function startElement($uri, $element, $attrs)
    {
        parent::startElement($uri, $element, $attrs);

        switch (count($this->_Stack)) {
        case 2:
            if ($element == 'Replace' || $element == 'Add' || $element == 'Delete') {
                $this->_contentType = '';
                $this->_elementType = $element;
                $this->_itemSize = null;
            }
            break;
        case 3:
            if ($element == 'Item') {
                if (isset($_SESSION['SyncML.state']->curSyncItem)) {
                    // copy from state in case of MoreData:
                    $this->_curItem =  $_SESSION['SyncML.state']->curSyncItem;
                    // Set CmdID to current the CmdId, not the initial one
                    // from the first message.
                    $this->_curItem->setCmdID($this->_itemCmdID);
                    unset($_SESSION['SyncML.state']->curSyncItem);
                } else {
                    $this->_curItem = new SyncML_SyncElement($_SESSION['SyncML.state']->getSync($this->_targetURI),
                                            $this->_elementType,
                                            $this->_itemCmdID,
                                            $this->_itemSize);
                }
                $this->_itemMoreData = false;
            }
        }
    }

    function endElement($uri, $element)
    {

        switch (count($this->_Stack)) {
        case 3:
            if ($element == 'LocURI' && !isset($this->_currentSyncElement)) {
                if ($this->_Stack[1] == 'Source') {
                    $this->_sourceURI = trim($this->_chars);
                } elseif ($this->_Stack[1] == 'Target') {
                    $this->_targetURI = trim($this->_chars);
                }
            } elseif ($element == 'Item') {
                if ($this->_itemMoreData) {
                    // Store to continue in next session:
                    $_SESSION['SyncML.state']->curSyncItem = $this->_curItem;
                } else {
                    // finished: store to syncElements[]
                    $ct = $this->_curItem->getContentType();
                    if (empty($ct)) {
                        $this->_curItem->setContentType($this->_contentType);
                    }

                    $this->_syncElements[] = $this->_curItem;
                    // @TODO: check if size matches strlen(content) if size >0
                    // (esp. in case of MoreData)
                    unset($this->_curItem);
                }
            } elseif ($element == 'CmdID') {
                $this->_itemCmdID = trim($this->_chars);
            }
            break;
        case 4:
            if ($element == 'Type') {
                $this->_contentType = trim($this->_chars);
            } elseif ($element == 'Data') {
                $this->_curItem->addContent($this->_chars);
            } elseif ($element == 'MoreData') {
                $this->_itemMoreData = true;
            } elseif ($element == 'Size') {
                $this->_itemSize = $this->_chars;
            }
            // }
            break;

        case 5:
            if ($element == 'LocURI') {
                if ($this->_Stack[3] == 'Source') {
                    $this->_curItem->setCuid(trim($this->_chars));
                } elseif ($this->_Stack[3] == 'Target') {
                    // Not used: we ignore "suid proposals" from
                    // client.
                }
            }
            break;

        case 6:
            if ($element == 'Type') {
                $this->_curItem->setContentType(trim($this->_chars));
            }
            break;
        }

        parent::endElement($uri, $element);
    }

}
