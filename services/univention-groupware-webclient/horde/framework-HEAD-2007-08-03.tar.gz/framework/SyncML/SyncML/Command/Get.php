<?php

require_once 'SyncML/Command.php';

/**
 * The SyncML_Command_Get class.
 *
 * This class responds to a client get request and returns the DevInf
 * information for the SyncML server.
 *
 * $Horde: framework/SyncML/SyncML/Command/Get.php,v 1.36 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2003-2007 Karsten Fourmont <fourmont@gmx.de>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <fourmont@gmx.de>
 * @author  Anthony Mills <amills@pyramid6.com>
 * @since   Horde 3.0
 * @package SyncML
 */
class SyncML_Command_Get extends SyncML_Command {

    function handleCommand()
    {
        // create Status response
        $this->_outputHandler->outputStatus($this->_cmdID,$this->_cmdName,
                                            RESPONSE_OK,
                                            $_SESSION['SyncML.state']->getDevInfURI());
         

        if (!$_SESSION['SyncML.state']->isAuthorized()) {
            return;
        }
        
        $this->_outputHandler->outputDevInf($this->_cmdID);

    }

}
