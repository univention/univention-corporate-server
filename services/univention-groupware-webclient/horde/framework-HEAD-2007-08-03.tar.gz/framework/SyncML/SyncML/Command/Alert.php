<?php

require_once 'SyncML/Command.php';

/**
 * The SyncML_Alert class provides a SyncML implementation of
 * the Alert command as defined in SyncML Representation Protocol,
 * version 1.1 5.5.2.
 *
 * $Horde: framework/SyncML/SyncML/Command/Alert.php,v 1.48 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2003-2007 Anthony Mills <amills@pyramid6.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @author  Anthony Mills <amills@pyramid6.com>
 * @since   Horde 3.0
 * @package SyncML
 */
class SyncML_Command_Alert extends SyncML_Command {


    function handleCommand()
    {
        // Handle unauthorized first.
        if (!$_SESSION['SyncML.state']->isAuthorized()) {
            $this->_outputHandler->outputStatus($this->_cmdID,$this->_cmdName,
                                            RESPONSE_INVALID_CREDENTIALS);
                return;
        }

        // Handle NEXT_MESSAGE Alert by doing nothing
        // (except OK status response):
        // Exception for Funambol: here we produce the output only after
        // an explicit ALERT_NEXT_MESSAGE.
        if($this->_alert == ALERT_NEXT_MESSAGE) {
            $this->_outputHandler->outputStatus($this->_cmdID,$this->_cmdName,
                                            RESPONSE_OK);
            // @TODO: create a getDevice()->sentyncDataLate() method instead of this:
            if (is_a($_SESSION['SyncML.state']->getDevice(), 'SyncML_Device_sync4j')) {
                /* Now send client changes to server: this will produce the
                * <sync> response: */
                $sync = & $_SESSION['SyncML.state']->getSync($this->_targetLocURI);
                if ($sync) {
                    $sync->createSyncOutput($this->_outputHandler);
                }
            }
            return;
        }

        $database = $this->_targetLocURI;
        if ( !$GLOBALS['backend']->isValidDatabaseURI($database)) {
            // @TODO: proper error handling!
            return;
        }

        $clientAnchorNext = $this->_metaAnchorNext;

        if ($this->_alert == ALERT_TWO_WAY
                || $this->_alert == ALERT_ONE_WAY_FROM_CLIENT
                || $this->_alert == ALERT_ONE_WAY_FROM_SERVER) {
            // Check if we have information about previos sync:
              $r = $GLOBALS['backend']->readSyncAnchors($this->_targetLocURI);

            if (is_array($r)) {
                // info about previous successful sync sessions found:
                list($clientlast, $serverAnchorLast) = $r;
                $GLOBALS['backend']->logMessage(sprintf('previous sync found for database: %s; client-ts: %s', $database, $clientlast), __FILE__, __LINE__, PEAR_LOG_DEBUG);

                // Check if anchor sent from client matches our own stored data:
                if ($clientlast == $this->_metaAnchorLast) {
                    // Last Sync Anchor matches, TwoWaySync will do.
                    $anchormatch = true;
                    $GLOBALS['backend']->logMessage("SyncML: Anchor match, TwoWaySync since " . $clientlast, __FILE__, __LINE__, PEAR_LOG_DEBUG);
                } else {
                    // server and client have different anchors: enforce Slow/Refresh Sync
                    $GLOBALS['backend']->logMessage('client requested sync with anchor ts ' . $this->_metaAnchorLast . ' but server ' . 'has timestamp' . $clientlast . ' on file. Enforcing SlowSync', __FILE__, __LINE__, PEAR_LOG_INFO);
                    $anchormatch = false;
                    $clientlast = 0;
                }
            } else {
                // no info about previous Sync: use Slow or Refresh Sync
                $GLOBALS['backend']->logMessage(sprintf('SyncML: No info about previous syncs found for device %s and database %s',
                                             $_SESSION['SyncML.state']->getSourceURI(),
                                             $database),
                                     __FILE__, __LINE__, PEAR_LOG_DEBUG);
                $clientlast = 0;
                $serverAnchorLast = 0;
                $anchormatch = false;
            }
        } else {
            // slowsync requested, no anchor check required:
            $anchormatch =true;
        }
        // determine synctype and status response code:
        switch ($this->_alert) {
        case ALERT_TWO_WAY:
            $synctype = $anchormatch ? ALERT_TWO_WAY : ALERT_SLOW_SYNC;
            $response = $anchormatch ? RESPONSE_OK : RESPONSE_REFRESH_REQUIRED;
            break;
        case ALERT_SLOW_SYNC:
            $synctype = ALERT_SLOW_SYNC;
            $response = $anchormatch ? RESPONSE_OK : RESPONSE_REFRESH_REQUIRED;
            break;
        case ALERT_ONE_WAY_FROM_CLIENT:
            $synctype = $anchormatch ? ALERT_ONE_WAY_FROM_CLIENT : ALERT_REFRESH_FROM_CLIENT;
            $response = $anchormatch ? RESPONSE_OK : RESPONSE_REFRESH_REQUIRED;
            break;
        case ALERT_REFRESH_FROM_CLIENT:
            $synctype = ALERT_REFRESH_FROM_CLIENT;
            $response = $anchormatch ? RESPONSE_OK : RESPONSE_REFRESH_REQUIRED;
            break;
        case ALERT_ONE_WAY_FROM_SERVER:
            $synctype = $anchormatch ? ALERT_ONE_WAY_FROM_SERVER : ALERT_REFRESH_FROM_SERVER;
            $response = $anchormatch ? RESPONSE_OK : RESPONSE_REFRESH_REQUIRED;
            break;
        case ALERT_REFRESH_FROM_SERVER:
            $synctype = ALERT_REFRESH_FROM_SERVER;
            $response = $anchormatch ? RESPONSE_OK : RESPONSE_REFRESH_REQUIRED;
            break;
        case ALERT_RESUME:
            // @TODO: Suspend and Resume is not supported yet
            $synctype = ALERT_SLOW_SYNC;
            $response = RESPONSE_REFRESH_REQUIRED;
        default:
            $GLOBALS['backend']->logMessage('Unknown sync type:' . $this->_alert,
                                            __FILE__, __LINE__, PEAR_LOG_ERR);
        }


        // Now set interval to retrieve server changes from:
        // defined by ServerAnchor [Last,Next]
        if($synctype == ALERT_TWO_WAY
                || $synctype == ALERT_ONE_WAY_FROM_CLIENT
                || $synctype == ALERT_ONE_WAY_FROM_SERVER) {
            $serverAnchorNext = $GLOBALS['backend']->getCurrentTimeStamp();
        } else {
            $serverAnchorLast = 0;
            // erase existing Map:
            if(($anchormatch && CONFIG_DELETE_MAP_ON_REQUESTED_SLOWSYNC) ||
                (!$anchormatch && CONFIG_DELETE_MAP_ON_ANCHOR_MISMATCH_SLOWSYNC)) {
                $GLOBALS['backend']->eraseMap($this->_targetLocURI);
            }
        }
        $serverAnchorNext = $GLOBALS['backend']->getCurrentTimeStamp();

        // Now Create the actual Sync object (if it does not exist yet:)
        $sync = & $_SESSION['SyncML.state']->getSync($this->_targetLocURI);
        if (!$sync) {
            $GLOBALS['backend']->logMessage('Create new sync for '
                                  . $this->_targetLocURI
                                  .  '; synctype=' . $synctype,
                                 __FILE__, __LINE__, PEAR_LOG_DEBUG);

            $sync = &new SyncML_Sync($synctype,
                                     $this->_targetLocURI,
                                     $this->_sourceLocURI,
                                     $serverAnchorLast, $serverAnchorNext,
                                     $clientAnchorNext);

            $_SESSION['SyncML.state']->setSync($this->_targetLocURI, $sync);
        }

        $this->_outputHandler->outputStatus($this->_cmdID, $this->_cmdName,
                                            $response,
                                            $this->_targetLocURI,
                                            $this->_sourceLocURI,
                                            $this->_metaAnchorNext,
                                            $this->_metaAnchorLast);

       $this->_outputHandler->outputAlert($synctype,
                    $sync->getClientLocURI(),
                    $sync->getServerLocURI(),
                    $sync->getServerAnchorLast(),
                    $sync->getServerAnchorNext());
    }

    /* Member variables and XML parsing functions */

    /**
     * @var integer
     */
    var $_alert;

    /**
     * @var string
     */
    var $_sourceLocURI;

    /**
     * @var string
     */
    var $_targetLocURI;

    /**
     * @var string
     */
    var $_metaAnchorNext;

    /**
     * @var integer
     */
    var $_metaAnchorLast;

    /**
     * Creates a new instance of Alert.
     */
    function SyncML_Command_Alert()
    {
    }

    /**
     * Setter for property sourceURI.
     *
     * @param string $sourceURI  New value of property sourceURI.
     */
    function setSourceLocURI($sourceURI)
    {
        $this->_sourceURI = $sourceURI;
    }

    function getTargetLocURI()
    {
        return $this->_targetURI;
    }

    /**
     * Setter for property targetURI.
     *
     * @param string $targetURI  New value of property targetURI.
     */
    function setTargetURI($targetURI)
    {
        $this->_targetURI = $targetURI;
    }

    function startElement($uri, $element, $attrs)
    {
        parent::startElement($uri, $element, $attrs);

    }

    function endElement($uri, $element)
    {
        if (!isset($this->_chars)) {
            $this->_chars = '';
        }
        switch (count($this->_Stack)) {
        case 2:
            if ($element == 'Data') {
                $this->_alert = intval(trim($this->_chars));
            }
            break;

        case 4:
            if ($element == 'LocURI') {
                if ($this->_Stack[2] == 'Source') {
                    $this->_sourceLocURI = trim($this->_chars);
                } elseif ($this->_Stack[2] == 'Target') {
                    $this->_targetLocURI = trim($this->_chars);
                }
            }
            break;

        case 5:
            if ($element == 'Next') {
                $this->_metaAnchorNext = trim($this->_chars);
            } elseif ($element == 'Last') {
                $this->_metaAnchorLast = trim($this->_chars);
            }
            break;
        }

        parent::endElement($uri, $element);
    }

}
