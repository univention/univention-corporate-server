<?php

require_once 'SyncML/Command.php';
require_once 'SyncML/Constants.php';

/**
 * $Horde: framework/SyncML/SyncML/Command/Status.php,v 1.28 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2003-2007 Karsten Fourmont <fourmont@gmx.de>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <fourmont@gmx.de>
 * @since   Horde 3.0
 * @package SyncML
 */
class SyncML_Command_Status extends SyncML_Command {

    // @TODO: parse and handle status data sent from the client!
    function handleCommand()
    {
        
    }
}
