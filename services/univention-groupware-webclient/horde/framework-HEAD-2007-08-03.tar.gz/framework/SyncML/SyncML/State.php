<?php

require_once 'SyncML/DeviceInfo.php';
require_once 'SyncML/Device.php';
require_once 'SyncML/Constants.php';

/**
 * The SyncML_State class provides a SyncML state object.
 *
 * $Horde: framework/SyncML/SyncML/State.php,v 1.44 2007/06/27 17:23:02 jan Exp $
 *
 * Copyright 2003-2007 Anthony Mills <amills@pyramid6.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Anthony Mills <amills@pyramid6.com>
 * @since   Horde 3.0
 * @package SyncML
 */
class SyncML_State {

    /**
     * Session id of this session.
     */
    var $_sessionID;

    /**
     * Id of current message.
     */
    var $_msgID;

    /**
     * The target URI as sent by the client. This is normally the URL
     * of the Horde rpc server. However the client is free to send
     * anything: sync4j for example does not send the path part.
     */
    var $_targetURI;

    /**
     * The source URI as sent by the client. Can be used to identify
     * the client; the session id is constructed mainly from this
     * data.
     */
    var $_sourceURI;

    /**
     * 0 for syncml 1.0, 1 for syncml 1.1.
     */
    var $_version;

    /**
     * Username used to auth with the backend.
     */
    var $_locName;

    /**
     * Password used to auth with the backend.
     */
    var $_password;

    /**
     * True means that this session has authenticated successfully.
     */
    var $_isAuthorized;

    /**
     * Namespace information.
     */
    var $_uri;

    /**
     * Namespace information.
     */
    var $_uriMeta;

    /**
     * Namespace information.
     */
    var $_uriDevInf;

    var $_wbxml; // boolean

    var $_maxMsgSize;

    var $_syncs = array();

    /**
     * The SyncML_Device class defined in Device.php.
     * Name of the appropriate device driver.
     */
    var $_deviceDriver;

    /**
     * Device info provided by the SyncML DevInf data. Mainly used by
     * the SyncML_Device class.
     */
    var $_deviceInfo;

    /**
     * Current Sync item sent from client. Must be stored in state
     * when one element is split into multiple message packets
     */

    var $curSyncItem;

    /**
     * set true if the client sends a Final but we are not finished with the
     * current package and thus can't final this package yet.
     */

    var $delayedFinal;
    /**
     * Creates a new instance of SyncML_State.
     */
    function SyncML_State($sourceURI, $locName, $sessionID)
    {
        $this->setSourceURI($sourceURI);
        $this->setLocName($locName);
        $this->setSessionID($sessionID);

        $this->isAuthorized = false;

        // Create empty dummy device info. Will be replaced with real
        // DevInf information if they are transferred.
        $this->_deviceInfo = &new SyncML_DeviceInfo();

        /* allow very big messages unless told otherwise: */
        $this->setMaxMsgSize(1000000000);

        $this->delayedFinal = false;
    }

    function setDeviceInfo($di)
    {
        $this->_deviceInfo = $di;
    }

    function &getDeviceInfo()
    {
        return $this->_deviceInfo;
    }

    function getSessionID()
    {
        return $this->_sessionID;
    }

    function getLocName()
    {
        return $this->_locName;
    }

    /* Alias for getLocName */
    function getUser()
    {
        return $this->_locName;
    }

    function getSourceURI()
    {
        return $this->_sourceURI;
    }

    function getTargetURI()
    {
        return $this->_targetURI;
    }

    function getVersion()
    {
        return $this->_version;
    }

    function getMsgID()
    {
        return $this->_msgID;
    }

    function setWBXML($wbxml)
    {
        $this->_wbxml = $wbxml;
    }

    function isWBXML()
    {
        return !empty($this->_wbxml);
    }

    function setMaxMsgSize($s)
    {
        $this->_maxMsgSize = $s;
    }

    function getMaxMsgSize()
    {
        return $this->_maxMsgSize;
    }

    /**
     * Returns the <DevInf><VerDTD> content based on the protocol version.
     */
    function getVerDTD()
    {
        switch ($this->getVersion()) {
            case 0:
                return '1.0';
            case 1:
                return '1.1';
            case 2:
                return '1.2';
            default:
                return '1.0';
        }
    }

    /**
     * Returns the DevInf URI based on the protocol version.
     */
    function getDevInfURI()
    {
        switch ($this->getVersion()) {
            case 0:
                return './devinf10';
            case 1:
                return './devinf11';
            case 2:
                return './devinf12';
            default:
                return './devinf10';
        }
    }

    /**
     * Returns the protocol name based on the protocol version.
     */
    function getProtocolName()
    {
        switch ($this->getVersion()) {
            case 0:
                return 'SyncML/1.0';
            case 1:
                return 'SyncML/1.1';
            case 2:
                return 'SyncML/1.2';
            default:
                return 'SyncML/1.0';
        }
    }

    /**
     * Setter for property msgID.
     *
     * @param string $msgID  New value of property msgID.
     */
    function setMsgID($msgID)
    {
        $this->_msgID = $msgID;
    }

    /**
     * Setter for property locName.
     *
     * @param string $locName  New value of property locName.
     */
    function setLocName($locName)
    {
        $this->_locName = $locName;
    }

    function setPassword($password)
    {
        $this->_password = $password;
    }

    function setSourceURI($sourceURI)
    {
        $this->_sourceURI = $sourceURI;
    }

    function setTargetURI($targetURI)
    {
        $this->_targetURI = $targetURI;
    }

    function setVersion($version)
    {
        $this->_version = $version;

        if ($version == 1) {
            $this->_uri = NAME_SPACE_URI_SYNCML_1_1;
            $this->_uriMeta = NAME_SPACE_URI_METINF_1_1;
            $this->_uriDevInf = NAME_SPACE_URI_DEVINF_1_1;
        } elseif ($version == 2) {
            $this->_uri = NAME_SPACE_URI_SYNCML_1_2;
            $this->_uriMeta = NAME_SPACE_URI_METINF_1_2;
            $this->_uriDevInf = NAME_SPACE_URI_DEVINF_1_2;
        } else {
            $this->_uri = NAME_SPACE_URI_SYNCML;
            $this->_uriMeta = NAME_SPACE_URI_METINF;
            $this->_uriDevInf = NAME_SPACE_URI_DEVINF;
        }
    }

    function setSessionID($sessionID)
    {
        $this->_sessionID = $sessionID;
    }

    function isAuthorized()
    {
        return $this->_isAuthorized;
    }

    function setSync($target, &$sync)
    {
        $this->_syncs[$target] = &$sync;
    }

    function &getSync($target)
    {
        if (isset($this->_syncs[$target])) {
            return $this->_syncs[$target];
        } else {
            $false = false;
            return $false;
        }
    }

    function &getSyncs()
    {
        return $this->_syncs;
    }

    function getURI()
    {
        /*
         * The non WBXML devices (notably P900 and Sync4j seem to get confused
         * by a <SyncML xmlns="syncml:SYNCML1.1"> element. They require
         * just <SyncML>. So don't use an ns for non wbxml devices.
         */
        if ($this->isWBXML() || $this->getVersion()>0) {
            return $this->_uri;
        } else {
            return '';
        }
    }
    function getURIMeta()
    {
        return $this->_uriMeta;
    }

    function getURIDevInf()
    {
        return $this->_uriDevInf;
    }

    function &getDevice()
    {
        if (empty($this->_deviceDriver)) {

            $si = $this->getSourceURI();
            $di = $this->getDeviceInfo();

            if (stristr($si, 'sync4j') !== false
                    || stristr($si, 'sc-pim') !== false
                    || stristr($si, 'fol-') !== false
                    || stristr($si, 'fwm-') !== false) {
                    $this->_deviceDriver = 'Sync4j';
            } elseif (!empty($di->_Man) && stristr($di->_Man, 'Sony Ericsson') !== false) {
                $this->_deviceDriver = 'P800';
            /* The Morola A1000 has a similar (UIQ) firmware as the P800: */
            } elseif (!empty($di->_Mod) && stristr($di->_Mod, 'A1000') !== false) {
                $this->_deviceDriver = 'P800';
            } elseif (!empty($di->_Man) && stristr($di->_Man, 'synthesis') !== false) {
                $this->_deviceDriver = 'Synthesis';
            } elseif (!empty($di->_Man) && stristr($di->_Man, 'nokia') !== false) {
                $this->_deviceDriver = 'Nokia';
            } elseif (stristr($si, 'fmz-thunderbird-plugin') !== false) {
                $this->_deviceDriver = 'Sync4JMozilla';
            } else {
                $this->_deviceDriver = 'default' ; // Use default
            }
        }
        return SyncML_Device::singleton($this->_deviceDriver);

    }

    /**
     * Check if there are any pending elements that have not been sent to due
     * to message sitze restrictions. These will be sent int the next msg.
     *
     */
    function hasPendingElements()
    {

        if (is_array($this->_syncs)) {
            foreach ($this->_syncs as $sync) {
                if ($sync->hasPendingElements()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Returns all syncs which have pending elements left.
     * Returns an array of TargetLocURIs which can be used
     * as a key in getSync calls.
     */
    function getPendingSyncs()
    {
        $r = array();
        if (is_array($this->_syncs)) {
            foreach ($this->_syncs as $target => $sync) {
                if ($sync->hasPendingElements()) {
                    $r[] = $target;
                }
            }
        }
        return $r;
    }

    /**
     * Returns true if all syncs are in completed state or no syncs
     *  are present.
     *
     */
    function isAllSyncsComplete()
    {
        if (is_array($this->_syncs)) {
            foreach ($this->_syncs as $target => $sync) {
                if (!$sync->isComplete()) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * A final tag is propagated here and then further to every sync.
     * This allow the sync objects to determine if they are complete.
     */
    function handleFinal(&$output)
    {
        if (is_array($this->_syncs)) {
            foreach (array_keys($this->_syncs) as $t) {
                $this->_syncs[$t]->handleFinal($output);
            }
        }
    }
}
