<?php
/**
 * SyncML Backend for the Horde Application framework.
 *
 * The backend provides the following functionality:
 *
 * 1) handling of the actual data, i.e.
 *    a) add/replace/delete entries to and retrieve entries from the
 *       backend
 *    b) retrieve history to find out what entries have been changed
 * 2) managing of the map between cliend IDs and server IDs
 * 3) store information about sync anchors (timestamps) of previous
 *    successfuls sync sessions
 * 4) session handling
 * 5) authorization
 * 6) logging
 *
 * Copyright 2005-2007 Karsten Fourmont <karsten@horde.org>
 *
 * See the enclosed file COPYING for license information (LGPL). If you did not
 * receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * $Horde: framework/SyncML/SyncML/Backend/Horde.php,v 1.6 2007/07/25 20:49:23 karsten Exp $
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @package SyncML
 */


/* Key concepts

 * 1) Database URIs and Databases

 * 2) Suid and Guid mapping

 * 3) Sync Anchors

 * 4) Changes and Timestamps

*/

require_once 'Horde/Auth.php';

class SyncML_Backend_Horde extends SyncML_Backend {

    var $_datatree;

    var $_db;
    /**
     * Constructor; creates the datatree and initializes the log.
     *
     */
    function SyncML_Backend_Horde($params)
    {
        parent::SyncML_Backend($params);

        $driver = $GLOBALS['conf']['datatree']['driver'];
        $params = Horde::getDriverConfig('datatree', $driver);
        $params = array_merge($params, array('group' => 'horde.syncml'));

        $this->_datatree =& DataTree::singleton($driver, $params);

        require_once 'DB.php';
        $this->_db = &DB::connect($GLOBALS['conf']['sql']);

        /* Set DB portability options. */
        if (is_a($this->_db, 'DB_common')) {
            switch ($this->_db->phptype) {
            case 'mssql':
                $this->_db->setOption('portability', DB_PORTABILITY_LOWERCASE | DB_PORTABILITY_ERRORS | DB_PORTABILITY_RTRIM);
                break;
            default:
                $this->_db->setOption('portability', DB_PORTABILITY_LOWERCASE | DB_PORTABILITY_ERRORS);
            }
        }

    }

    /**
     * Sets the charset. All data passed to the backend uses this
     * charset and data returned from the backend must use this
     * charset, too.
     */
    function setCharset($c)
    {
        parent::setCharset($c);
        NLS::setCharset($this->getCharset());
        String::setDefaultCharset($this->getCharset());
    }

    function setUser($user)
    {
        global $conf;
        parent::setUser($user);
        if ($this->_backendMode == SYNCML_BACKENDMODE_TEST) {
            /* After a session the user gets automatically logged out. */
            /* So we have to login again: */
            $auth = &Auth::singleton($conf['auth']['driver']);
            $auth->setAuth($this->_user, array());
        }
    }

    /**
     * Starts a php session with the given session id.
     *
     * @param string $session_id The session_id to use.
     */
    function sessionStart($syncDeviceID, $sessionId, $backendMode = SYNCML_BACKENDMODE_SERVER)
    {
        // not extra colons when used as key in datatree:
        $syncDeviceID = str_replace(':', '_', $syncDeviceID);

        // Only the server needs to start a session:
        if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
            // Reload the Horde SessionHandler if necessary.
            Horde::setupSessionHandler();
        }
        parent::sessionStart($syncDeviceID, $sessionId, $backendMode);
    }

    /**
     * Get entries that have been modified in the server database.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     * @param integer $from_ts        Start timestamp.
     * @param integer $to_ts          Exclusive end timestamp. Not yet
     *                                implemented.
     * @param array  &$adds           Output array: assoc array of
     *                                adds suid=>0
     * @param array  &$mods           Output array: assoc array of
     *                                modifications suid=>cuid
     * @param array  &$dels           Output array: assoc array of
     *                                deletions suid=>cuid
     * @return mixed                  true on success or a PEAR_Error object.
     */

    function getServerChanges($databaseURI,$from_ts, $to_ts,
                              &$adds, &$mods, &$dels)
    {

        global $registry;

        $adds= $mods = $dels = array();
        $database = $this->_normalize($databaseURI);

        // Handle additions:
        if ($from_ts == 0) {
            // Return all db entries directly rather than bother
            // history:
            $data = $registry->call($database. '/list',
                                    array(SyncML_Backend_Horde::getParameter($databaseURI,'source')));
        } else {
            $data = $registry->call($database. '/listBy', array('action' => 'add', 'timestamp' => $from_ts,
                   'source' => SyncML_Backend_Horde::getParameter($databaseURI,'source')));
        }

        if (is_a($data, 'PEAR_Error')) {
            $this->logMessage("SyncML: $database/listBy failed for add:"
                              . $data->getMessage(),
                              __FILE__, __LINE__, PEAR_LOG_WARNING);
            return $data;
        }

        foreach ($data as $suid) {
            // Only server needs to check for client sent entries:
            if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                if($from_ts == 0) {
                    // SlowSync: Ignore all entries where there already is
                    // a map entry.
                    $cuid = $this->getCuid($database, $suid);
                    if($cuid) {
                        $this->logMessage("slowsync-add: $suid ignored", __FILE__, __LINE__, PEAR_LOG_DEBUG);
                        continue;
                    }
                }
                $suid_ts = $registry->call($database . '/getActionTimestamp', array($suid, 'add', 'source' => SyncML_Backend_Horde::getParameter($databaseURI,'source')));
                $sync_ts = $this->getChangeTS($database, $suid);
                if ($sync_ts && $sync_ts >= $suid_ts) {
                    // Change was done by us upon request of client.
                    // Don't mirror that back to the client.
                    $this->logMessage("add: $suid ignored, came from client", __FILE__, __LINE__, PEAR_LOG_DEBUG);
                    continue;
                }
            }

            $adds[$suid] = 0;
        }

        // On SlowSync: everything is sent as add, no need to send
        // modifications or deletions. So we are finished here:
        if ($from_ts == 0) {
            return true;
        }

        // Handle changes:
        $data = $registry->call($database. '/listBy', array('action' => 'modify', 'timestamp' => $from_ts, 'source' => SyncML_Backend_Horde::getParameter($databaseURI,'source')));
        if (is_a($data, 'PEAR_Error')) {
            $this->logMessage("SyncML: $database/listBy failed for modify:"
                              . $data->getMessage(),
                              __FILE__, __LINE__, PEAR_LOG_WARNING);
            return $data;
        }

        foreach ($data as $suid) {
            // Only server needs to check for client sent entries and update map.
            if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                $suid_ts = $registry->call($database . '/getActionTimestamp', array($suid, 'modify', SyncML_Backend_Horde::getParameter($databaseURI,'source')));
                $sync_ts = $this->getChangeTS($database, $suid);
                if ($sync_ts && $sync_ts >= $suid_ts) {
                    // Change was done by us upon request of client.
                    // Don't mirror that back to the client.
                    $this->logMessage("change: $suid ignored, came from client", __FILE__, __LINE__, PEAR_LOG_DEBUG);
                    continue;
                }
                $cuid = $this->getCuid($database, $suid);
                if (!$cuid) {
                    $this->logMessage("Unable to create change for $suid: client-id not found in map.",
                                      __FILE__, __LINE__, PEAR_LOG_WARNING);
                    // $mods[$suid] = null;
                } else {
                    $mods[$suid] = $cuid;
                }
            } else {
                    $mods[$suid] = $suid;
            }
        }


        // Handle deletions.
        $data = $registry->call($database. '/listBy', array('action' => 'delete', 'timestamp' => $from_ts, 'source' => SyncML_Backend_Horde::getParameter($databaseURI,'source')));

        if (is_a($data, 'PEAR_Error')) {
            $this->logMessage("SyncML: $database/listBy failed for delete:"
                              . $data->getMessage(),
                              __FILE__, __LINE__, PEAR_LOG_WARNING);
            return data;
        }

        foreach ($data as $suid) {
            // Only server needs to check for client sent entries.
            if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                $suid_ts = $registry->call($database. '/getActionTimestamp', array($suid, 'delete', SyncML_Backend_Horde::getParameter($databaseURI,'source')));
                $sync_ts = $this->getChangeTS($database, $suid);
                if ($sync_ts && $sync_ts >= $suid_ts) {
                    // Change was done by us upon request of client.
                    // Don't mirror that back to the client.
                    $this->logMessage("SyncML: delete $suid ignored, came from client", __FILE__, __LINE__, PEAR_LOG_DEBUG);
                    continue;
                }
                $cuid = $this->getCuid($database, $suid);
                if (!$cuid) {
                    $this->logMessage("Unable to create delete for $suid: locid not found in map",
                                      __FILE__, __LINE__, PEAR_LOG_WARNING);
                    continue;
                }

                $dels[$suid] = $cuid;
            } else {
                $dels[$suid] = $suid;
            }
        }


        return true;

    }

    /**
     * Retrieves an entry from the backend.
     *
     * @param string $databaseURI URI of Database to sync. Like
     *                            calendar, tasks, contacts or notes.
     *                            May include optional parameters:
     *                            tasks?options=ignorecompleted.
     * @param string $suid       Server unique id of the entry: for horde
     *                           this is the guid.
     * @param string contentType Content-Type: the mime type in which the
     *                           function shall return the data
     *
     * @return mixed             A string with the data entry or
     *                           or a PEAR_Error object.
     */
    function retrieveEntry($databaseURI, $suid, $contentType)
    {
        return $GLOBALS['registry']->call(
                $this->_normalize($databaseURI) . '/export',
                array('guid' => $suid, 'contentType' => $contentType));
    }

    /**
     * Adds an entry into the server database.
     *
     * @param string $databaseURI  URI of Database to sync. Like
     *                             calendar, tasks, contacts or notes.
     *                             May include optional parameters:
     *                             tasks?options=ignorecompleted.
     * @param string $content      The actual data
     * @param string $contentType  Mimetype of $content
     * @param string $cuid         Only for server mode: Client ID ofthis entry.
     *                             Used for map.
     *
     * @return array  PEAR_Error or suid (Horde guid) of new entry
     */
    function addEntry($databaseURI, $content, $contentType, $cuid = null)
    {
        global $registry;

        $database = $this->_normalize($databaseURI);

        $suid = $registry->call($database. '/import',
                                array($content, $contentType, SyncML_Backend_Horde::getParameter($databaseURI,'source')));


        if (!is_a($suid, 'PEAR_Error')) {
            $this->logMessage("add to server db $database cuid $cuid -> suid $suid", __FILE__, __LINE__, PEAR_LOG_DEBUG);
            $ts = $registry->call($database. '/getActionTimestamp', array($suid, 'add', SyncML_Backend_Horde::getParameter($databaseURI,'source')));
            if (!$ts) {
                $this->logMessage('Unable to find add-ts for ' . $suid . ' at ' . $ts, __FILE__, __LINE__, PEAR_LOG_ERR);
            }
            // Only server needs to do a cuid<->suid map
            if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                $this->createUidMap($database, $cuid, $suid, $ts);
            }
        } else {
            // Failed import. Maybe the entry is already there. Check if
            // a guid is returned:
            if ($suid->getDebugInfo()) {
                $suid = $suid->getDebugInfo();
                $this->logMessage('Add: Already exists with suid=' . $suid,
                                         __FILE__, __LINE__, PEAR_LOG_DEBUG);
                if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                    $this->createUidMap($database, $cuid, $suid, 0);
                }
            }

        }

        return $suid;
    }

    /**
     * Deletes an entry from the server database.
     *
     * @param string $databaseURI URI of Database to sync. Like
     *                            calendar, tasks, contacts or notes.
     *                            May include optional parameters:
     *                            tasks?options=ignorecompleted.
     * @param string $cuid      Client ID of the entry
     *
     * @return boolean          true on success or false on failed (item not found)
     */
    function deleteEntry($databaseURI, $cuid)
    {
        global $registry;

        $database = $this->_normalize($databaseURI);
        // Find server ID for this entry:
        // Only server needs to do a cuid<->suid map
        if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
            $suid = $this->getSuid($database, $cuid);
        } else {
            $suid = $cuid;
        }

        if (!is_a($suid, 'PEAR_Error')) {
            $r = $registry->call($database. '/delete', array($suid));
            $ts = $registry->call($database . '/getActionTimestamp', array($suid, 'delete'));
            // We can't remove the mapping entry as we need to keep
            // the timestamp information.

            // Only server needs to do a cuid<->suid map
            if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                $this->createUidMap($database, $cuid, $suid, $ts);
            }
        } else {
            return false;
        }

        if (is_a($r, 'PEAR_Error')) {
            return false;
        }

        return true;
    }

    /**
     * Replaces an entry in the server database.
     *
     * @param string $databaseURI  URI of Database to sync. Like
     *                             calendar, tasks, contacts or notes.
     *                             May include optional parameters:
     *                             tasks?options=ignorecompleted.
     * @param string $content      The actual data
     * @param string $contentType  Mimetype of $content
     * @param string $cuid         Client ID of this entry
     *
     * @return array  PEAR_Error or suid (Horde guid) of modified entry.
     */
    function replaceEntry($databaseURI, $content, $contentType, $cuid)
    {
        global $registry;

        $database = $this->_normalize($databaseURI);

        // Only server needs to do a cuid<->suid map
        if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
            $suid = $this->getSuid($database, $cuid);
        } else {
            $suid = $cuid;
        }
        $this->logMessage("replace in db $database cuid $cuid suid $suid", __FILE__, __LINE__, PEAR_LOG_DEBUG);

        if ($suid) {
            // Entry exists: replace current one.
            $ok = $registry->call($database . '/replace',
                                  array($suid, $content, $contentType));
            if (is_a($ok, 'PEAR_Error')) {
                return $ok;
            }
            $ts = $registry->call($database . '/getActionTimestamp', array($suid, 'modify', SyncML_Backend_Horde::getParameter($databaseURI,'source')));
            // Only server needs to do a cuid<->suid map
            if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                $this->createUidMap($database, $cuid, $suid, $ts);
            }
        } else {
            return PEAR::raiseError('No map entry found');
        }

        return $suid;
    }

    /** Checks the authorization and does a "login" on the backend if
     * necessary.
     * Returns true on auth accepted, false otherwise.
     * For some types of authentications (notably auth:basic) the username
     * gets extracted from the auth data and is then stored in username.
     * For security reason the caller must ensure that this is the username
     * that is used for the session, overriding any username specified in
     * &lt;LocName&gt;.
     *
     * @param string username    username as provided in the SyncHdr.
     *                           May be overwritten by credData
     * @param string creadData   Auth data provided by Cred/Data in the SyncHdr.
     * @param string credFormat  Format of data as Cread/Meta/Format in the
     *                           SyncHdr. Typically 'b64'.
     * @param string credType    Auth type as provided by Cred/Meta/Type in the
     *                           SyncHdr. Typically 'syncml:auth-basic'
     *
     * @return boolean true on valid uri, false on invalid uri.
     */
    function checkAuthorization(&$username,$credData, $credFormat, $credType)
    {
        if (empty($credData) || empty($credType)) {
            return false;
        }

        switch ($credType) {
        case 'syncml:auth-basic':
            list($username,$pwd) = explode(':', base64_decode($credData),2);
            $this->logMessage('checking auth for user=' . $username,
                              __FILE__, __LINE__, PEAR_LOG_DEBUG);
            // empty passwords result in errors for some auth backends:
            // so don't call the auth backend in this case
            if ($pwd === '') {
                return false;
            }
            $auth = &Auth::singleton($GLOBALS['conf']['auth']['driver']);
            return $auth->authenticate($username,
                                        array('password' => $pwd));
        case 'syncml:auth-md5':
            /* syncml:auth-md5 only transfers hash values of passwords.
             * Currently the syncml:auth-md5 hash scheme is not supported
             * by the Horde Auth backend. So we can't use horde to do
             * authentication. Instead here is a very crude direct manual hook:
             * To allow authentication for a user 'dummy' with password 'sync',
             * run
             * php -r 'print base64_encode(pack("H*",md5("dummy:sync")));'
             * from the command line. Then create an entry like
             *  'dummy' => 'ZD1ZeisPeQs0qipHc9tEsw==' in the users array below,
             * where the value is the command line output.
             * This user/password combination is then accepted for md5-auth.
             */
            $users = array(
                  // example for user dummy with pass pass:
                  // 'dummy' => 'ZD1ZeisPeQs0qipHc9tEsw=='
                          );
            if (empty($users[$username])) {
                return false;
            }

            //@TODO: nonce may be specified by client. Use it then.
            $nonce = '';
            if (base64_encode(pack('H*',md5($users[$username] . ':' . $nonce)))
                    === $credData) {
                $auth = &Auth::singleton($GLOBALS['conf']['auth']['driver']);
                $auth->setAuth($username, $credData);
                return true;
            }
            return false;
            break;
        default:
            $this->logMessage('unsupported auth type ' . $credType,
                              __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }
    }

    /**
     * After a successful sync: store Sync anchors to allow two way sync
     * on next sync.
     * The backend has to store the parameters in its persistence engine
     * where user, syncDdeviceID and database are the keys while client and
     * server anchor ar the payload. See readSyncAnchors for retrival
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key for the sync
     *                                anchor.
     * @param string clientAnchorNext The client anchor as sent by the client.
     * @param string serverAnchorNext The anchor as used internally by the
     *                                server.
     */
    function writeSyncAnchors($databaseURI, $clientAnchorNext, $serverAnchorNext)
    {
        $database = $this->_normalize($databaseURI);

        $s = $this->_user . ':' . $this->_syncDeviceID . ':' . $database;

        $info = &new DataTreeObject($s);
        $info->set('ClientAnchor', $clientAnchorNext);
        $info->set('ServerAnchor', $serverAnchorNext);
        if ($this->_datatree->exists($info)) {
            $this->_datatree->updateData($info);
        } else {
            $this->_datatree->add($info);
        }
    }


    /**
     *
     * Reads the previously written sync anchors from the database
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key for the sync
     *                                anchor.
     * @return mixed                  array(clientanchor,serveranchor) as
     *                                stored in previous writeSyncAnchor
     *                                request. Or false if no data found.
     */
    function readSyncAnchors($databaseURI)
    {
        $database = $this->_normalize($databaseURI);

        $ob = $this->_datatree->getObject($this->_user . ':' . $this->_syncDeviceID . ':' . $database);
        if (!is_a($ob, 'DataTreeObject')) {
            return false;
        }

        $clientlast = $ob->get('ClientAnchor');

        /* In older versions we stored clientlast in an array: */
        if (is_array($clientlast)) {
            $clientlast = $clientlast[$database];
        }

        $serverlast = $ob->get('ServerAnchor');

        /* In older versions we stored clientlast in an array: */
        if (is_array($serverlast)) {
            $serverlast = $serverlast[$database];
        }

        return array($clientlast, $serverlast);
    }

    /**
     * Create a map entries to map between server and client IDs.
     * If an entry already exists, it is overwritten.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param integer timestamp       Optional timestamp. This can be used to 'tag'
     *                                changes made in the backend during the sync
     *                                process. This allows to identify these and
     *                                ensure, that these changes are not replicated
     *                                back to the client (and thus duplicated).
     *                                See key concept "Changes and timestamps".
     */
    function createUidMap($databaseURI, $cuid, $suid, $timestamp = 0)
    {
        $database = $this->_normalize($databaseURI);

        // Check if entry exists. If not insert, otherwise update.
        if ($this->getSuid($databaseURI, $cuid) == false) {
            $r = $this->_db->query('INSERT INTO horde_syncml_map '
                . ' (syncml_syncpartner,syncml_db,syncml_uid,syncml_cuid,syncml_suid,syncml_timestamp) VALUES ('
                . $this->_db->quote(strval($this->_syncDeviceID)) . ','
                . $this->_db->quote(strval($database)) . ','
                . $this->_db->quote(strval($this->_user)) . ','
                . $this->_db->quote(strval($cuid)) . ','
                . $this->_db->quote(strval($suid)) . ','
                . intval($timestamp)
                . ')');
        } else {
            $r = $this->_db->query('UPDATE horde_syncml_map '
                . ' SET syncml_suid = '
                . $this->_db->quote(strval($suid))
                . ' ,syncml_timestamp = '
                . $this->_db->quote(strval($timestamp))
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote(strval($this->_syncDeviceID))
                . ' AND syncml_db = '
                . $this->_db->quote(strval($database))
                . ' AND syncml_uid='
                . $this->_db->quote(strval($this->_user))
                . ' AND syncml_cuid = '
                . $this->_db->quote(strval($cuid))
                );
        }
        if ($this->_checkForError($r)) {
            return $r;
        }
        return true;
    }

    /**
     * Retrieves the Server ID for a given Client ID from the map.
     * All three parameters combined are the key to the map.
     * This function is used internally by the backend, typically by
     * deleteEntry and replaceEntry as these are invoked with a client id.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param string cuid             The client ID.
     *
     * @return mixed                  The server ID string or false if no
     *                                entry is found.
     *
     * @access private
     *
     */
    function getSuid($databaseURI, $cuid)
    {
        $database = $this->_normalize($databaseURI);

        $r = $this->_db->getOne('SELECT syncml_suid FROM horde_syncml_map '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote(strval($this->_syncDeviceID))
                . ' AND syncml_db = '
                . $this->_db->quote(strval($database))
                . ' AND syncml_uid='
                . $this->_db->quote(strval($this->_user))
                . ' AND syncml_cuid = '
                . $this->_db->quote(strval($cuid))
                );
        $this->_checkForError($r);

        if (!empty($r)) {
            return $r;
        }
        return false;
    }

    /**
     * Retrieves the Client ID for a given Server ID from the map.
     * All three parameters combined are the key to the map.
     * This function is used internally by the backend, typically by
     * getServerChanges as this function is supposed to return client IDs
     * for changes and deletions.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param string suid             The server ID.
     *
     * @return mixed                  The client ID string or false if no
     *                                entry is found.
     *
     * @access private
     *
     */
    function getCuid($databaseURI, $suid)
    {
        $database = $this->_normalize($databaseURI);

        $r = $this->_db->getOne('SELECT syncml_cuid FROM horde_syncml_map '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote(strval($this->_syncDeviceID))
                . ' AND syncml_db = '
                . $this->_db->quote(strval($database))
                . ' AND syncml_uid='
                . $this->_db->quote(strval($this->_user))
                . ' AND syncml_suid = '
                . $this->_db->quote(strval($suid))
                );

        $this->_checkForError($r);

        if (!empty($r)) {
            return $r;
        }
        return false;
    }

    /**
     * Returns a timestamp stored in the map for a given Server ID.
     * The timestamp is the timestamp of the last change to this server ID
     * that was done inside a sync session (as a result of a change received
     * by the server). It's important to distinguish changes in the backend
     * a) made by the user during normal operation and
     * b) changes made by SyncML to reflect client updates.
     * When the server is sending its changes it is only allowed to send
     * type a). However the history feature in the backend my not know if
     * a change is of type a) or type b). So the timestamp is used to
     * differentiate between the two.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param string suid             The server ID.
     *
     * @return mixed                  The previously stored timestamp or false
     *                                if no entry is found.
     *
     * @access private
     *
     */
    function getChangeTS($databaseURI, $suid)
    {
        $database = $this->_normalize($databaseURI);

        $r = $this->_db->getOne('SELECT syncml_timestamp FROM horde_syncml_map '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote(strval($this->_syncDeviceID))
                . ' AND syncml_db = '
                . $this->_db->quote(strval($database))
                . ' AND syncml_uid='
                . $this->_db->quote(strval($this->_user))
                . ' AND syncml_suid = '
                . $this->_db->quote(strval($suid))
                );
        $this->_checkForError($r);

        if (!empty($r)) {
            return $r;
        }
        return false;
    }

    /**
     * Erases all mapping entries for one user / syncDeviceID / database
     * so a SlowSync really syncs everything properly and no old
     * mapping entries remain.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     */
    function eraseMap($databaseURI)
    {
        $database = $this->_normalize($databaseURI);
        $r = $this->_db->query($q = 'DELETE FROM horde_syncml_map '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote(strval($this->_syncDeviceID))
                . ' AND syncml_db = '
                . $this->_db->quote(strval($database))
                . ' AND syncml_uid='
                . $this->_db->quote(strval($this->_user))
                );

        $GLOBALS['backend']->logMessage('erase map:' . $q,__FILE__, __LINE__, PEAR_LOG_DEBUG);

        $this->_checkForError($r);
    }

    /**
     * Logs a message in the backend.
     * This is internal server logging and no output for the user..
     *
     * @param mixed $message     Either a string or a PEAR_Error object.
     * @param string $file       What file was the log function called from
     *                           (e.g. __FILE__)?
     * @param integer $line      What line was the log function called from
     *                           (e.g. __LINE__)?
     * @param integer $priority  The priority of the message. One of:
     * <pre>
     * PEAR_LOG_EMERG
     * PEAR_LOG_ALERT
     * PEAR_LOG_CRIT
     * PEAR_LOG_ERR
     * PEAR_LOG_WARNING
     * PEAR_LOG_NOTICE
     * PEAR_LOG_INFO
     * PEAR_LOG_DEBUG
     * </pre>
     */
    function logMessage($message, $file = __FILE__, $line = __LINE__,
                        $priority = PEAR_LOG_INFO)
    {
        // Internal logging to logtext
        parent::logMessage($message, $file, $line, $priority);

        // Logging to Horde log:
        if (is_string($message)) {
            $message = "SyncML: " . $message;
        }
        Horde::logMessage($message, $file, $line, $priority);
    }

    /**
     * Cleanup function called after all message processing is
     * finished. Allows for things like closing db or flushing logs.
     */
    function close()
    {
        parent::Close();
    }


    //  Internal Horde_Backend functions that are not part of the backend api.


   /**
     * Checks if the parameter is a PEAR_Error object and if so
     * log the error.
     *
     * @param mixed  $o    An object or value to check.
     * @return mixed       The error object if an error has been passed or
     *                     false if no error has been passed.
     */
    function _checkForError($o)
    {
        if( is_a($o,'PEAR_Error')) {
            $this->logMessage($o);
            //var_dump($o); die("DB Error!");
            return $o;
        }
        return false;
    }

    /**
     *
     * Create a clean test environment in the backend.
     * Ensure there's a user with the given credentials
     * and an empty data store.
     *
     * @param string $user This user accout has to be created in the backend.
     * @param string $pwd  The password for user $user.
     *
     */
    function testSetup($user, $pwd)
    {
        $this->_user = $user;

        global $conf;

        if (empty($pwd)) {
            $pwd = rand() . rand();
        }

        /* Get an Auth object. */
        $auth = &Auth::singleton($conf['auth']['driver']);
        if (is_a($auth, 'PEAR_Error')) {
            Horde::fatal($auth, __FILE__, __LINE__);
        }
        // make this user an admin for the time beeing to allow
        // deletion of user data:
        $conf['auth']['admins'][] =$user;

        /* Always remove test user first. */
        if ($auth->exists($user)) {
            /* We need to be logged in to call removeUserData. */
            /* Otherwise we run into permission issues. */
            $auth->setAuth($user, array());
            $o = $auth->removeUserData($user);
            //if (is_a($o, 'PEAR_Error')) {
            //    Horde::fatal($o, __FILE__, __LINE__);
            //}
            $o = $auth->removeUser($user);
        }

        $o =$auth->addUser($user, array('password' => $pwd));
        if (is_a($o, 'PEAR_Error')) {
            Horde::fatal($o, __FILE__, __LINE__);
        }
        $auth->setAuth($user, array());

        /* Delete syncml data from datatree storage. */
        $driver = $GLOBALS['conf']['datatree']['driver'];
        $params = Horde::getDriverConfig('datatree', $driver);
        $params = array_merge($params, array('group' => 'syncml'));

        $dt = &DataTree::singleton($driver, $params);

        $o = $dt->remove($user, true);
        //if (is_a($o, 'PEAR_Error')) {
        //    Horde::fatal($o, __FILE__, __LINE__);
        //}
    }

    /**
     * Tear down the test environment after the test is run.
     * Should remove the testuser created during testSetup and all its data.
     */
    function testTearDown()
    {
        global $conf;
        /* Get an Auth object. */
        $auth = &Auth::singleton($conf['auth']['driver']);

        /* We need to be logged in to call removeUserData. */
        /* Otherwise we run into permission issues. */
        $auth->setAuth($this->_user, array());

        print "\nCleaning up: removing test user data and test user...";
        $o = $auth->removeUserData($this->_user);
        $o = $auth->removeUser($this->_user);

        /* Delete syncml data from datatree storage. */
        $driver = $GLOBALS['conf']['datatree']['driver'];
        $params = Horde::getDriverConfig('datatree', $driver);
        $params = array_merge($params, array( 'group' => 'syncml.' ));

        $dt = &DataTree::singleton($driver, $params);

        $dt->remove($this->_user, true);

        print "OK\n";
    }


    /** Normalize a databaseURI to a database name.
     * So _normalize('tasks?ignorecompleted') should return just tasks.
     */
    function _normalize($databaseURI)
    {
        $database = parent::_normalize($databaseURI);
        /* Convert some commonly encountered types to the
         * appropriate horde service names:
         */
        switch($database) {
        case 'contacts':
        case 'contact':
        case 'card':
        case 'scard':
            return 'contacts';
        case 'calendar':
        case 'event':
        case 'events':
        case 'cal':
        case 'scal':
            return 'calendar';
        case 'notes':
        case 'memo':
        case 'note':
        case 'snote':
            return 'notes';
        case 'tasks':
        case 'task':
        case 'stask':
            return 'tasks';
        default:
            return $database;
        }
    }

    /** extracts an HTTP GET like parameter from an url.
     * getParameter('test?q=1','q') == 1
     * @access: static
     */
    function getParameter($url,$parameter, $default = null)
    {
        if (preg_match('|[&\?]' . $parameter . '=([^&]*)|', $url, $m)) {
            return $m[1];
        }
        return $default;
    }

}
