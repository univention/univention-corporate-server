<?php
/**
 * Generic SQL based SyncML Backend.
 * This can be used as a starting point for an custom backe nd implementation.
 *
 * The backend provides the following functionality:
 *
 * 1) handling of the actual data, i.e.
 *    a) add/replace/delete entries to and retrieve entries from the
 *       backend
 *    b) retrieve history to find out what entries have been changed
 * 2) managing of the map between cliend IDs and server IDs
 * 3) store information about sync anchors (timestamps) of previous
 *    successfuls sync sessions
 * 4) session handling
 * 5) authorization
 * 6) logging
 *
 * $Horde: framework/SyncML/SyncML/Backend/Sql.php,v 1.4 2007/06/27 17:48:32 jan Exp $
 *
 * Copyright 2006-2007 Karsten Fourmont <karsten@horde.org>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @package SyncML
 */

require_once('MDB2.php');


/*
The SQL Database must contain five tables as created by the following mysql script.

-- DROP DATABASE syncml;
CREATE DATABASE syncml;

GRANT SELECT,INSERT, UPDATE,DELETE ON syncml.* TO syncml@localhost IDENTIFIED BY 'insertpasswordhere';
FLUSH PRIVILEGES;


USE syncml;

CREATE TABLE syncml_data(
    syncml_id            VARCHAR(64),
    syncml_db            VARCHAR(64),
    syncml_uid           VARCHAR(64),
    syncml_data          TEXT,
    syncml_contenttype   VARCHAR(255),
    syncml_created_ts    INTEGER DEFAULT 0,
    syncml_modified_ts   INTEGER DEFAULT 0
);

CREATE TABLE syncml_map(
    syncml_syncpartner VARCHAR(64),
    syncml_db          VARCHAR(64),
    syncml_uid         VARCHAR(64),
    syncml_cuid        VARCHAR(64),
    syncml_suid        VARCHAR(64),
    syncml_timestamp   INTEGER
);

CREATE INDEX syncml_cuid_idx ON syncml_map (syncml_syncpartner,syncml_db,syncml_uid,syncml_cuid);
CREATE INDEX syncml_suid_idx ON syncml_map (syncml_syncpartner,syncml_db,syncml_uid,syncml_suid);

CREATE TABLE syncml_anchors(
    syncml_syncpartner   VARCHAR(64),
    syncml_db            VARCHAR(64),
    syncml_uid           VARCHAR(64),
    syncml_clientanchor  VARCHAR(255),
    syncml_serveranchor  VARCHAR(255)
);

CREATE TABLE syncml_suidlist(
    syncml_syncpartner    VARCHAR(64),
    syncml_db             VARCHAR(64),
    syncml_uid            VARCHAR(64),
    syncml_suid           VARCHAR(255)
);

CREATE TABLE syncml_uids(
    syncml_uid      VARCHAR(64),
    syncml_password VARCHAR(255)
);


 */

/**
 */
class SyncML_Backend_Sql extends SyncML_Backend {

    var $_db;

    /**
     * Constructor.
     *
     * @param array $params: an assoc array with parameters. In addition to
     *                       those supported by the SyncML_Backend class
     *                       one more parameter is needed to specify the
     *                       the database connection:
     *                       'dsn' => connection dsn.
     */
    function SyncML_Backend_Sql($params)
    {
        parent::SyncML_Backend($params);

        $this ->_db = &MDB2::connect($params['dsn']);
        if (is_a($this->_db, 'PEAR_Error')) {
            $this->logMessage($this->_db,
                              __FILE__, __LINE__, PEAR_LOG_ERR);
        }
    }

    /** Checks if $databaseURI is a valid database URI than can be synced with
     * this backend.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *
     * @return boolean      true on valid uri, false on invalid uri.
     */
    function isValidDatabaseURI($databaseURI)
    {
        $database = $this->_normalize($databaseURI);
        switch(strtolower($database)) {
            case 'tasks';
            case 'calendar';
            case 'notes';
            case 'contacts';
            case 'events':
            case 'memo':
                return true;
            default:
                $msg = 'Invalid db uri: ' . $databaseURI
                        . '. Try tasks, calendar, notes or contacts.';
                $this->logMessage('Invalid Database: ' . $msg,
                                  __FILE__, __LINE__, PEAR_LOG_ERR);
                return false;
        }
    }

    /**
     * Get entries that have been modified in the server database.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     * @param integer $from_ts        Start timestamp.
     * @param integer $to_ts          Exclusive end timestamp. Not yet
     *                                implemented.
     * @param array  &$adds           Output array: assoc array of
     *                                adds suid=>0 (cuid=>0 for client mode)
     * @param array  &$mods           Output array: assoc array of
     *                                modifications suid=>cuid
     *                                (cuid=>cuid for client mode)
     * @param array  &$dels           Output array: assoc array of
     *                                deletions suid=>cuid
     *                                (cuid=>cuid for client mode)
     * @return mixed                  true on success or a PEAR_Error object.
     */

    function getServerChanges($databaseURI,$from_ts, $to_ts,
                              &$adds, &$mods, &$dels)
    {
        $database = $this->_normalize($databaseURI);

        $adds = $mods = $dels = array();
        // Handle additions:
        $data = $this->_db->queryAll($q='SELECT syncml_id, syncml_created_ts from syncml_data '
                . 'WHERE syncml_db='
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                . ' AND syncml_created_ts>='
                . $this->_db->quote($from_ts, 'integer'). ' AND '
                . 'syncml_created_ts <'
                . $this->_db->quote($to_ts, 'integer'));
        if ($this->_checkForError($data)) {
            return $data;
        }

        foreach($data as $d) {
            $suid = $d[0];
            $suid_ts = $d[1];
            $sync_ts = $this->getChangeTS($databaseURI, $suid);
            if ($sync_ts && $sync_ts >= $suid_ts) {
                // Change was done by us upon request of client.
                // Don't mirror that back to the client.
                $this->logMessage("add: $suid ignored, came from client", __FILE__, __LINE__, PEAR_LOG_DEBUG);
                continue;
            }

            $adds[$suid] = 0;
        }

        // Only compile changes on delta sync:
        if ($from_ts>0) {
            // Handle replaces. With this very we might get IDs that are
            // already in the adds array but that's ok: The calling code
            // takes care to ignore these.
            $data = $this->_db->queryAll('SELECT syncml_id, syncml_modified_ts from syncml_data '
                    .'WHERE syncml_db='
                    . $this->_db->quote($database, 'text')
                    . ' AND syncml_uid='
                    . $this->_db->quote($this->_user, 'text')
                    . ' AND syncml_modified_ts>='
                    . $this->_db->quote($from_ts, 'integer'). ' AND '
                    . 'syncml_modified_ts <'
                    . $this->_db->quote($to_ts, 'integer'));
            if ($this->_checkForError($data)) {
                return $data;
            }
            foreach($data as $d) {
                // Only the server needs to check the change ts do identify
                // client sent changes.
                if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                    $suid = $d[0];
                    $suid_ts = $d[1];
                    $sync_ts = $this->getChangeTS($databaseURI, $suid);
                    if ($sync_ts && $sync_ts >= $suid_ts) {
                        // Change was done by us upon request of client.
                        // Don't mirror that back to the client.
                        $this->logMessage("change: $suid ignored, came from client", __FILE__, __LINE__, PEAR_LOG_DEBUG);
                        continue;
                    }
                    $mods[$suid] = $this->getCuid($databaseURI, $suid);
                } else {
                    $mods[$d[0]] = $d[0];
                }
            }
        }

        // Handle deletions:
        // We assume stupid a backend datastore (syncml_data) where
        // deleted items are simply "gone" from the datastore. So we need
        // to do our own bookkeeping to identify entries that have been
        // deleted since the last sync run.
        // This is done by the _trackDeletions helper function: we feed
        // it with a current list of all suids and get
        // the ones missing (and thus deleted) in return.
        $data = $this->_db->queryCol('SELECT syncml_id from syncml_data WHERE syncml_db='
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                );
        if ($this->_checkForError($data)) {
            return $data;
        }

        // Get deleted items and store current items:
        // Only use the deleted information on delta sync. On initial slowsync
        // we just need to call _trackDeletes once to init the list.

        $data = $this->_trackDeletes($databaseURI, $data);
        if ($this->_checkForError($data)) {
            return $data;
        }
        if ($from_ts>0) {
            foreach($data as $suid) {
                // Only the server needs to handle the cuid suid map:
                if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                    $dels[$suid] = $this->getCuid($databaseURI, $suid);
                } else {
                    $dels[$suid] = $suid;
                }
            }
        }
    }

    /**
     * Retrieves an entry from the backend.
     *
     * @param string $databaseURI URI of Database to sync. Like
     *                            calendar, tasks, contacts or notes.
     *                            May include optional parameters:
     *                            tasks?options=ignorecompleted.
     * @param string $suid       Server unique id of the entry: for horde
     *                           this is the guid.
     * @param string contentType Content-Type: the mime type in which the
     *                           function shall return the data
     *
     * @return mixed             A string with the data entry or
     *                           or a PEAR_Error object.
     */
    function retrieveEntry($databaseURI, $suid, $contentType)
    {
        $database = $this->_normalize($databaseURI);

        return $this->_db->queryOne('SELECT syncml_data from syncml_data '
                . 'WHERE syncml_db='
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                . ' AND syncml_id='
                . $this->_db->quote($suid, 'text'));
    }

    /**
     * Adds an entry into the server database.
     *
     * @param string $databaseURI  URI of Database to sync. Like
     *                             calendar, tasks, contacts or notes.
     *                             May include optional parameters:
     *                             tasks?options=ignorecompleted.
     * @param string $content      The actual data
     * @param string $contentType  Mimetype of $content
     * @param string $cuid         Only for server mode: ClientID of this entry.
     *                             Used for map.
     *
     * @return array  PEAR_Error or suid (Horde guid) of new entry
     */
    function addEntry($databaseURI, $content, $contentType, $cuid = null)
    {
        $database = $this->_normalize($databaseURI);

        /* Generate an id (suid). It's also possible to use a database */
        /* generated primary key here. */
        $suid = $this->_generateID();

        $created_ts = $this->getCurrentTimeStamp();
        $r = $this->_db->exec('INSERT INTO syncml_data '
                . '(syncml_id, syncml_db, syncml_uid, syncml_data, syncml_contenttype, '
                . ' syncml_created_ts, syncml_modified_ts) VALUES ('
                . $this->_db->quote($suid, 'text') . ','
                . $this->_db->quote($database, 'text') . ','
                . $this->_db->quote($this->_user, 'text') . ','
                . $this->_db->quote($content, 'text') . ','
                . $this->_db->quote($contentType, 'text') . ','
                . $this->_db->quote($created_ts, 'integer') . ','
                . $this->_db->quote($created_ts, 'integer')
                . ')');
        if ($this->_checkForError($r)) {
            return $r;
        }
        // Only the server needs to handle the cuid suid map:
        if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
           $this->createUidMap($databaseURI, $cuid, $suid, $created_ts);
        }
    }

    /**
     * Replaces an entry in the server database.
     *
     * @param string $databaseURI  URI of Database to sync. Like
     *                             calendar, tasks, contacts or notes.
     *                             May include optional parameters:
     *                             tasks?options=ignorecompleted.
     * @param string $content      The actual data
     * @param string $contentType  Mimetype of $content
     * @param string $cuid         Client ID of this entry.
     *
     * @return array  PEAR_Error or suid of modified entry.
     */
    function replaceEntry($databaseURI, $content, $contentType, $cuid)
    {
        $database = $this->_normalize($databaseURI);

        if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
            $suid = $this->getSuid($databaseURI, $cuid);
        } else {
            $suid = $cuid;
        }
        if ($suid) {
            // Entry exists: replace current one.
            $modified_ts = $this->getCurrentTimeStamp();
            $r = $this->_db->exec('UPDATE syncml_data '
                . 'SET syncml_modified_ts = '
                . $this->_db->quote($modified_ts, 'integer')
                . ',syncml_data = '
                . $this->_db->quote($content, 'text')
                . ',syncml_contenttype = '
                . $this->_db->quote($contentType, 'text')
                . 'WHERE syncml_db='
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                . ' AND syncml_id='
                . $this->_db->quote($suid, 'text'));
            if ($this->_checkForError($r)) {
                return $r;
            }

            // Only the server needs to keep the map:
            if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
                $this->createUidMap($databaseURI, $cuid, $suid, $modified_ts);
            }

        } else {
            return PEAR::raiseError('No map entry found for cuid=' . $cuid);
        }

        return $suid;

    }

    /**
     * Deletes an entry from the server database.
     *
     * @param string $databaseURI URI of Database to sync. Like
     *                            calendar, tasks, contacts or notes.
     *                            May include optional parameters:
     *                            tasks?options=ignorecompleted.
     * @param string $cuid      Client ID of the entry
     *
     * @return boolean          true on success or false on failed (item not found)
     */
    function deleteEntry($databaseURI, $cuid)
    {
        $database = $this->_normalize($databaseURI);

        // Find ID for this entry:
        if ($this->_backendMode == SYNCML_BACKENDMODE_SERVER) {
            $suid = $this->getSuid($databaseURI, $cuid);
        } else {
            $suid = $cuid;
        }
        if (!is_a($suid, 'PEAR_Error')) {
            // A clever backend datastore would store some information about
            // a deletion so this information can be extracted from the history.
            // However we do a "stupid" datastore here where deleted items are
            // simply gone. This allows us to illustrate the _trackDeletions
            // bookkeeping mechanism.
            $r = $this->_db->queryOne('DELETE FROM syncml_data '
                . ' WHERE syncml_db='
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                . ' AND syncml_id='
                . $this->_db->quote($suid, 'text'));
            if ($this->_checkForError($r)) {
                return $r;
            }

            // Deleted bookkeeping is required for server and client,
            // but not for test mode:
            if ($this->_backendMode != SYNCML_BACKENDMODE_TEST) {
                $this->_removeFromSuidList($databaseURI, $suid);
            }
            //@TODO: delete from map!
        } else {
            return false;
        }

        if (is_a($r, 'PEAR_Error')) {
            return false;
        }

        return true;
    }

    /** Checks the authorization and does a "login" on the backend if
     * necessary.
     * Returns true on auth accepted, false otherwise.
     * For some types of authentications (notably auth:basic) the username
     * gets extracted from the auth data and is then stored in username.
     * For security reason the caller must ensure that this is the username
     * that is used for the session, overriding any username specified in
     * &lt;LocName&gt;.
     *
     * @param string username    username as provided in the SyncHdr.
     *                           May be overwritten by credData
     * @param string creadData   Auth data provided by Cred/Data in the SyncHdr.
     * @param string credFormat  Format of data as Cread/Meta/Format in the
     *                           SyncHdr. Typically 'b64'.
     * @param string credType    Auth type as provided by Cred/Meta/Type in the
     *                           SyncHdr. Typically 'syncml:auth-basic'
     *
     * @return boolean true on valid uri, false on invalid uri.
     */
    function checkAuthorization(&$username,$credData, $credFormat, $credType)
    {

        if (empty($credData) || empty($credType)) {
            return false;
        }

        switch ($credType) {
        case 'syncml:auth-basic':
            list($username,$pwd) = explode(':', base64_decode($credData),2);
            $this->logMessage('checking auth for user=' . $username,
                              __FILE__, __LINE__, PEAR_LOG_DEBUG);
            // empty passwords result in errors for some auth backends:
            // so don't call the auth backend in this case
            if ($pwd === '') {
                return false;
            }
            $r = $this->_db->queryOne('SELECT syncml_uid FROM syncml_uids'
                . ' WHERE syncml_uid='
                . $this->_db->quote($username, 'text')
                . ' AND syncml_password='
                . $this->_db->quote($pwd, 'text'));
            $this->_checkForError($r);

            if ($r === $username) {
                return true;
            }
            return false;
        case 'syncml:auth-md5':
            /* syncml:auth-md5 only transfers hash values of passwords.
             * This is currently not supported by the SQL backend.
             * So we can't use the table to do authentication. Instead here
             * is a very crude direct manual hook to illustrate how it works:
             * To allow authentication for a user 'dummy' with password 'sync',
             * run
             * php -r 'print base64_encode(pack("H*",md5("dummy:sync")));'
             * from the command line. Then create an entry like
             *  'dummy' => 'ZD1ZeisPeQs0qipHc9tEsw==' in the users array below,
             * where the value is the command line output.
             * This user/password combination is then accepted for md5-auth.
             */
            $users = array(
                  // example for user dummy with pass pass:
                  // 'dummy' => 'ZD1ZeisPeQs0qipHc9tEsw=='
                          );
            if (empty($users[$username])) {
                return false;
            }

            //@TODO: nonce may be specified by client. Use it then.
            $nonce = '';
            if (base64_encode(pack('H*',md5($users[$username] . ':' . $nonce)))
                    === $credData) {
                return true;
            }
            return false;
            break;
        default:
            $this->logMessage('unsupported auth type ' . $credType,
                              __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }
    }

    /**
     * After a successful sync: store Sync anchors to allow two way sync
     * on next sync.
     * The backend has to store the parameters in its persistence engine
     * where user, syncDeviceID and database are the keys while client and
     * server anchor ar the payload. See readSyncAnchors for retrival
     *
     * @param string user             Username to use
     * @param string syncDevideID     Key to identify the client device.
     *                                This allows one user to sync with
     *                                different devices. This parameteris used
     *                                when dealing with the cuid<->suid map.
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key for the sync
     *                                anchor.
     * @param string clientAnchorNext The client anchor as sent by the client.
     * @param string serverAnchorNext The anchor as used internally by the
     *                                server.
     */
    function writeSyncAnchors($databaseURI,
                              $clientAnchorNext, $serverAnchorNext)
    {
        $database = $this->_normalize($databaseURI);

        // Check if entry exists. If not insert, otherwise update.
        if ($this->readSyncAnchors($databaseURI) == false) {
            $r = $this->_db->exec('INSERT INTO syncml_anchors '
                . ' (syncml_syncpartner,syncml_db,syncml_uid, syncml_clientanchor,syncml_serveranchor) VALUES ('
                . $this->_db->quote($this->_syncDeviceID, 'text') . ','
                . $this->_db->quote($database, 'text') . ','
                . $this->_db->quote($this->_user, 'text') . ','
                . $this->_db->quote($clientAnchorNext, 'text') . ','
                . $this->_db->quote($serverAnchorNext, 'text')
                . ')');
        } else {
            $r = $this->_db->exec('UPDATE syncml_anchors '
                . ' SET syncml_clientanchor = '
                . $this->_db->quote($clientAnchorNext, 'text')
                . ' ,syncml_serveranchor = '
                . $this->_db->quote($serverAnchorNext, 'text')
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                );
        }
        if ($this->_checkForError($r)) {
            return $r;
        }
        return true;
    }


    /**
     *
     * Reads the previously written sync anchors from the database
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key for the sync
     *                                anchor.
     * @return mixed                  array(clientanchor,serveranchor) as
     *                                stored in previous writeSyncAnchor
     *                                request. Or false if no data found.
     */
    function readSyncAnchors($databaseURI)
    {
        $database = $this->_normalize($databaseURI);

        $r = $this->_db->queryRow('SELECT syncml_clientanchor,syncml_serveranchor '
                . '  FROM syncml_anchors WHERE syncid = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                );
        $this->_checkForError($r);

        if (!is_array($r)) {
            return false;
        }

        return array($r[0], $r[1]);
    }

    /**
     * Create a map entries to map between server and client IDs.
     * If an entry already exists, it is overwritten.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param integer timestamp       Optional timestamp. This can be used to 'tag'
     *                                changes made in the backend during the sync
     *                                process. This allows to identify these and
     *                                ensure, that these changes are not replicated
     *                                back to the client (and thus duplicated).
     *                                See key concept "Changes and timestamps".
     */
    function createUidMap($databaseURI, $cuid, $suid, $timestamp = 0)
    {
        $database = $this->_normalize($databaseURI);

        // Check if entry exists. If not insert, otherwise update.
        if ($this->getSuid($databaseURI, $cuid) == false) {
            $r = $this->_db->exec('INSERT INTO syncml_map '
                . ' (syncml_syncpartner,syncml_db,syncml_uid,syncml_cuid,syncml_suid,syncml_timestamp) VALUES ('
                . $this->_db->quote($this->_syncDeviceID, 'text') . ','
                . $this->_db->quote($database, 'text') . ','
                . $this->_db->quote($this->_user, 'text') . ','
                . $this->_db->quote($cuid, 'text') . ','
                . $this->_db->quote($suid, 'text') . ','
                . $this->_db->quote($timestamp, 'integer')
                . ')');
        } else {
            $r = $this->_db->exec('UPDATE syncml_map '
                . ' SET syncml_suid = '
                . $this->_db->quote($suid, 'text')
                . ' ,syncml_timestamp = '
                . $this->_db->quote($timestamp, 'text')
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                . ' AND syncml_cuid = '
                . $this->_db->quote($cuid, 'text')
                );
        }
        if ($this->_checkForError($r)) {
            return $r;
        }
        return true;
    }

    /**
     * Retrieves the Server ID for a given Client ID from the map.
     * All three parameters combined are the key to the map.
     * This function is used internally by the backend, typically by
     * deleteEntry and replaceEntry as these are invoked with a client id.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param string cuid             The client ID.
     *
     * @return mixed                  The server ID string or false if no
     *                                entry is found.
     *
     * @access private
     *
     */
    function getSuid($databaseURI, $cuid)
    {
        $database = $this->_normalize($databaseURI);

        $r = $this->_db->queryOne('SELECT syncml_suid FROM syncml_map '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                . ' AND syncml_cuid = '
                . $this->_db->quote($cuid, 'text')
                );
        $this->_checkForError($r);

        if (!empty($r)) {
            return $r;
        }
        return false;
    }

    /**
     * Retrieves the Client ID for a given Server ID from the map.
     * All three parameters combined are the key to the map.
     * This function is used internally by the backend, typically by
     * getServerChanges as this function is supposed to return client IDs
     * for changes and deletions.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param string suid             The server ID.
     *
     * @return mixed                  The client ID string or false if no
     *                                entry is found.
     *
     * @access private
     *
     */
    function getCuid($databaseURI, $suid)
    {
        $database = $this->_normalize($databaseURI);

        $r = $this->_db->queryOne('SELECT syncml_cuid FROM syncml_map '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                . ' AND syncml_suid = '
                . $this->_db->quote($suid, 'text')
                );

        $this->_checkForError($r);

        if (!empty($r)) {
            return $r;
        }
        return false;
    }

    /**
     * Returns a timestamp stored in the map for a given Server ID.
     * The timestamp is the timestamp of the last change to this server ID
     * that was done inside a sync session (as a result of a change received
     * by the server). It's important to distinguish changes in the backend
     * a) made by the user during normal operation and
     * b) changes made by SyncML to reflect client updates.
     * When the server is sending its changes it is only allowed to send
     * type a). However the history feature in the backend my not know if
     * a change is of type a) or type b). So the timestamp is used to
     * differentiate between the two.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param string suid             The server ID.
     *
     * @return mixed                  The previously stored timestamp or false
     *                                if no entry is found.
     *
     * @access private
     *
     */
    function getChangeTS($databaseURI, $suid)
    {
        $database = $this->_normalize($databaseURI);

        $r = $this->_db->queryOne('SELECT syncml_timestamp FROM syncml_map '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                . ' AND syncml_suid = '
                . $this->_db->quote($suid, 'text')
                );
        $this->_checkForError($r);

        if (!empty($r)) {
            return $r;
        }
        return false;
    }


    function logMessage($message, $file = __FILE__, $line = __LINE__,
                        $priority = PEAR_LOG_INFO)
    {
//        print "SyncML: $message\n\n";
//        Horde::logMessage($message, $file, $line, $priority);
        parent::logMessage($message, $file, $line, $priority);
    }
    /**
     * Erases all mapping entries for one user / syncDevideID / database
     * so a SlowSync really syncs everything properly and no old
     * mapping entries remain.
     *
     * @param string user             Username to use
     * @param string syncDevideID     Key to identify the client device.
     *                                This allows one user to sync with
     *                                different devices.
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     */
    function eraseMap($databaseURI)
    {
        $database = $this->_normalize($databaseURI);

        $r = $this->_db->exec('DELETE FROM syncml_map '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                );
        if ($this->_checkForError($r)) {
            return $r;
        }

        $r = $this->_db->exec('DELETE FROM syncml_suidlist '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                );
        if ($this->_checkForError($r)) {
            return $r;
        }
        return true;
    }

    /**
     * Cleanup function called after all message processing is
     * finished. Allows for things like closing db or flushing logs.
     * When running in test mode, tearDown must be called rather than close.
     */
    function close()
    {
        parent::close();
        $this->_db->disconnect();
    }


    // Internal helper functions

    /**
     * Generates a unique ID used as suid
     */
    function _generateID()
    {
        return date('YmdHis') . '.' .
            substr(base_convert(microtime(), 10, 36), -16) . '@'
            . (!empty($_SERVER["HTTP_HOST"]) ? $_SERVER["HTTP_HOST"] : 'localhost');
    }


    /**
     * Checks if the parameter is a PEAR_Error object and if so
     * log the error.
     *
     * @param mixed  $o    An object or value to check.
     * @return mixed       The error object if an error has been passed or
     *                     false if no error has been passed.
     */
    function _checkForError($o)
    {
        if( is_a($o,'PEAR_Error')) {
            $this->logMessage($o);
            // var_dump($o); die("DB Error!");
            return $o;
        }
        return false;
    }

    /**
     * Returns list of IDs of itemes that have been deleted since the last
     * sync run and stores complete list of IDs for next sync run.
     * Some backend datastores don't keep information about deleted entries.
     * So we have to create a workaround that finds out what entries have
     * been deleted since the last sync run. _trackDeletes provides this
     * functionality: it is called with a list of all IDs currently in the
     * database. It then compares this list with its own previously stored
     * list of IDs to identify those missing (and thus deleted). The passed
     * list is then stored for the next invocation.
     *
     * @param string user             Username to use
     * @param string syncDevideID     Key to identify the client device.
     *                                This allows one user to sync with
     *                                different devices.
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param array allSuids          Array of all SUIDs (primary keys) currently
     *                                in the server datastore.
     *
     * @return array                  Array of all entries that have been
     *                                deleted since the last call of
     *                                _trackDeletes.
     */
    function _trackDeletes($databaseURI, $currentSuids)
    {
$this->logMessage("_trackDel with count=" . count($currentSuids)
        ." current ids", __FILE__, __LINE__, PEAR_LOG_DEBUG);
        $database = $this->_normalize($databaseURI);
        if (!is_array($currentSuids)) {
            $currentSuids = array();
        }

        $r = $this->_db->queryCol('SELECT syncml_suid FROM syncml_suidlist '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                );
        if ($this->_checkForError($r)) {
            return $r;
        }
$this->logMessage("_trackDel found count=" . count($r)
        ." items in prevlist", __FILE__, __LINE__, PEAR_LOG_DEBUG);

        // Convert to assoc. array with suid as key:
        if (is_array($r)) {
            $prevSuids = array_flip($r);
        } else {
            $prevSuids = array();
        }

        foreach ($currentSuids as $suid) {
            if (isset($prevSuids[$suid])) {
                // entry is there now and in Prev: unset in Prev array so we
                // end up with only those in Prev that are no longer there now.
                unset($prevSuids[$suid]);
            } else {
                // entry is there now but not in Prev: new entry
                // store in syncml_suidlist
                $r = $this->_db->exec('INSERT INTO syncml_suidlist '
                    . ' (syncml_syncpartner,syncml_db,syncml_uid, syncml_suid) VALUES ('
                    . $this->_db->quote($this->_syncDeviceID, 'text') . ','
                    . $this->_db->quote($database, 'text') . ','
                    . $this->_db->quote($this->_user, 'text') . ','
                    . $this->_db->quote($suid, 'text')
                    . ')');
                if ($this->_checkForError($r)) {
                    return $r;
                }
            }
        }
        // $prevSuids now contains the deleted suids. Remove those from
        // syncml_suidlist so we have a current list of all existing suids:
        foreach ($prevSuids as $suid => $cuid) {
            $r = $this->_removeFromSuidList($databaseURI, $suid);
        }

$this->logMessage("_trackDel with found count=" . count($prevSuids)
        ." deleted items", __FILE__, __LINE__, PEAR_LOG_DEBUG);

        return array_keys($prevSuids);
    }

    /**
     * Remove a suid from the suidlist. This is done by _trackDeletes when
     * updating the suidlist and deleteEntry when removing an entry due to
     * a client request.
     *
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     *                                So the databaseURI has to be "normalized"
     *                                (from "contacts?optionsx=s" to "contacts")
     *                                before beeing used as a key.
     * @param array suid              The suid to remove from the list.
     */
    function _removeFromSuidList($databaseURI, $suid)
    {
        $database = $this->_normalize($databaseURI);

$this->logMessage("_removefromlist item=" . $suid, __FILE__, __LINE__, PEAR_LOG_DEBUG);
        $r = $this->_db->queryCol('DELETE FROM syncml_suidlist '
                . ' WHERE syncml_syncpartner = '
                . $this->_db->quote($this->_syncDeviceID, 'text')
                . ' AND syncml_db = '
                . $this->_db->quote($database, 'text')
                . ' AND syncml_uid='
                . $this->_db->quote($this->_user, 'text')
                . ' AND syncml_suid='
                . $this->_db->quote($suid, 'text')
                );
        if ($this->_checkForError($r)) {
            return $r;
        }
$this->logMessage("_removefromlist result=" . implode('!',$r), __FILE__, __LINE__, PEAR_LOG_DEBUG);
        return true;
    }

    /*
     * Database access functions. The following functions are not part of
     * the backend api. They are here to illustrate how a backebnd application
     * (like a web calendar) has to modify the data with respect to the
     * history. There are three functions:
     * addEntry_backend, replaceEntry_backend, deleteEntry_backend.
     * They are very similar to the api methods above, but don't use cuids or
     * syncDeviceIDs as these are only relevant for syncing.
     */

    /**
     * Adds an entry into the server database.
     *
     * @param string $user         The username to use. Not strictly necessery
     *                             to store this but it helps for the test
     *                             environment to clean up all entries for a
     *                             test user.
     * @param string $databaseURI  URI of Database to sync. Like
     *                             calendar, tasks, contacts or notes.
     *                             May include optional parameters:
     *                             tasks?options=ignorecompleted.
     * @param string $content      The actual data
     * @param string $contentType  Mimetype of $content
     *
     * @return array  PEAR_Error or suid (Horde guid) of new entry
     */
    function DELETE_addEntry_backend($user, $databaseURI, $content, $contentType)
    {
        $database = $this->_normalize($databaseURI);

        /* Generate an id (suid). It's also possible to use a database */
        /* generated primary key here. */
        $suid = $this->_generateID();

        $created_ts = $this->getCurrentTimeStamp();
        $r = $this->_db->exec('INSERT INTO syncml_data '
                . '(syncml_id, syncml_db, syncml_uid, syncml_data, syncml_contenttype, '
                . ' syncml_created_ts, syncml_modified_ts) VALUES ('
                . $this->_db->quote($suid, 'text') . ','
                . $this->_db->quote($database, 'text') . ','
                . $this->_db->quote($user, 'text') . ','
                . $this->_db->quote($content, 'text') . ','
                . $this->_db->quote($contentType, 'text') . ','
                . $this->_db->quote($created_ts, 'integer') . ','
                . $this->_db->quote($created_ts, 'integer')
                . ')');
        if ($this->_checkForError($r)) {
            return $r;
        }
        return $suid;
    }

    /**
     * Replaces an entry in the server database.
     *
     * @param string $user         The username to use. Not strictly necessery
     *                             to store this but it helps for the test
     *                             environment to clean up all entries for a
     *                             test user.
     * @param string $databaseURI  URI of Database to sync. Like
     *                             calendar, tasks, contacts or notes.
     *                             May include optional parameters:
     *                             tasks?options=ignorecompleted.
     * @param string $content      The actual data
     * @param string $contentType  Mimetype of $content
     * @param string $suid         The (server) ID of this entry
     *
     * @return array  PEAR_Error or suid of modified entry.
     */
    function DELETE_replaceEntry_backend($user, $databaseURI, $content, $contentType, $suid)
    {
        $database = $this->_normalize($databaseURI);

        // Entry exists: replace current one.
        $modified_ts = $this->getCurrentTimeStamp();
        $r = $this->_db->exec('UPDATE syncml_data '
            . 'SET syncml_modified_ts = '
            . $this->_db->quote($modified_ts, 'integer')
            . ',syncml_data = '
            . $this->_db->quote($content, 'text')
            . ',syncml_contenttype = '
            . $this->_db->quote($contentType, 'text')
            . 'WHERE syncml_db='
            . $this->_db->quote($database, 'text')
            . ' AND syncml_uid='
            . $this->_db->quote($user, 'text')
            . ' AND syncml_id='
            . $this->_db->quote($suid, 'text'));

        if ($this->_checkForError($r)) {
            return $r;
        }

        return $suid;
    }

    /**
     * Deletes an entry from the server database.
     *
     * @param string $user         The username to use. Not strictly necessery
     *                             to store this but it helps for the test
     *                             environment to clean up all entries for a
     *                             test user.
     * @param string $databaseURI     URI of Database to sync. Like
     *                                calendar, tasks, contacts or notes.
     *                                May include optional parameters:
     *                                tasks?options=ignorecompleted.
     * @param string $suid      (Server) ID of the entry
     *
     * @return boolean          true on success or false on failed.
     */
    function DELETE_deleteEntry_backend($user, $databaseURI, $suid)
    {
        $database = $this->_normalize($databaseURI);

        $r = $this->_db->queryOne('DELETE FROM syncml_data '
            . ' WHERE syncml_db='
            . $this->_db->quote($database, 'text')
            . ' AND syncml_uid='
            . $this->_db->quote($user, 'text')
            . ' AND syncml_id='
            . $this->_db->quote($suid, 'text'));

        if ($this->_checkForError($r)) {
            return false;
        }
        return true;
    }

    /**
     *
     * Create a clean test environment in the backend.
     * Ensure there's a user with the given credentials
     * and an empty data store.
     *
     * @param string $user This user accout has to be created in the backend.
     * @param string $pwd  The password for user $user.
     *
     */
    function testSetup($user, $pwd)
    {
        $this->_user = $user;
        $this->_cleanUser($user);
        $this->_backend->_user = $user;

        $r = $this->_db->exec('INSERT INTO syncml_uids (syncml_uid,syncml_password)'
            . ' VALUES ('
            . $this->_db->quote($user, 'text') . ','
            . $this->_db->quote($pwd, 'text') . ')');

        $this->_checkForError($r);
    }

    /**
     * Tear down the test environment after the test is run.
     * Should remove the testuser created during testSetup and all its data.
     */
    function testTearDown()
    {
        $this->_cleanUser($this->_user);
        $this->_db->disconnect();
    }

    function _cleanUser($user)
    {
        $r = $this->_db->exec('DELETE FROM syncml_data WHERE syncml_uid='
            . $this->_db->quote($user, 'text'));
        $this->_checkForError($r);

        $r = $this->_db->exec('DELETE FROM syncml_map WHERE syncml_uid='
            . $this->_db->quote($user, 'text'));
        $this->_checkForError($r);

        $r = $this->_db->exec('DELETE FROM syncml_anchors WHERE syncml_uid='
            . $this->_db->quote($user, 'text'));
        $this->_checkForError($r);

        $r = $this->_db->exec('DELETE FROM syncml_uids WHERE syncml_uid='
            . $this->_db->quote($user, 'text'));
        $this->_checkForError($r);
        $r = $this->_db->exec('DELETE FROM syncml_suidlist WHERE syncml_uid='
            . $this->_db->quote($user, 'text'));
        $this->_checkForError($r);
    }

}
