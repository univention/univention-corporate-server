<?php
/**
 * There are two global objects that are used by SyncML:
 * 1) $_SESSION['SyncML.state']:
 *    session object used to maintain the state between the individual
 *    SyncML messages.
 *
 * 2) $GLOBALS['backend']
 *    Backend to handle the communication with the datastore.
 *
 * @todo: Main Todos:
 * - ensure that no server data is written for ALERT_ONE_WAY_FROM_SERVER
 *   even when client sends data (security!)
 * - consinstant naming of clientSyncDB (currently called targetLocURI, db
 *   or synctype)
 * - tackle the AddReplace issue: when a Replace is issued (i.e. during
 *   SlowSync) the server should first check if the entry already exists.
 *   Like: does a calendar entry with the same timeframe, same subject and
 *   location exist. If so, the replace should replace this value rather than
 *   create a new one as a duplicate.
 *
 * $Horde: framework/SyncML/SyncML.php,v 1.63 2007/06/29 12:58:01 jan Exp $
 *
 * Copyright 2003-2007 Karsten Fourmont <karsten@horde.org>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Karsten Fourmont <karsten@horde.org>
 * @author  Anthony Mills <amills@pyramid6.com>
 * @since   Horde 3.0
 * @package SyncML
 */

require_once 'SyncML/Command.php';
require_once 'SyncML/Command/Status.php';
require_once 'SyncML/Command/Alert.php';
require_once 'SyncML/Command/Sync.php';
require_once 'SyncML/Command/Final.php';
require_once 'SyncML/Command/SyncHdr.php';
require_once 'SyncML/Sync.php';
require_once 'SyncML/Backend.php';
require_once 'SyncML/XMLOutput.php';
require_once 'XML/WBXML/ContentHandler.php';

/* PEAR_LOG_* constants: */
require_once 'Log.php';

/**
 * Main SyncML function.
 *
 * The function does all the necessary processing and returns the resulting
 * output.
 *
 * @param string $request      The HTTP request data.
 * @param string $contentType  The request's content type.
 * @param string $backend
 * @param array $backendparams
 */
function SyncML_HandleRequest($request, $contentType, $backend = 'Horde',
                              $backendparms = array())
{
    /* Create the Backend*/
    $GLOBALS['backend'] = SyncML_Backend::factory($backend, $backendparms);
    $h = new SyncML_ContentHandler();
    $response = $h->process($request, $contentType);
    $GLOBALS['backend']->close();

    return $response;
}

class SyncML_ContentHandler {

    /**
     * Stack for holding the xml elements during creation of the object from
     * the xml event flow.
     *
     * @var array
     */
    var $_Stack = array();

    /**
     * @var string
     */
    var $_chars;

    /**
     * Instance of SyncML_Command. Events are passed through to this
     * ContentHandler.
     *
     * @var SyncML_Command
     */
    var $_currentCommand;

    /**
     * Whether we received a final element in this message.
     */
    var $_gotFinal;

    var $_xmlWriter;

    var $_wbxmlparser;

    function SyncML_ContentHandler()
    {
        /* Set to true to indicate that we expect another message from the
         * client. If this is still false at the end of processing, the sync
         * session is finished and we can clopse the session. */
        $GLOBALS['message_expectresponse'] = false;
        $this->_gotFinal = false;
        $this->_wbxmlparser = null;
    }

    /**
     * Here's were all the processing takes place: gets the SyncML request
     * data and returns a SyncML response The only thing that needs to be in
     * place before invoking this function is a working backend.
     */
    function process($request, $contentType)
    {
        if ($contentType =='application/vnd.syncml+wbxml') {
            $isWBXML = true;
        } else {
            $isWBXML = false;
        }

        /* Catch any errors/warnings/notices that may get thrown while
         * processing. Don't want to let anything go to the client that's not
         * part of the valid response. */
        ob_start();

        $GLOBALS['backend']->logFile(SYNCML_LOGFILE_CLIENTMESSAGE, $request, $isWBXML);

        if (!$isWBXML) {
            /* XML code. */

            /* try to extract charset from XML text */
            if (preg_match('/^\s*<\?xml[^>]*encoding\s*=\s*"([^"]*)"/i',
                           $request, $m)) {
                $charset = $m[1];
            } else {
                $charset = 'UTF-8';
            }

            $GLOBALS['backend']->setCharset($charset);

            /* Init output handler. */
            $this->_xmlWriter = &SyncML_XMLOutput::singleton();
            /* XML_WBXML_ContentHandler Is a class that produces plain XML
             * output. */
            $this->_xmlWriter->init(new XML_WBXML_ContentHandler());

            /* Create the XML parser and set method references. */
            $parser = xml_parser_create_ns($charset);
            xml_set_object($parser, $this);
            xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, false);
            xml_set_element_handler($parser, '_startElement', '_endElement');
            xml_set_character_data_handler($parser, '_characters');
            xml_set_processing_instruction_handler($parser, '');
            xml_set_external_entity_ref_handler($parser, '');

            /* Here we go: fire off events: */
            if (!xml_parse($parser, $request)) {
                $s = sprintf('XML error: %s at line %d',
                             xml_error_string(xml_get_error_code($parser)),
                             xml_get_current_line_number($parser));
                $GLOBALS['backend']->logMessage($s,__FILE__,__LINE__,PEAR_LOG_ERR);
                xml_parser_free($parser);
                return new PEAR_Error($s);
            }

            xml_parser_free($parser);

        } else {
            /* WBXML code. */

            /* The decoder works like the parser in the XML code above: It
             * parses the input and calls the callback functions of $this. */
            $this->_wbxmlparser = new XML_WBXML_Decoder();
            $this->_wbxmlparser->setContentHandler($this);

            /* Init output handler. */
            $this->_xmlWriter = &SyncML_XMLOutput::singleton();
            $this->_xmlWriter->init(new XML_WBXML_Encoder());

            /* Here we go: fire off events: */
            $r = $this->_wbxmlparser->decode($request);
        }

        $id = @session_id();
        $sessionclose = empty($id) ? true : false;

        $output = $this->getOutput();
        if (!$isWBXML) {
            $output = '<?xml version="1.0" encoding="' . $charset . '"?>'
                . $output;
        }
        $GLOBALS['backend']->logFile(SYNCML_LOGFILE_SERVERMESSAGE, $output, $isWBXML, $sessionclose);

        /* Clear the output buffer that we started above, and log anything
         * that came up for later debugging. */
        $errorLogging = ob_get_clean();

        if (!empty($errorLogging)) {
            $GLOBALS['backend']->logMessage('Caught output: ' . str_replace("\n", ' ', $errorLogging), __FILE__, __LINE__, PEAR_LOG_WARNING);
        }

        return $output;
    }

    /*
     * CONTENTHANDLER CALLBACK FUNCTIONS
     * The following functions are callback functions that are called by the
     * XML parser. The XML and WBXML parsers use slightly different functions,
     * so the methods are duplicated.
     */

    /**
     * Returns the XML|WBXML output once processing is finished.
     *
     * @return string  The XML or WBXML output data.
     */
    function getOutput()
    {
        return $this->_xmlWriter->getOutput();
    }

    /**
     * Callback function called by XML parser.
     */
    function _startElement($parser, $tag, $attributes)
    {
        list($uri, $name) = $this->_splitURI($tag);
        $this->startElement($uri, $name, $attributes);
    }

    /**
     * Callback function called by XML parser.
     */
    function _characters($parser, $chars)
    {
        $this->characters($chars);
    }

    /**
     * Callback function called by XML parser.
     */
    function _endElement($parser, $tag)
    {
        list($uri, $name) = $this->_splitURI($tag);
        $this->endElement($uri, $name);
    }

    /**
     * Splits an URI as provided by the XML parser.
     */
    function _splitURI($tag)
    {
        $parts = explode(':', $tag);
        $name = array_pop($parts);
        $uri = implode(':', $parts);
        return array($uri, $name);
    }

    /**
     * Callback function called by WBXML parser.
     */
    function startElement($uri, $element, $attrs)
    {
        $this->_Stack[] = $element;

        // <SyncML>: don't do anyhting yet
        if (count($this->_Stack) == 1) {
            return;
        }

        // header or body?
        if ($this->_Stack[1] == 'SyncHdr') {
            if (count($this->_Stack) == 2) {
                $this->_currentCommand = & new SyncML_Command_SyncHdr();
            }
            $this->_currentCommand->startElement($uri, $element, $attrs);
        } else {
            switch (count($this->_Stack)) {
            case 2:
                 // <SyncBody>: do nothing yet
                 break;
            case 3:
                // new Command:
                // <SyncML><SyncBody><[Command]>
                $this->_currentCommand = & SyncML_Command::factory($element,$this->_xmlWriter);
                $this->_currentCommand->startElement($uri, $element, $attrs);
                break;
            default:
                // pass on to current command handler:
                // <SyncML><SyncBody><Command><...>
                $this->_currentCommand->startElement($uri, $element, $attrs);
                break;
            }
        }
    }

    /**
     * Callback function called by WBXML parser.
     */
    function endElement($uri, $element)
    {
        // </SyncML>: everything done already by end of SyncBody
        if (count($this->_Stack) == 1) {
            return;
        }
        // header or body?
        if ($this->_Stack[1] == 'SyncHdr') {
            switch (count($this->_Stack)) {
            case 2:
                // </SyncHdr> end of header
                $this->handleHeader($this->_currentCommand);
                unset($this->_currentCommand);
                break;
            default:
                // pass on to command handler:
                $this->_currentCommand->endElement($uri, $element);
                break;
            }
        } else {
            switch (count($this->_Stack)) {
            case 2:
                // </SyncBody> end of SyncBody. Finish everything:
                $this->handleEnd();
                break;
            case 3:
                // </[Command]></SyncBody></SyncML>
                // Command finished. Complete parsing and pass on to Handler
                $this->_currentCommand->endElement($uri, $element);
                $this->handleCommand($this->_currentCommand);
                unset($this->_currentCommand);
                break;
            default:
                // </...></[Command]></SyncBody></SyncML>
                // pass on to command handler:
                $this->_currentCommand->endElement($uri, $element);
                break;
            }
        }

        if (isset($this->_chars)) {
            unset($this->_chars);
        }

        array_pop($this->_Stack);
    }

    /**
     * Callback function called by WBXML parser.
     */
    function characters($str)
    {
        if (isset($this->_currentCommand)) {
            $this->_currentCommand->characters($str);
        } else {
            if (isset($this->_chars)) {
                $this->_chars = $this->_chars . $str;
            } else {
                $this->_chars = $str;
            }
        }
    }

    /*
     * PROCESSING FUNCTIONS
     *
     * The following functions are called by the callback functions
     * and do the actual processing.
     */

    /**
     * Handles the header logic.
     *
     * Invoked after header is parsed.
     */
    function handleHeader(& $hdr)
    {
        if (is_object($this->_wbxmlparser)) {
            /* The WBXML parser only knows about the charset once parsing is
             * started. So setup charset now. */
            $this->_xmlWriter->_output->setVersion($this->_wbxmlparser->getVersion());
            $this->_xmlWriter->_output->setCharset($this->_wbxmlparser->getCharsetStr());
            $GLOBALS['backend']->setCharset($this->_wbxmlparser->getCharsetStr());
        }

        /* Start the session. */
        $hdr->setupState();
        $_SESSION['SyncML.state']->setWBXML($this->_xmlWriter->isWBXML());

        /* Check auth. */
        if (!$_SESSION['SyncML.state']->isAuthorized()) {
            $user = $hdr->getLocName();
            $auth = $GLOBALS['backend']->checkAuthorization(
                $user,
                $hdr->getCredData(),
                $hdr->getCredFormat(),
                $hdr->getCredType());
            if ($auth === true) {
                $_SESSION['SyncML.state']->_isAuthorized = true;
                $statuscode = RESPONSE_AUTHENTICATION_ACCEPTED;
                $_SESSION['SyncML.state']->setLocName($user);
                $GLOBALS['backend']->setUser($user);
            } else {
                if (!$hdr->getCredData()) {
                    $statuscode = RESPONSE_CREDENTIALS_MISSING;
                } else {
                    $statuscode = RESPONSE_INVALID_CREDENTIALS;
                }
                $GLOBALS['backend']->logMessage('Invalid authorization!',
                                 __FILE__, __LINE__, PEAR_LOG_DEBUG);
            }
        } else {
            $statuscode = RESPONSE_OK;
            $GLOBALS['backend']->setUser($_SESSION['SyncML.state']->getUser());
        }

        /* Create <SyncML>. */
        $this->_xmlWriter->outputInit();

        /* Got the state; now write our SyncHdr header. */
        $this->_xmlWriter->outputHeader();

        /* Creates <SyncBody>. */
        $this->_xmlWriter->outputBodyStart();

        /* Output status for SyncHdr. */
        $this->_xmlWriter->outputStatus('0', 'SyncHdr', $statuscode,
                                        $_SESSION['SyncML.state']->getTargetURI(),
                                        $_SESSION['SyncML.state']->getSourceURI());

        /* Debug logging string. */
        $str = 'authorized=' . $_SESSION['SyncML.state']->isAuthorized() .
            ' version=' . $_SESSION['SyncML.state']->getVersion() .
            ' msgid=' . $_SESSION['SyncML.state']->getMsgID() .
            ' source=' . $_SESSION['SyncML.state']->getSourceURI() .
            ' target=' . $_SESSION['SyncML.state']->getTargetURI() .
            ' user=' . $_SESSION['SyncML.state']->getLocName() .
            ' charset=' . $GLOBALS['backend']->getCharset() .
            ' wbxml=' . $_SESSION['SyncML.state']->isWBXML();

        $GLOBALS['backend']->logMessage($str, __FILE__, __LINE__, PEAR_LOG_DEBUG);
    }

    /**
     * Processes one command after it has been completely parsed.
     *
     * Invoked after a command is parsed.
     */
    function handleCommand(&$cmd)
    {
        $name= $cmd->getCommandName();
        if ($name != 'Status' && $name != 'Map' && $name != 'Final' &&
            $name != 'Sync' && $name != 'Results') {
            /* We've got to do something! This can't be the last packet. */
            $GLOBALS['message_expectresponse'] = true;
        }
        if ($name == 'Final') {
            $this->_gotFinal = true;
        }
        /* Actual processing takes place here. */
        $cmd->handleCommand();
    }

    /**
     * Finishes the response.
     *
     * Invoked after complete message is parsed.
     */
    function handleEnd()
    {
        global $messageFull;

        /* If there's pending sync data and space left in the message, send
         * data now. */
        if ($messageFull || $_SESSION['SyncML.state']->hasPendingElements()) {
            /* still something to do: don't close session. */
            $GLOBALS['message_expectresponse'] = true;
        }

        if (!$messageFull &&
            count($p = $_SESSION['SyncML.state']->getPendingSyncs()) > 0) {
            foreach ($p as $pendingSync) {
                if (!$messageFull) {
                   $GLOBALS['backend']->logMessage('continue sync for syncType=' . $pendingSync, __FILE__, __LINE__, PEAR_LOG_DEBUG);
                    $sync = &$_SESSION['SyncML.state']->getSync($pendingSync);
                    $sync->createSyncOutput($this->_xmlWriter);
                }
            }
        }

        if (isset($_SESSION['SyncML.state']->curSyncItem)) {
            $sync = $_SESSION['SyncML.state']->curSyncItem->getSync();
            $this->_xmlWriter->outputAlert(ALERT_NO_END_OF_DATA,
                                           $sync->getClientLocURI(),
                                           $sync->getServerLocURI(),
                                           $sync->getServerAnchorLast(),
                                           $sync->getServerAnchorNext());
        }

        /* Don't send the final tag if we haven't sent all sync data yet. */
        if ($this->_gotFinal) {
            if (!$messageFull &&
                !$_SESSION['SyncML.state']->hasPendingElements()) {
                /* Create <Final></Final>. */
                $this->_xmlWriter->outputFinal();
                $GLOBALS['backend']->logMessage('Sending Final to client.', __FILE__, __LINE__, PEAR_LOG_DEBUG);
                $_SESSION['SyncML.state']->delayedFinal = false;
            } else {
                $GLOBALS['message_expectresponse'] = true;
                /* Remember to send a Final. */
                $_SESSION['SyncML.state']->delayedFinal = true;
            }
        } elseif ($_SESSION['SyncML.state']->delayedFinal) {
            if (!$messageFull &&
                !$_SESSION['SyncML.state']->hasPendingElements()) {
                /* Create <Final></Final>. */
                $this->_xmlWriter->outputFinal();
                $GLOBALS['backend']->logMessage('Sending delayed Final to client.', __FILE__, __LINE__, PEAR_LOG_DEBUG);
                $_SESSION['SyncML.state']->delayedFinal = false;
            } else {
                $GLOBALS['message_expectresponse'] = true;
            }
        }

        /* Create </SyncML>. Message is finished now! */
        $this->_xmlWriter->outputEnd();

        if (!$GLOBALS['message_expectresponse'] &&
            $_SESSION['SyncML.state']->isAllSyncsComplete()) {
            /* This packet did not contain any real actions, just status and
             * map. This means we're done. The session can be closed and the
             * anchors saved for the next sync. */
            foreach ($_SESSION['SyncML.state']->getSyncs() as $sync) {
                $sync->closeSync();
            }

            /* Session can be closed here. */
            $GLOBALS['backend']->sessionClose();
        } else {
            $GLOBALS['backend']->logMessage('SyncML: return message completed',
                                            __FILE__, __LINE__, PEAR_LOG_DEBUG);
        }
    }

}
