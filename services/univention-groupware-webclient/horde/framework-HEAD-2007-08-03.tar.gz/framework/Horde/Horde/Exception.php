<?php
/**
 * Horde base exception.
 *
 * $Horde: framework/Horde/Horde/Exception.php,v 1.1 2006/09/18 18:09:33 chuck Exp $
 *
 * @package Horde_Exception
 */
class Horde_Exception extends Exception {
}
