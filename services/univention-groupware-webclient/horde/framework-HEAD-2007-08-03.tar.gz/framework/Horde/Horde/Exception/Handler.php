<?php
/**
 * $Horde: framework/Horde/Horde/Exception/Handler.php,v 1.8 2007/07/20 18:20:42 chuck Exp $
 *
 * Inspired by:
 * http://www.sitepoint.com/blogs/2006/04/04/pretty-blue-screen/ and
 * http://www.sitepoint.com/blogs/2006/08/12/pimpin-harrys-pretty-bluescreen/.
 *
 * Also see for future ideas:
 * http://mikenaberezny.com/archives/55
 *
 * @package Horde_Exception
 */

/**
 * Register the handlers.
 */
set_exception_handler(array('Horde_Exception_Handler', 'handleException'));
set_error_handler(array('Horde_Exception_Handler', 'handleError'));

/**
 * Register the default configuration.
 */
Horde_Exception_Handler::$config = new Horde_Exception_Handler_Configuration();

/**
 * The error handler configuration object.
 *
 * @package Horde_Exception
 */
class Horde_Exception_Handler_Configuration {

    /**
     * What threshhold should we set for PHP errors? 2039 is E_ALL &~
     * E_NOTICE.
     */
    public $level = E_ALL;

    /**
     * Show a debug dump of exceptions and errors? This is not
     * appropriate for production systems as it will likely reveal
     * sensitive information.
     */
    public $debug = false;

}

/**
 * Handles errors and exceptions
 *
 * @package Horde_Exception
 */
class Horde_Exception_Handler {

    public static $config;

    /**
     * Hook for error handling
     *
     * @param integer Error level
     * @param string Error message
     * @param string Error file
     * @param integer Line
     * @param array Context (all defined vars)
     */
    public static function handleError($errno, $errstr, $errfile, $errline, $errcontext)
    {
        /* Check if error needs to be handled */
        if (($errno & self::$config->level) != $errno) {
            return;
        }

        /* Error types */
        $error_types = array(
            1 => 'ERROR',
            2 => 'WARNING',
            4 => 'PARSE',
            8 => 'NOTICE',
            16 => 'CORE_ERROR',
            32 => 'CORE_WARNING',
            64 => 'COMPILE_ERROR',
            128 => 'COMPILE_WARNING',
            256 => 'USER_ERROR',
            512 => 'USER_WARNING',
            1024 => 'USER_NOTICE',
            2047 => 'ALL',
            2048 => 'STRICT',
            4096 => 'RECOVERABLE_ERROR');

        $details['type'] = 'Error';
        $details['code'] = $error_types[$errno];
        $details['message'] = preg_replace("%\s\[<a href='function\.[\d\w-_]+'>function\.[\d\w-_]+</a>\]%", '', $errstr);
        $details['line'] = $errline;
        $details['file'] = $errfile;

        /* Build exception-like backtrace. */
        $backtrace = debug_backtrace();
        $details['trace'] = array();
        for ($i = 1, $iMax = count($backtrace); $i < $iMax; $i++) {
            $details['trace'][$i - 1]['file'] = @$backtrace[$i]['file'];
            $details['trace'][$i - 1]['line'] = @$backtrace[$i]['line'];
            $details['trace'][$i - 1]['function'] = @$backtrace[$i]['function'];
            $details['trace'][$i - 1]['class'] = @$backtrace[$i]['class'];
            $details['trace'][$i - 1]['type'] = @$backtrace[$i]['type'];
            $details['trace'][$i - 1]['args'] = @$backtrace[$i]['args'];
        }

        return self::handleAny($details);
    }

    /**
     * Hook for exception handling.
     *
     * @param Exception $e Exception to handle.
     */
    public static function handleException($e)
    {
        return self::handleAny(array(
            'type' => get_class($e),
            'code' => $e->getCode(),
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'trace' => $e->getTrace(),
        ));
    }

    /**
     * Handle either Errors or Exceptions
     *
     * @param array $details
     */
    public static function handleAny($details)
    {
        if (self::$config->debug) {
            self::dump($details);
        }
    }

    /**
     * A static function to nicely output exceptions.
     *
     * @param array $input @see self::displayException()
     */
    public static function dump($input)
    {
        // Store previous output.
        $previous_output = ob_get_contents();

        $desc = $input['type'] . ' making ' . $_SERVER['REQUEST_METHOD'] . ' request to ' . $_SERVER['REQUEST_URI'];
        ?>
        <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
          "http://www.w3.org/TR/html4/loose.dtd">
        <html lang="en">
        <head>
          <meta http-equiv="content-type" content="text/html; charset=utf-8" />
          <meta name="robots" content="NONE,NOARCHIVE" />
          <title><?php echo htmlspecialchars($desc) ?></title>
          <style type="text/css">
            html * { padding:0; margin:0; }
            body * { padding:10px 20px; }
            body * * { padding:0; }
            body { font:small sans-serif; background: #fff; }
            body>div { border-bottom:1px solid #aaa; }
            h1 { font-weight:normal; }
            h2 { margin-bottom:.8em; }
            h2 span { font-size:80%; color:#666; font-weight:normal; }
            h2 a { text-decoration:none; }
            h3 { margin:1em 0 .5em 0; }
            h4 { margin:0.5em 0 .5em 0; font-weight: normal; font-style: italic; }
            table { border:1px solid #ccc; border-collapse: collapse; background:#fff; }
            tbody td, tbody th { vertical-align:top; padding:2px 3px; }
            thead th { padding:1px 6px 1px 3px; background:#e9e9e9; text-align:left; font-weight:bold; font-size:90%; border:1px solid #ddd; }
            tbody th { text-align:right; color:#666; padding-right:.5em; }
            table.vars { margin:5px 0 2px 40px; }
            table.vars td, table.req td { font-family:monospace; }
            table td { background: #e9e9e9; }
            table td.code { width:95%;}
            table td.code div { overflow:hidden; }
            table.source th { color:#666; }
            table.source td { font-family:monospace; white-space:pre; border-bottom:1px solid #eee; }
            ul.backtrace { list-style-type:none; }
            ul.backtrace li.frame { margin-bottom:1em; }
            ul.backtrace li.frame p { border: thin solid #ccc; padding: 2px; background: #e9e9e9; }
            div.context { margin:5px 0 2px 40px; background-color:#e9e9e9; border: thin solid #ddd; }
            div.context ol { padding-left:30px; margin:0 10px; list-style-position: inside; }
            div.context ol li { font-family:monospace; white-space:pre; color:#666 }
            div.context li.current-line { color:#000; background-color:#fff; }
            div.commands { margin-left: 40px; }
            div.commands a { color:black; text-decoration:none; }
            p.headers { background: #ccc; font-family:monospace; padding: 2px; }
            #summary { background: #000; color: #fff }
            #summary h2 { font-weight: normal; color: #ccc; }
            #backtrace { background:#fff; }
            #request { background:#f6f6f6; }
            #response { background:#eee; }
            #summary table { border:none; background: #000; color: #fff; }
            #summary th { color: #fff; }
            #summary td { background: #000; color: #fff; }
            .switch { text-decoration: none; }
            .whitemsg { background:white; color:black;}
          </style>
          <script type="text/javascript">
            function getElementsByClassName(oElm, strTagName, strClassName){
                // Written by Jonathan Snook, http://www.snook.ca/jon;
                // Add-ons by Robert Nyman, http://www.robertnyman.com
                var arrElements = (strTagName == "*" && document.all)? document.all :
                oElm.getElementsByTagName(strTagName);
                var arrReturnElements = [];
                strClassName = strClassName.replace(/\-/g, "\\-");
                var oRegExp = new RegExp("(^|\\s)" + strClassName + "(\\s|$)");
                var oElement;
                for (var i=0; i<arrElements.length; i++){
                    oElement = arrElements[i];
                    if (oRegExp.test(oElement.className)){
                        arrReturnElements.push(oElement);
                    }
                }
                return (arrReturnElements)
            }
            function hideAll(elems) {
              for (var e = 0; e < elems.length; e++) {
                elems[e].style.display = 'none';
              }
            }
            function toggle() {
              for (var i = 0; i < arguments.length; i++) {
                var e = document.getElementById(arguments[i]);
                if (e) {
                  e.style.display = e.style.display == 'none' ? 'block' : 'none';
                }
              }
              return false;
            }
            function varToggle(link, id, prefix) {
              toggle(prefix + id);
              var s = link.getElementsByTagName('span')[0];
              var uarr = String.fromCharCode(0x25b6);
              var darr = String.fromCharCode(0x25bc);
              s.innerHTML = s.innerHTML == uarr ? darr : uarr;
              return false;
            }
            function sectionToggle(span, section) {
              toggle(section);
              var span = document.getElementById(span);
              var uarr = String.fromCharCode(0x25b6);
              var darr = String.fromCharCode(0x25bc);
              span.innerHTML = span.innerHTML == uarr ? darr : uarr;
              return false;
            }

            window.onload = function() {
              hideAll(getElementsByClassName(document, 'table', 'vars'));
              hideAll(getElementsByClassName(document, 'div', 'context'));
              hideAll(getElementsByClassName(document, 'ul', 'backtrace'));
              hideAll(getElementsByClassName(document, 'div', 'section'));
            }
          </script>
        </head>
        <body>

        <div id="summary">
          <h1><?php echo htmlspecialchars($desc) ?></h1>
          <h2><?php if ($input['code']) echo htmlspecialchars($input['code']), ': ', htmlspecialchars($input['message']) ?></h2>
          <table>
            <tr>
              <th>PHP</th>
              <td><?php echo htmlspecialchars($input['file']), ' line ', htmlspecialchars($input['line']) ?></td>
            </tr>
            <tr>
              <th>URI</th>
              <td><?php echo htmlspecialchars($_SERVER['REQUEST_METHOD']), ' ', htmlspecialchars($_SERVER['REQUEST_URI']) ?></td>
            </tr>
          </table>
        </div>

        <div id="backtrace">
          <h2>Backtrace
            <a href='#' onclick="return sectionToggle('tb_switch', 'tb_list');">
            <span id="tb_switch">&#x25b6;</span></a></h2>
          <ul id="tb_list" class="backtrace">
            <?php $frames = $input['trace']; foreach ($frames as $frame_id => $frame) { ?>
              <li class="frame">
                <p>
                  <?php echo self::_sub($frame) ?>
                  [<?php echo htmlspecialchars($frame['file']) ?>, line <?php echo htmlspecialchars($frame['line']) ?>]
                </p>
                <?php
                if (count($frame['args']) > 0) {
                    $params = self::_parms($frame);
                ?>
                <div class="commands">
                  <a href='#' onclick="return varToggle(this, '<?php echo htmlspecialchars($frame_id) ?>','v')"><span>&#x25b6;</span> Args</a>
                </div>
                  <table class="vars" id="v<?php echo htmlspecialchars($frame_id) ?>">
                    <thead>
                      <tr>
                        <th>Arg</th>
                        <th>Name</th>
                        <th>Value</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($frame['args'] as $k => $v) {
                          $name = isset($params[$k]) ? '$' . $params[$k]->name : '?';
                        ?>
                        <tr>
                          <td><?php echo htmlspecialchars($k) ?></td>
                          <td><?php echo htmlspecialchars($name) ?></td>
                          <td class="code">
                            <div><?php if (is_object($v)) echo '<pre>' . print_r($v, true) . '</pre>'; else highlight_string(var_export($v, true)); ?></div>
                          </td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                  </table>
                <?php } if (is_readable($frame['file'])) { ?>
                <div class="commands">
                    <a href='#' onclick="return varToggle(this, '<?php echo htmlspecialchars($frame_id) ?>','c')"><span>&#x25b6;</span> Src</a>
                </div>
                <div class="context" id="c<?php echo htmlspecialchars($frame_id) ?>">
                  <?php
                  $lines = self::_src2lines($frame['file']);
                  $start = $frame['line'] < 5 ?
                    0 : $frame['line'] -5; $end = $start + 10;
                  $out = '';
                  foreach ($lines as $k => $line) {
                    if ($k > $end) break;
                    $line = trim(strip_tags($line));
                    if ($k < $start && isset($frames[$frame_id + 1]['function'])
                        && preg_match('/function( )*' . preg_quote($frames[$frame_id + 1]['function']) . '/', $line)) {
                      $start = $k;
                    }
                    if ($k >= $start) {
                      if ($k != $frame['line']) {
                          $out .= '<li><code>' . self::_clean($line) . '</code></li>' . "\n";
                      } else {
                          $out .= '<li class="current-line"><code>' .
                              self::_clean($line) . '</code></li>' . "\n";
                      }
                    }
                  }
                  echo "<ol start=\"$start\">\n".$out. "</ol>\n";
                  ?>
                </div>
                <?php } else { ?>
                <div class="commands">No source code available</div>
                <?php } ?>
              </li>
            <?php } ?>
          </ul>

        </div>

        <div id="request">
          <h2>Request
            <a href='#' onclick="return sectionToggle('req_switch', 'req_list')">
            <span id="req_switch">&#x25b6;</span></a></h2>
          <div id="req_list" class="section">
            <?php
            if (function_exists('apache_request_headers')) {
            ?>
            <h3>Request <span>(raw)</span></h3>
            <?php
              $req_headers = apache_request_headers();
                ?>
              <h4>HEADERS</h4>
              <?php
              if (count($req_headers) > 0) {
              ?>
                <p class="headers">
                <?php
                foreach ($req_headers as $req_h_name => $req_h_val) {
                  echo htmlspecialchars($req_h_name . ': ' . $req_h_val);
                  echo '<br />';
                }
                ?>
                </p>
              <?php } else { ?>
                <p>No headers.</p>
              <?php } ?>

              <?php
              $req_body = file_get_contents('php://input');
              if (strlen($req_body) > 0) {
              ?>
              <h4>Body</h4>
              <p class="req" style="padding-bottom: 2em"><code>
                <?php echo htmlspecialchars($req_body) ?>
              </code></p>
              <?php } ?>
            <?php } ?>
            <h3>Request <span>(parsed)</span></h3>
            <?php foreach (array('$_GET' => $_GET, '$_POST' => $_POST, '$_COOKIE' => $_COOKIE, '$_SERVER' => $_SERVER, '$_ENV' => $_ENV) as $sglobal_name => $sglobal) { ?>
            <h4><?php echo $sglobal_name ?></h4>
              <?php if (count($sglobal) > 0) { ?>
              <table class="req">
                <thead>
                  <tr>
                    <th>Variable</th>
                    <th>Value</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($sglobal as $k => $v): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($k) ?></td>
                      <td class="code">
                        <div><?php echo htmlspecialchars(var_export($v, true)) ?></div>
                        </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
              <?php } else { ?>
              <p class="whitemsg">No data</p>
              <?php } } ?>
          </div>
        </div>

        <div id="response">
          <h2>Response
            <a href='#' onclick="return sectionToggle('resp_switch','resp_list')">
            <span id="resp_switch">&#x25b6;</span></a></h2>

          <div id="resp_list" class="section">
            <h3>Headers</h3>
            <?php
            $resp_headers = headers_list();
            if (count($resp_headers) > 0):
            ?>
            <p class="headers">
              <?php
              foreach ($resp_headers as $resp_h) {
                echo htmlspecialchars($resp_h);
                echo '<br />';
              }
              ?>
            </p>
            <?php else: ?>
              <p>No headers.</p>
            <?php endif; ?>
            <?php if (!empty($previous_output)): ?>
              <p class="headers" style="padding-bottom: 1em; padding-top:1em; margin-top:1em;">
                <?php echo htmlspecialchars($previous_output) ?>
              </p>
            <?php endif; ?>
          </div>
        </div>

        </body>
        </html>
        <?php
        exit;
    }

    private static function _sub($f)
    {
        $loc = '';
        if (isset($f['class'])) {
            $loc .= $f['class'] . $f['type'];
        }
        if (isset($f['function'])) {
            $loc .= $f['function'];
        }
        if (!empty($loc)) {
            $loc = htmlspecialchars($loc);
            $loc = "<strong>$loc</strong>";
        }
        return $loc;
    }

    private static function _clean($line)
    {
        $l = trim(strip_tags($line));
        return $l ? $l : '&nbsp;';
    }

    private static function _parms($f)
    {
        if (isset($f['function'])) {
            try {
                if (isset($f['class'])) {
                    $r = new ReflectionMethod($f['class'] . '::' . $f['function']);
                } else {
                    $r = new ReflectionFunction($f['function']);
                }
                return $r->getParameters();
            } catch(Exception $e) {}
        }
        return array();
    }

    private static function _src2lines($file)
    {
        $src = nl2br(highlight_file($file, true));
        return explode('<br />', $src);
    }

}
