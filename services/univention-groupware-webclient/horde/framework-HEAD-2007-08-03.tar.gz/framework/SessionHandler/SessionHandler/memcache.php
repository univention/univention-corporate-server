<?php

require_once 'Horde/Memcache.php';

/**
 * SessionHandler:: implementation for memcache.
 *
 * NOTE FOR WINDOWS USERS w/PHP 4: Due to limitations in PHP 4, you should not
 * use the memcache driver.  Either upgrade to PHP 5 or use a different
 * session handler.
 *
 * Optional parameters:<pre>
 *   'track' - (boolean) Track active sessions?
 * </pre>
 *
 * $Horde: framework/SessionHandler/SessionHandler/memcache.php,v 1.8 2007/06/14 20:07:21 slusarz Exp $
 *
 * Copyright 2005-2007 Rong-En Fan <rafan@infor.org>
 * Copyright 2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Rong-En Fan <rafan@infor.org>
 * @author  Michael Slusarz <slusarz@curecanti.org>
 * @since   Horde 3.1
 * @package Horde_SessionHandler
 */
class SessionHandler_memcache extends SessionHandler {

    /**
     * Horde_Memcache object.
     *
     * @var Horde_Cache
     */
    var $_memcache;

    /**
     * Current session ID.
     *
     * @var string
     */
    var $_id;

    /**
     * Constructs a new SessionHandler object.
     *
     * @param array $params  A hash containing connection parameters.
     */
    function SessionHandler_memcache($params = array())
    {
        $this->_memcache = &Horde_Memcache::singleton();

        parent::SessionHandler($params);

        // Garbage collection for session tracking information - run 0.1% of
        // all session accesses.
        if (!empty($this->_params['track']) && (rand(0, 999) == 0)) {
            register_shutdown_function(array(&$this, '_trackGC'));
        }
    }

    /**
     * Close the SessionHandler backend.
     *
     * @return boolean  True on success, false otherwise.
     */
    function close()
    {
        $this->_memcache->unlock($this->_id);
        return true;
    }

    /**
     * Read the data for a particular session identifier.
     *
     * @param string $id  The session identifier.
     *
     * @return string  The session data.
     */
    function read($id)
    {
        $this->_memcache->lock($id);
        $result = $this->_memcache->get($id);

        if ($result === false) {
            $this->_memcache->unlock($id);
            Horde::logMessage('Error retrieving session data (id = ' . $id . ')', __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }

        $this->_id = $id;
        Horde::logMessage('Read session data (id = ' . $id . ')', __FILE__, __LINE__, PEAR_LOG_DEBUG);
        return $result;
    }

    /**
     * Write session data to the SessionHandler backend.
     *
     * @param string $id            The session identifier.
     * @param string $session_data  The session data.
     *
     * @return boolean  True on success, false otherwise.
     */
    function write($id, $session_data)
    {
        $res = $track = false;

        if (!empty($this->_params['track'])) {
            // Do a replace - the only time it should fail is if we are
            // writing a session for the first time.  If that is the case,
            // update the session tracker.
            $res = $this->_memcache->replace($id, $session_data, ini_get('session.gc_maxlifetime'));
            $track = ($res === false);
        }

        if ($res === false) {
            $res = $this->_memcache->set($id, $session_data, ini_get('session.gc_maxlifetime'));
        }

        if ($res === false) {
            Horde::logMessage('Error writing session data (id = ' . $id . ')', __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }

        if ($track) {
            $ids = $this->_memcache->get('horde_memcache_sessions_track');
            if ($ids === false) {
                $ids = array();
            }

            $ids[$id] = time();
            $this->_memcache->set('horde_memcache_sessions_track', $ids);
        }

        Horde::logMessage('Wrote session data (id = ' . $id . ')', __FILE__, __LINE__, PEAR_LOG_DEBUG);
        return true;
    }

    /**
     * Destroy the data for a particular session identifier.
     *
     * @param string $id  The session identifier.
     *
     * @return boolean  True on success, false otherwise.
     */
    function destroy($id)
    {
        $result = $this->_memcache->delete($id);
        $this->_memcache->unlock($id);

        if ($result === false) {
            Horde::logMessage('Failed to delete session (id = ' . $id . ')', __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }

        if (!empty($this->_params['track'])) {
            $ids = $this->_memcache->get('horde_memcache_sessions_track');
            if ($ids !== false) {
                unset($ids[$id]);
                $this->_memcache->set('horde_memcache_sessions_track', $ids);
            }
        }

        Horde::logMessage('Deleted session data (id = ' . $id . ')', __FILE__, __LINE__, PEAR_LOG_DEBUG);
        return true;
    }

    /**
     * Garbage collect stale sessions from the SessionHandler backend.
     *
     * @param integer $maxlifetime  The maximum age of a session.
     *
     * @return boolean  True on success, false otherwise.
     */
    function gc($maxlifetime = 300)
    {
        // Memcache does its own garbage collection.
        return true;
    }

    /**
     * Get a list of (possibly) valid session identifiers.
     *
     * @return array  A list of session identifiers.
     */
    function getSessionIDs()
    {
        if (empty($this->_params['track'])) {
            return PEAR::raiseError(_("Memcache session tracking not enabled."));
        }

        $ids = $this->_memcache->get('horde_memcache_sessions_track');
        return ($ids === false) ? array() : array_keys($ids);
    }

    /**
     * Get session data read-only.
     *
     * @access private
     *
     * @param string $id  The session identifier.
     *
     * @return string  The session data.
     */
    function _readOnly($id)
    {
        return $this->_memcache->get($id);
    }

    /**
     * Do garbage collection for session tracking information.
     *
     * @access private
     */
    function _trackGC()
    {
        $ids = $this->_memcache->get('horde_memcache_sessions_track');
        $tstamp = time() - ini_get('session.gc_maxlifetime');
        $alter = false;

        foreach ($ids as $key => $val) {
            if ($tstamp > $val && !$this->_memcache->get($id)) {
                unset($ids[$key]);
                $alter = true;
            }
        }

        if ($alter) {
            $this->_memcache->set('horde_memcache_sessions_track', $ids);
        }
    }

}
