<?php
/**
 * SessionHandler:: implementation that serializes session data in memcached and writes-through to
 * mysql.
 * memcache website: http://www.danga.com/memcached/
 *
 * Required parameters:<pre>
 *   'hostspec-mc'  The hostname of memcache server
 *   'port-mc'      The port on which to connect to the memcache server.
 *   'hostspec-db'   - The hostname of the database server.
 *   'protocol'   - The DB communication protocol ('tcp', 'unix', etc.).
 *   'username'   - The DB username with which to connect to the database.
 *   'password'   - The DB password associated with 'username'.
 *   'database'   - The name of the database.
 *   'table'      - The name of the sessiondata table in 'database'.
 *   'rowlocking' - Whether to use row-level locking and transactions (InnoDB)
 *                  or table-level locking (MyISAM).</pre>
 *
 * Optional DB parameters:<pre>
 *   'port-db'  The port on which to connect to the database.
 *   'persistent-db'  Use persistent DB connections? (boolean)</pre>
 *
 * Optional memcache parameters:<pre>
 *   'persistent-mc'  Use persistent memcached connections? (boolean)
 *   'compression-mc' Use compression when storing sessions. </pre>
 *
 * $Horde: framework/SessionHandler/SessionHandler/memcache_mysql.php,v 1.1 2007/06/29 20:47:48 chuck Exp $
 *
 * Copyright 2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Aaron Lee <shiftee@gmail.com>
 * @since   Horde 3.2
 * @package Horde_SessionHandler
 */
class SessionHandler_memcache_mysql extends SessionHandler {

    /**
     * MySQL session handler
     */
    var $_db;

    /**
     * Memcache session handler
     */
    var $_mc;

    /**
     * Configuration params for the Memcache driver
     *
     * @var array
     */
    var $_params_mc;

    /**
     * Configuration params for the MySQL driver
     *
     * @var array
     */
    var $_params_db;

    /**
     * Connected state
     *
     * @var boolean
     */
    var $_connected_all = false;

    /**
     * Close the SessionHandler backends
     *
     * @return boolean True on success, false otherwise.
     */
    function close()
    {
        if ($this->_connected_all) {
            if (!$this->_db->close()) {
                return false;
            }
            return $this->_mc->close();
        }
        return true;
    }

    /**
     * Read a session from the datastores, preferring memcache hits over mysql
     *
     * @param string $id The session identifier
     *
     * @return string The session data
     */
    function read($id)
    {
        /* Make sure we are connected. */
        if (is_a(($result = $this->_connect()), 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }

        /* First look for data in memcache */
        $result = $this->_mc->read($id);
        if (!$result) {
            // Cache miss
            Horde::logMessage("memcache cache miss session = $id",__FILE__, __LINE__,PEAR_LOG_WARN);
            $result = $this->_db->read($id);
        }
        if (!$result) {
            // Not in either store.
            Horde::logMessage('Error retrieving session data from memcache AND mysql (id = ' . $id . ')', __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }
        return $result;
    }

    /**
     * Write a session to the datastores (both)
     */
    function write($id, $session_data)
    {
        /* Make sure we are connected. */
        if (is_a(($result = $this->_connect()), 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }

        if (!$this->_mc->write($id, $session_data)) {
            return false;
        }
        return $this->_db->write($id, $session_data);
    }

    /**
     * Destroy the data for a particular session identifier in the
     * SessionHandler backend.
     *
     * @param string $id  The session identifier.
     *
     * @return boolean  True on success, false otherwise.
     */
    function destroy ($id)
    {
        /* Make sure we are connected. */
        if (is_a(($result = $this->_connect()), 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }

        if (!$this->_mc->destroy($id)) {
            return false;
        }
        return $this->_db->destroy($id);
    }

    /**
     * Garbage collect stale sessions from the SessionHandler backend.
     *
     * @param integer $maxlifetime  The maximum age of a session.
     *
     * @return boolean  True on success, false otherwise.
     */
    function gc($maxlifetime = 300)
    {
        /* Make sure we are connected. */
        if (is_a(($result = $this->_connect()), 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }

        if (!$this->_mc->gc($maxlifetime)) {
            return false;
        }
        return $this->_db->gc($maxlifetime);
    }

    /**
     * Get a list of the valid session identifiers (from the mysql driver)
     *
     * @return array  A list of valid session identifiers.
     */
    function getSessionIDs()
    {
        return $this->_db->getSessionIDs();
    }

    /**
     * Construct memcache and mysql drivers
     */
    function _connect()
    {
        if ($this->_connected_all) {
            return true;
        }

        // Setup config parameters for the mysql driver
        $this->_params_db = $this->_params;
        $params = array('persistent-db', 'port-db', 'hostspec-db', 'hostspec-mc', 'persistent-mc', 'port-mc', 'compression-mc');

        // Set optional/required parameters into _params_db hashspace
        if (isset ($this_params['persistent-db'])) {
            $this->_params_db['persistent'] = $this->_params['persistent-db'];
        }
        if (isset ($this_params['port-db'])) {
            $this->_params_db['port'] = $this->_params['port-db'];
        }
        $this->_params_db['hostspec'] = $this->_params['hostspec-db'];

        $this->_db = SessionHandler::singleton('mysql', $this->_params_db);
        if (is_a($this->_db, 'PEAR_Error')) {
            return $this->_db;
        }
        if (is_a(($result = $this->_db->_connect()), 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return $result;
        }

        // Setup config params for the memcache driver
        $this->_params_mc = $this->_params;

        // Set optional/required params into _params_mc hashspace
        if (isset($this->_params['hostspec-mc'])) {
            $this->_params_mc['hostspec'] = $this->_params['hostspec-mc'];
        }
        if (isset($this->_params['port-mc'])) {
            $this->_params_mc['port'] = $this->_params['port-mc'];
        }
        if (isset($this->_params['persistent-mc'])) {
            $this->_params_mc['persistent'] = $this->_params['persistent-mc'];
        }
        if (isset($this->_params['compression-mc'])) {
            $this->_params_mc['compression'] = $this->_params['compression-mc'];
        }

        $this->_mc = SessionHandler::singleton('memcache', $this->_params_mc);
        if (is_a($this->_mc, 'PEAR_Error')) {
            return $this->_mc;
        }
        if (is_a(($result = $this->_mc->_connect()), 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return $result;
        }

        $this->_connected_all = true;
        return true;
    }

}
