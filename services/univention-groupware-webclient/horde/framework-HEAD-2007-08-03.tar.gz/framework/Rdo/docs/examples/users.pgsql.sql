-- $Horde: framework/Rdo/docs/examples/users.pgsql.sql,v 1.1 2007/04/28 01:21:15 chuck Exp $
CREATE TABLE users (
    id bigserial NOT NULL,
    name varchar(255),
    favorite_id integer,
    phone varchar(20),
    created varchar(10),
    updated varchar(10),

    PRIMARY KEY  (id)
);
