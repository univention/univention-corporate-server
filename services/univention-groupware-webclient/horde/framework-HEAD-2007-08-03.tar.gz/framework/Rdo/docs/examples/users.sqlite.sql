-- $Horde: framework/Rdo/docs/examples/users.sqlite.sql,v 1.1 2007/04/28 01:21:15 chuck Exp $
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(255),
    favorite_id INTEGER,
    phone VARCHAR(20),
    created VARCHAR(10),
    updated VARCHAR(10)
);
