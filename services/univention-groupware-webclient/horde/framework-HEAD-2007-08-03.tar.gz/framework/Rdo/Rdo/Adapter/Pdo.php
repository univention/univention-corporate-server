<?php
/**
 * @category Horde
 * @package Horde_Rdo
 */

/**
 * PDO Horde_Rdo_Adapter generic implementation. Provides most
 * functionality but must be extended with a concrete implementation
 * to fill in database-specific details.
 *
 * @category Horde
 * @package Horde_Rdo
 */
abstract class Horde_Rdo_Adapter_Pdo extends Horde_Rdo_Adapter {

    /**
     * PDO database connection object.
     *
     * @var PDO
     */
    protected $_db = null;

    /**
     * Free any resources that are open.
     */
    public function __destruct()
    {
        if ($this->_db) {
            $this->_db = null;
        }
    }

    /**
     * Create a backend object.
     *
     * @param Horde_Rdo_Mapper $mapper The Mapper creating the object.
     * @param array $fields Hash of field names/new values.
     *
     * @return integer The new object's primary key value, or throw an
     * exception if any errors occur.
     */
    public function create($mapper, $fields)
    {
        if (!$fields) {
            throw new Horde_Rdo_Exception('create() requires at least one field value.');
        }

        $sql = 'INSERT INTO ' . $this->_dml->quoteIdentifier($mapper->model->table);
        $keys = array();
        $placeholders = array();
        $bindParams = array();
        foreach ($fields as $field => $value) {
            $keys[] = $this->_dml->quoteIdentifier($field);
            $placeholders[] = '?';
            $bindParams[] = $value;
        }
        $sql .= ' (' . implode(', ', $keys) . ') VALUES (' . implode(', ', $placeholders) . ')';

        $this->execute($sql, $bindParams);
        return $this->_lastInsertId($mapper->model->table . '_' . $mapper->model->key . '_seq');
    }

    /**
     * Updates a backend object.
     *
     * @param Horde_Rdo_Mapper $mapper The Mapper requesting the update.
     * @param scalar $id The unique key of the object being updated.
     * @param array $fields Hash of field names/new values.
     *
     * @return integer Number of objects updated.
     */
    public function update($mapper, $id, $fields)
    {
        if (!$fields) {
            // Nothing to change.
            return true;
        }

        $sql = 'UPDATE ' . $this->_dml->quoteIdentifier($mapper->model->table) . ' SET';
        $bindParams = array();
        foreach ($fields as $field => $value) {
            $sql .= ' ' . $this->_dml->quoteIdentifier($field) . ' = ?,';
            $bindParams[] = $value;
        }
        $sql = substr($sql, 0, -1) . ' WHERE ' . $mapper->model->key . ' = ?';
        $bindParams[] = $id;

        return $this->execute($sql, $bindParams);
    }

    /**
     * Delete one or more objects from the database.
     *
     * @param Horde_Rdo_Mapper $mapper The Mapper requesting the deletion.
     * @param array|Horde_Rdo_Query $query Description of what to delete.
     *
     * @return integer Number of objects deleted.
     */
    public function delete($mapper, $query)
    {
        $query = Horde_Rdo_Query::create($query, $mapper);

        $clauses = array();
        $bindParams = array();
        foreach ($query->tests as $test) {
            $clauses[] = $this->_dml->quoteIdentifier($test['field']) . ' ' . $test['test'] . ' ?';
            $bindParams[] = $test['value'];
        }
        if (!$clauses) {
            throw new Horde_Rdo_Exception('Refusing to delete the entire table.');
        }

        $sql = 'DELETE FROM ' . $this->_dml->quoteIdentifier($mapper->model->table) .
               ' WHERE ' . implode(' ' . $query->conjunction . ' ', $clauses);

        return $this->execute($sql, $bindParams);
    }

    /**
     * Use for SELECT and anything that returns rows.
     *
     * @param string $sql A full SQL query to run.
     * @param array $bindParams Any parameters to bind to the query.
     *
     * @return PDOStatement Result set.
     */
    public function select($sql, $bindParams = array())
    {
        $statement = $this->_db->prepare($sql);
        if (!$statement) {
            throw new Horde_Rdo_Exception(implode(', ', $this->_db->errorInfo()) . ', ' . $sql);
        }

        try {
            $statement->execute($bindParams);
        } catch (Exception $e) {
            throw new Horde_Rdo_Exception('Unable to excecute query: ' . $e->getMessage());
        }

        return $statement;
    }

    /**
     * Return a single value from a query. Useful for quickly getting
     * a value such as with a COUNT(*) query.
     *
     * @param string $sql The SQL to get one result from.
     *
     * @return mixed The first value of the first row matched by $sql.
     */
    public function selectOne($sql, $bindParams = array())
    {
        $statement = $this->_db->prepare($sql);
        if (!$statement->execute($bindParams)) {
            throw new Horde_Rdo_Exception(implode(', ', $statement->errorInfo()));
        }
        return $statement->fetchColumn();
    }

    /**
     * Use for INSERT, UPDATE, DELETE, and other queries that don't
     * return rows. Returns number of affected rows.
     *
     * @param string $sql The query to run.
     * @param array $bindParams Any parameters to bind to the query.
     *
     * @return integer The number of rows affected by $sql.
     */
    public function execute($sql, $bindParams = array())
    {
        $statement = $this->_db->prepare($sql);
        if (!$statement->execute($bindParams)) {
            throw new Horde_Rdo_Exception(implode(', ', $statement->errorInfo()));
        }
        return $statement->rowCount();
    }

    /**
     */
    public function beginTransaction()
    {
        return $this->_db->beginTransaction();
    }

    /**
     */
    public function commit()
    {
        return $this->_db->commit();
    }

    /**
     */
    public function rollBack()
    {
        return $this->_db->rollBack();
    }

    /**
     * Build a connection string and connect to the database server.
     */
    protected function _connect()
    {
        $dsn = $this->getOption('dsn');
        if (!$dsn) {
            $dsn = 'dbname=' . $this->getOption('database');
            if ($hs = $this->getOption('hostspec')) {
                $dsn .= ';host=' . $hs;
            }
        }

        try {
            $this->_db = new PDO($this->getOption('phptype') . ':' . $dsn,
                                 $this->getOption('username'),
                                 $this->getOption('password'));
            $this->_db->setAttribute(PDO::ATTR_STATEMENT_CLASS, array('Horde_Rdo_Adapter_Pdo_Cursor', array()));
            $this->_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            // Catch and re-throw this exception as a stack trace may
            // contain the database password.
            throw new Horde_Rdo_Exception('Connect failed: ' . $e->getMessage());
        }
    }

    /**
     * @param string $sequence The name of the sequence to get the
     * latest value in.
     *
     * @return integer The last auto-generated row id for $sequence
     */
    protected function _lastInsertId($sequence)
    {
        return $this->_db->lastInsertId($sequence);
    }

}
