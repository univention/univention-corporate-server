<?php
/**
 * @category Horde
 * @package Horde_Rdo
 */

/**
 * @TODO
 */
class Horde_Rdo_Adapter_Mysqli extends Horde_Rdo_Adapter {
}
