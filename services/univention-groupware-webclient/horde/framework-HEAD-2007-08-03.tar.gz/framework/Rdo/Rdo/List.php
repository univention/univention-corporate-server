<?php
/**
 * @category Horde
 * @package Horde_Rdo
 */

/**
 * Iterator for collections of Rdo objects.
 *
 * @TODO implement ArrayAccess as well?
 *
 * @category Horde
 * @package Horde_Rdo
 */
class Horde_Rdo_List implements Iterator, Countable {

    /**
     * Rdo Mapper
     * @var Horde_Rdo_Mapper
     */
    protected $_mapper;

    /**
     * Rdo Query
     * @var Horde_Rdo_Query
     */
    protected $_query;

    /**
     * Query resource
     * @var Iterator
     */
    protected $_result;

    /**
     * Current object
     * @var Horde_Rdo_Base
     */
    protected $_current;

    /**
     * Current list offset.
     * @var integer
     */
    protected $_index;

    /**
     * Are we at the end of the list?
     * @var boolean
     */
    protected $_eof;

    /**
     * Constructor.
     *
     * @param mixed $query Description of query to run when results are requested.
     * @param integer $mode
     * @param Horde_Rdo_Mapper $mapper Mapping object this result set came from.
     */
    public function __construct($query, $mode = Horde_Rdo::FIND_ALL, $mapper = null)
    {
        $this->_query = Horde_Rdo_Query::create($query, $mapper);

        if ($mode == Horde_Rdo::FIND_FIRST) {
            $this->_query->limit(1);
        }

        if ($this->_query->mapper) {
            $this->_mapper = $this->_query->mapper;
        } elseif (!is_null($mapper)) {
            $this->_query->setMapper($mapper);
            $this->_mapper = $mapper;
        } else {
            throw new Horde_Rdo_Exception('Mapper must be set on the Query object or explicitly passed.');
        }
    }

    /**
     * Destructor - release any resources.
     */
    public function __destruct()
    {
        if ($this->_result) {
            unset($this->_result);
        }
    }

    /**
     * Number of items in the list.
     *
     * This may trigger a seperate COUNT(*) query to the backend if the
     * database doesn't support "num_rows"-like functionality.
     */
    public function count()
    {
        return $this->_mapper->adapter->count($this->_query);
    }

    /**
     * List the columns in this List.
     *
     * @return array An array of column names (data names, not human names).
     */
    public function columns()
    {
        return $this->_mapper->model->listFields();
    }

    /**
     * Get detailed information on one column in this List.
     *
     * @return Column information
     */
    public function column($column)
    {
        return $this->_mapper->model->getField($column);
    }

    /**
     * Sort by a given field. Rewinds the query if it has already started.
     *
     * @param string $field      Field to sort by
     * @param string $direction  Direction: one of the Horde_Rdo::SORT_ constants
     */
    public function sortBy($field, $direction = Horde_Rdo::SORT_ASC)
    {
        $this->_result = null;
        $this->_query->sortBy($field, $direction);
    }

    /**
     * Restrict the list to a subset of the query results. Rewinds the
     * query if it has already started.
     *
     * @param integer $limit Number of items to fetch.
     * @param integer $offset Offset to start fetching at.
     */
    public function limit($limit, $offset = null)
    {
        $this->_result = null;
        $this->_query->limit($limit, $offset);
    }

    /**
     * Implementation of the rewind() method for iterator.
     */
    public function rewind()
    {
        if ($this->_result) {
            $this->_result = null;
        }
        $this->_current = null;
        $this->_index = null;
        $this->_eof = true;
        $this->_result = $this->_mapper->adapter->query($this->_query);

        $this->next();
    }

    /**
     * Implementation of the current() method for iterator.
     *
     * @return mixed The current row, or null if no rows.
     */
    public function current()
    {
        if (is_null($this->_result)) {
            $this->rewind();
        }
        return $this->_current;
    }

    /**
     * Implementation of the key() method for iterator.
     *
     * @return mixed The current row number (starts at 0), or NULL if no rows
     */
    public function key()
    {
        if (is_null($this->_result)) {
            $this->rewind();
        }
        return $this->_index;
    }

    /**
     * Implementation of the next() method.
     *
     * @return Horde_Rdo_Base|null The next Rdo object in the set or
     * null if no more results.
     */
    public function next()
    {
        if (is_null($this->_result)) {
            $this->rewind();
        }

        if ($this->_result) {
            $next = $this->_result->fetch();
            if (!$next) {
                $this->_eof = true;
            } else {
                $this->_eof = false;

                if (is_null($this->_index)) {
                    $this->_index = 0;
                } else {
                    ++$this->_index;
                }

                $this->_current = $this->_mapper->map($next);
            }
        }

        return $this->_current;
    }

    /**
     * Implementation of the valid() method for iterator
     *
     * @return boolean Whether the iteration is valid
     */
    public function valid()
    {
        if (is_null($this->_result)) {
            $this->rewind();
        }
        return !$this->_eof;
    }

}
