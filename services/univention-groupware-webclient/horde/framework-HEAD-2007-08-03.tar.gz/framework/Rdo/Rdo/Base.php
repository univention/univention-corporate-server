<?php
/**
 * @category Horde
 * @package Horde_Rdo
 */

/**
 * Horde_Rdo_Base abstract class (Rampage Data Objects). Entity
 * classes extend this baseline.
 *
 * @category Horde
 * @package Horde_Rdo
 */
abstract class Horde_Rdo_Base implements IteratorAggregate {

    /**
     * The Horde_Rdo_Mapper instance associated with this Rdo object. The
     * Mapper takes care of all backend access.
     *
     * @see Horde_Rdo_Mapper
     * @var Horde_Rdo_Mapper
     */
    protected $_mapper;

    /**
     * Constructor. Can be called directly by a programmer, or is
     * called in Horde_Rdo_Mapper::map(). Takes an associative array
     * of initial property values.
     *
     * @param array $fields Initial property values for the new object.
     *
     * @see Horde_Rdo_Mapper::map()
     */
    public function __construct($fields = array())
    {
        foreach ($fields as $key => $val) {
            $this->$key = $val;
        }
    }

    /**
     * When Rdo objects are cloned, unset the unique id that
     * identifies them so that they can be modified and saved to the
     * backend as new objects. If you don't really want a new object,
     * don't clone.
     */
    public function __clone()
    {
        // @TODO Support composite primary keys
        unset($this->{$this->getMapper()->model->key});
    }

    /**
     * Fetch properties that haven't yet been loaded. Lazy-loaded
     * fields and lazy-loaded relationships are handled this way. Once
     * a property is retrieved, it is set as $this->property so that
     * it doesn't need to be fetched again.
     *
     * @param string $property The name of the property to access.
     *
     * @return mixed The value of $property or null.
     */
    public function __get($property)
    {
        $mapper = $this->getMapper();

        // Look for lazy fields first, then relationships.
        if (in_array($property, $mapper->lazyFields)) {
            // @TODO Support composite primary keys
            $query = new Horde_Rdo_Query($mapper);
            $query->setFields($property)
                  ->addTest($mapper->model->key, '=', $this->{$mapper->model->key});
            $this->$property = $mapper->adapter->queryOne($query);
            return $this->$property;
        } elseif (isset($mapper->lazyRelationships[$property])) {
            $rel = $mapper->lazyRelationships[$property];
        } else {
            return null;
        }

        // Try to find the Mapper class for the object the
        // relationship is with, and fail if we can't.
        if (isset($rel['mapper'])) {
            $m = new $rel['mapper']();
        } else {
            $m = $mapper->inflector->tableToMapper($property);
            if (is_null($m)) {
                return null;
            }
        }

        // Based on the kind of relationship, fetch the appropriate
        // objects and fill the cache.
        switch ($rel['type']) {
        case Horde_Rdo::ONE_TO_ONE:
        case Horde_Rdo::MANY_TO_ONE:
            $this->$property = $m->find($this->{$rel['foreignKey']});
            break;

        case Horde_Rdo::ONE_TO_MANY:
            $this->$property = $this->cache($property,
                                   $m->find(Horde_Rdo::FIND_ALL,
                                            array($rel['foreignKey'] => $this->{$rel['foreignKey']})));
            break;

        case Horde_Rdo::MANY_TO_MANY:
            $key = $mapper->model->key;
            $query = new Horde_Rdo_Query();
            $on = isset($rel['on']) ? $rel['on'] : $m->model->key;
            $query->addRelationship($property, $mapper, $rel['through'], array($on => new Horde_Rdo_Query_Literal($on), $key => $this->$key));
            $this->$property = $m->find(Horde_Rdo::FIND_ALL, $query);
            break;

        case Horde_Rdo::CUSTOM:
            $query = array();
            foreach ($rel['on'] as $field => $value) {
                if (preg_match('/^@(.*)@$/', $value, $matches)) {
                    $query[$field] = $this->{$matches[1]};
                } else {
                    $query[$field] = $value;
                }
            }
            $this->$property = $m->find($rel['mode'], $query);
            break;
        }

        return $this->$property;
    }

    /**
     * Allow using isset($rdo->foo) to check for property or
     * relationship presence.
     *
     * @param string $property The property name to check existance of.
     */
    public function __isset($property)
    {
        $m = $this->getMapper();
        return isset($m->fields[$property])
            || isset($m->lazyFields[$property])
            || isset($m->relationships[$property])
            || isset($m->lazyRelationships[$property]);
    }

    /**
     * Allow using unset($rdo->foo) to unset a basic
     * property. Relationships cannot be unset in this way.
     *
     * @param string $property The property name to unset.
     */
    public function __unset($property)
    {
        // @TODO Should unsetting a MANY_TO_MANY relationship remove
        // the relationship?
    }

    /**
     * Implement the IteratorAggregate interface. Looping over an Rdo
     * object goes through each property of the object in turn.
     *
     * @return Horde_Rdo_Iterator The Iterator instance.
     */
    public function getIterator()
    {
        return new Horde_Rdo_Iterator($this);
    }

    /**
     * Get a Mapper instance that can be used to manage this
     * object. The Mapper instance can come from a few places:
     *
     * - If the class <RdoClassName>Mapper exists, it will be used
     *   automatically.
     *
     * - Any Rdo instance created with Horde_Rdo_Mapper::map() will have a
     *   $mapper object set automatically.
     *
     * - Subclasses can override getMapper() to return the correct
     *   mapper object.
     *
     * - The programmer can call $rdoObject->setMapper($mapper) to provide a
     *   mapper object.
     *
     * A Horde_Rdo_Exception will be thrown if none of these
     * conditions are met.
     *
     * @return Horde_Rdo_Mapper The Mapper instance managing this object.
     */
    public function getMapper()
    {
        if (!$this->_mapper) {
            $class = get_class($this) . 'Mapper';
            if (class_exists($class)) {
                $this->_mapper = new $class();
            } else {
                throw new Horde_Rdo_Exception('No Horde_Rdo_Mapper object found. Override getMapper() or define the ' . get_class($this) . 'Mapper class.');
            }
        }

        return $this->_mapper;
    }

    /**
     * Associate this Rdo object with the Mapper instance that will
     * manage it. Called automatically by Horde_Rdo_Mapper:map().
     *
     * @param Horde_Rdo_Mapper $mapper The Mapper to manage this Rdo object.
     *
     * @see Horde_Rdo_Mapper::map()
     */
    public function setMapper($mapper)
    {
        $this->_mapper = $mapper;
    }

    /**
     * Save any changes to the backend.
     *
     * @return boolean Success.
     */
    public function save()
    {
        return $this->getMapper()->update($this) == 1;
    }

    /**
     * Delete this object from the backend.
     *
     * @return boolean Success or failure.
     */
    public function delete()
    {
        return $this->getMapper()->delete($this) == 1;
    }

}
