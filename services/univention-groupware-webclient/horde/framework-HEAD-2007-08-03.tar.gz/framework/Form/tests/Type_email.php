<?php
/**
 * @package Horde_Form
 */

require_once 'Horde/Form.php';
require_once 'Horde/Variables.php';

$vars = Variables::getDefaultVariables();
$type = new Horde_Form_Type_email();
$var = new Horde_Form_Variable('email add', 'email', $type, true);

function test($email)
{
    global $type, $var, $vars;

    $valid = $type->isValid($var, $vars, $email, $message);

    echo '<tr><td>' . htmlspecialchars($email) . '</td>';
    echo '<td>' . ($valid ? 'Yes' : 'No: ' . $message) . '</td></tr>';
}

?>
<table border="1">
    <tr>
        <th>Input</th>
        <th>Valid?</th>
    </tr>
<?php

test('cal@iamcalx.com');
test('cal+henderson@iamcalx.com');
test('cal henderson@iamcalx.com');
test('"cal henderson"@iamcalx.com');
test('cal@iamcalx');
test('cal@iamcalx com');
test('cal@hello world.com');
test('cal@[hello].com');
test('cal@[hello world].com');
test('cal@[hello\\ world].com');
test('cal@[hello.com]');
test('cal@[hello world.com]');
test('cal@[hello\\ world.com]');
test('abcdefghijklmnopqrstuvwxyz@abcdefghijklmnopqrstuvwxyz');

test('woo\\ yay@example.com');
test('woo\\@yay@example.com');
test('woo\\.yay@example.com');

test('"woo yay"@example.com');
test('"woo@yay"@example.com');
test('"woo.yay"@example.com');
test('"woo\\"yay"@test.com');

test('webstaff@redcross.org');

test('');
test(',');
test(',,,,');
test('chuck@horde.org,');
test('chuck@horde.org,,');
test('cal@iamcalx.com, foo@example.com');
test(',chuck@horde.org,');

$type->_allow_multi = true;
test('');
test(',');
test(',,,,');
test('chuck@horde.org,');
test('chuck@horde.org,,');
test('cal@iamcalx.com, foo@example.com');
test(',chuck@horde.org,');

?>
</table>
