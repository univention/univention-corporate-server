<?php
/**
 * Horde_Share:: provides an interface to all shares a user might have.  Its
 * methods take care of any site-specific restrictions configured in in the
 * application's prefs.php and conf.php files.
 *
 * $Horde: framework/Share/Share.php,v 1.152 2007/07/07 19:11:28 mrubinsk Exp $
 *
 * Copyright 2002-2007 Joel Vandal <jvandal@infoteck.qc.ca>
 * Copyright 2002-2007 Infoteck Internet <webmaster@infoteck.qc.ca>
 * Copyright 2002-2007 The Horde Project (http://www.horde.org/)
 * Copyright 2006-2007 Gunnar Wrobel <wrobel@pardus.de>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Joel Vandal <jvandal@infoteck.qc.ca>
 * @author  Mike Cochrame <mike@graftonhall.co.nz>
 * @author  Chuck Hagenbuch <chuck@horde.org>
 * @author  Jan Schneider <jan@horde.org>
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @since   Horde 3.0
 * @package Horde_Share
 */
class Horde_Share {

    /**
     * Pointer to a storage instance to manage/store shares
     *
     * @var Storage
     */
    var $_storage;

    /**
     * The application we're managing shares for.
     *
     * @var string
     */
    var $_app;

    /**
     * The root of the Share tree.
     *
     * @var mixed
     */
    var $_root = null;

    /**
     * The subclass of Horde_Share_Object to instantiate shares as.
     *
     * @var string
     */
    var $_shareObject = 'Horde_Share_Object';

    /**
     * The class of the storage object that will be used to store the data.
     *
     * @var string
     */
    var $_storageObject = null;

    /**
     * A cache of all shares that have been retrieved, so we don't hit the
     * backend again and again for them.
     *
     * @var array
     */
    var $_cache = array();

    /**
     * Id-name-map of already cached share objects.
     *
     * @var array
     */
    var $_shareMap = array();

    /**
     * Cache used for listShares().
     *
     * @var array
     */
    var $_listcache = array();

    /**
     * A list of objects that we're currently sorting, for reference during the
     * sorting algorithm.
     *
     * @var array
     */
    var $_sortList;

    /**
     * Attempts to return a reference to a concrete Horde_Share instance. It
     * will only create a new instance if no Horde_Share instance currently
     * exists.
     *
     * This method must be invoked as:
     *   <code>$var = &Horde_Share::singleton($app, $driver);</code>
     *
     * @static
     *
     * @param string $app     The application that the shares relates to.
     * @param string $driver  Type of concrete Share subclass to return,
     *                        based on storage driver ($driver). The code is
     *                        dynamically included.
     *
     * @return Horde_Share  The concrete Share reference, or false on an error.
     */
    function &singleton($app, $driver = null)
    {
        static $shares = array();

        // FIXME: This is a temporary solution until the configuration
        // value actually exists and all apps call this code in the
        // correct fashion.
        $driver = basename($driver);
        if (empty($driver)) {
            if (!empty($GLOBALS['conf']['share']['driver'])) {
                $driver = $GLOBALS['conf']['share']['driver'];
            } else {
                $driver = 'datatree';
            }
        }

        $class = 'Horde_Share_' . $driver;
        if (!class_exists($class)) {
            include dirname(__FILE__) . '/Share/' . $driver . '.php';
        }

        $signature = $app . '_' . $driver;
        if (!isset($shares[$signature]) &&
            !empty($GLOBALS['conf']['share']['cache'])) {
            require_once 'Horde/SessionObjects.php';
            $session = &Horde_SessionObjects::singleton();
            $shares[$signature] = &$session->query('horde_share_' . $app);
        }

        if (empty($shares[$signature])) {
            if (class_exists($class)) {
                $shares[$signature] = &new $class($app);
            } else {
                $result = PEAR::raiseError(sprintf(_("\"%s\" share driver not found."), $driver));
                return $result;
            }
        }

        if (!empty($GLOBALS['conf']['share']['cache'])) {
            register_shutdown_function(array(&$shares[$signature], 'shutdown'));
        }

        return $shares[$signature];
    }

    /**
     * Constructor.
     *
     * @param string $app  The application that the shares belong to.
     */
    function Horde_Share($app)
    {
        $this->_app = $app;
        $this->__wakeup();
    }

    /**
     * Initializes the object.
     */
    function __wakeup()
    {
        Horde::callHook('_horde_hook_share_init', array($this, $this->_app));
    }

    /**
     * Returns the properties that need to be serialized.
     *
     * @return array  List of serializable properties.
     */
    function __sleep()
    {
        $properties = get_object_vars($this);
        unset($properties['_storage'], $properties['_sortList']);
        $properties = array_keys($properties);
        return $properties;
    }

    /**
     * Stores the object in the session cache.
     */
    function shutdown()
    {
        require_once 'Horde/SessionObjects.php';
        $session = &Horde_SessionObjects::singleton();
        $session->overwrite('horde_share_' . $this->_app, $this, false);
    }

    /**
     * Returns a Horde_Share_Object object corresponding to the given share
     * name, with the details retrieved appropriately.
     *
     * @param string $name  The name of the share to retrieve.
     *
     * @return Horde_Share_Object  The requested share.
     */
    function &getShare($name)
    {
        if (isset($this->_cache[$name])) {
            return $this->_cache[$name];
        }

        $result = &$this->_storage->getObject($name, $this->_storageObject);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        $this->_cache[$name] = &new $this->_shareObject();
        $this->_cache[$name]->setStorageObject($result);
        $this->_cache[$name]->setShareOb($this);
        $this->_shareMap[$this->_cache[$name]->getId()] = $name;

        return $this->_cache[$name];
    }

    /**
     * Returns a Horde_Share_Object object corresponding to the given unique
     * ID, with the details retrieved appropriately.
     *
     * @param string $cid  The id of the share to retrieve.
     *
     * @return Horde_Share_Object  The requested share.
     */
    function &getShareById($cid)
    {
        $result = &$this->_storage->getObjectById($cid, $this->_storageObject);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if (isset($this->_shareMap[$cid])) {
            $share = &$this->_cache[$this->_shareMap[$cid]];
        } else {
            $share = &new $this->_shareObject();
            $share->setStorageObject($result);
            $share->setShareOb($this);
            $name = $share->getName();
            $this->_cache[$name] = &$share;
            $this->_shareMap[$cid] = $name;
        }

        return $share;
    }

    /**
     * Returns an array of Horde_Share_Object objects corresponding to the
     * given set of unique IDs, with the details retrieved appropriately.
     *
     * @param array $cids  The array of ids to retrieve.
     *
     * @return array  The requested shares.
     */
    function &getShares($cids)
    {
        $all_shares = array();
        $missing_ids = array();
        foreach ($cids as $cid) {
            if (isset($this->_shareMap[$cid])) {
                $all_shares[$this->_shareMap[$cid]] = &$this->_cache[$this->_shareMap[$cid]];
            } else {
                $missing_ids[] = $cid;
            }
        }

        if (count($missing_ids)) {
            $shares = &$this->_storage->getObjects($missing_ids, $this->_storageObject);
            if (is_a($shares, 'PEAR_Error')) {
                return $shares;
            }

            foreach (array_keys($shares) as $key) {
                if (is_a($shares[$key], 'PEAR_Error')) {
                    return $shares[$key];
                }

                $this->_cache[$key] = &new $this->_shareObject();
                $this->_cache[$key]->setStorageObject($shares[$key]);
                $this->_cache[$key]->setShareOb($this);
                $this->_shareMap[$shares[$key]->getId()] = $key;
                $all_shares[$key] = &$this->_cache[$key];
            }
        }

        return $all_shares;
    }

    /**
     * Returns a new share object.
     *
     * @param string $name  The share's name.
     *
     * @return Horde_Share_Object  A new share object.
     */
    function &newShare($name)
    {
        if (empty($name)) {
            return PEAR::raiseError('Share names must be non-empty');
        }
        $share = &new $this->_shareObject();
        $share->setStorageObject($this->_getNewStorageObject($name));
        $share->setShareOb($this);
        $share->set('owner', Auth::getAuth());

        return $share;
    }

    /**
     * Adds a share to the shares system. The share must first be created with
     * Horde_Share::newShare(), and have any initial details added to it,
     * before this function is called.
     *
     * @param Horde_Share_Object $share  The new share object.
     *
     * @return boolean|PEAR_Error  PEAR_Error on failure.
     */
    function addShare(&$share)
    {
        if (!is_a($share, 'Horde_Share_Object')) {
            return PEAR::raiseError('Shares must be Horde_Share_Object objects or extend that class.');
        }

        $perm = &$GLOBALS['perms']->newPermission($share->storageObject->getName());
        if (is_a($perm, 'PEAR_Error')) {
            return $perm;
        }

        /* Give the owner full access */
        $perm->addUserPermission($share->get('owner'), PERMS_SHOW, false);
        $perm->addUserPermission($share->get('owner'), PERMS_READ, false);
        $perm->addUserPermission($share->get('owner'), PERMS_EDIT, false);
        $perm->addUserPermission($share->get('owner'), PERMS_DELETE, false);

        $share->setPermission($perm, false);

        $result = Horde::callHook('_horde_hook_share_add', array(&$share),
                                  'horde', false);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        $result = $this->_storage->add($share->storageObject);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        /* Store new share in the caches. */
        $id = $share->getId();
        $name = $share->getName();
        $this->_cache[$name] = &$share;
        $this->_shareMap[$id] = $name;

        /* Reset caches that depend on unknown criteria. */
        $this->_listCache = array();

        return $result;
    }

    /**
     * Removes a share from the shares system permanently.
     *
     * @param Horde_Share_Object $share  The share to remove.
     *
     * @return boolean|PEAR_Error  PEAR_Error on failure.
     */
    function removeShare(&$share)
    {
        if (!is_a($share, 'Horde_Share_Object')) {
            return PEAR::raiseError('Shares must be Horde_Share_Object objects or extend that class.');
        }

        $result = Horde::callHook('_horde_hook_share_remove', array(&$share),
                                  'horde', false);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        /* Remove share from the caches. */
        $id = $share->getId();
        unset($this->_shareMap[$id]);
        unset($this->_cache[$share->getName()]);

        /* Reset caches that depend on unknown criteria. */
        $this->_listCache = array();

        return $this->_storage->remove($share->storageObject);
    }

    /**
     * Checks if a share exists in the system.
     *
     * @param string $share  The share to check.
     *
     * @return boolean  True if the share exists, false otherwise.
     */
    function exists($share)
    {
        if (isset($this->_cache[$share])) {
            return true;
        }

        return $this->_storage->exists($share);
    }

    /**
     * Returns the Identity for a particular share owner.
     * @deprecated
     *
     * @param mixed $share  The share to fetch the Identity for - either the
     *                      string name, or the Horde_Share_Object object.
     *
     * @return string  The preference's value.
     */
    function &getIdentityByShare(&$share)
    {
        if (!is_a($share, 'Horde_Share_Object')) {
            $share = &$this->getShare($share);
            if (is_a($share, 'PEAR_Error')) {
                return null;
            }
        }

        require_once 'Horde/Identity.php';
        $identity = &Identity::singleton('none', $share->get('owner'));
        return $identity;
    }

    /**
     * Utility function to be used with uasort() for sorting arrays of
     * Horde_Share objects.
     * Example:<code>
     * uasort($list, array('Horde_Share', '_sortShares'));
     * </code>
     *
     * @access protected
     */
    function _sortShares(&$a, &$b)
    {
        $aParts = explode(':', $a->getName());
        $bParts = explode(':', $b->getName());

        $min = min(count($aParts), count($bParts));
        $idA = '';
        $idB = '';
        for ($i = 0; $i < $min; $i++) {
            if ($idA) {
                $idA .= ':';
                $idB .= ':';
            }
            $idA .= $aParts[$i];
            $idB .= $bParts[$i];

            if ($idA != $idB) {
                $curA = isset($this->_sortList[$idA]) ? $this->_sortList[$idA]->get('name') : '';
                $curB = isset($this->_sortList[$idB]) ? $this->_sortList[$idB]->get('name') : '';
                return strnatcasecmp($curA, $curB);
            }
        }

        return count($aParts) > count($bParts);
    }

}

/**
 * Abstract class for storing Share information. This class should be
 * extended for the more specific drivers.
 *
 * @author  Mike Cochrane <mike@graftonhall.co.nz>
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @since   Horde 3.2
 * @package Horde_Share
 */
class Horde_Share_Object {

    /**
     * The Horde_Share object which this share came from - needed for updating
     * data in the backend to make changes stick, etc.
     *
     * @var Horde_Share
     */
    var $_shareOb;

    /**
     * The actual storage object that holds the data.
     *
     * @var mixed
     */
    var $storageObject;

    /**
     * Associates a Share object with this share.
     *
     * @param Horde_Share $shareOb  The Share object.
     */
    function setShareOb(&$shareOb)
    {
        if (!is_a($shareOb, 'Horde_Share')) {
            return PEAR::raiseError('This object needs a Horde_Share instance as storage handler!');
        }
        $this->_shareOb = &$shareOb;
    }

    /**
     * Delegate set function to the storage object
     *
     * @param string $attribute  The attribute to set.
     * @param mixed $value       The value for $attribute.
     *
     * @return mixed True if setting the attribute did succeed a PEAR
     * error otherwise.
     */
    function set($attribute, $value)
    {
        return $this->storageObject->set($attribute, $value);
    }

    /**
     * Delegate get function to the storage object
     *
     * @param string $attribute  The attribute to get.
     *
     * @return mixed  The value of the attribute, or null.
     */
    function get($attribute)
    {
        return $this->storageObject->get($attribute);
    }

    /**
     * Gets the Id of this share.
     *
     * @return string  The share's Id.
     */
    function getId()
    {
        return $this->storageObject->getId();
    }

    /**
     * Gets the name of this share.
     *
     * @return string  The share's name.
     */
    function getName()
    {
        return $this->storageObject->getName();
    }

    /**
     * Saves the current attribute values in the cache to the imap folder.
     *
     * @return mixed  True on success or a PEAR error if the imap call failed.
     */
    function save()
    {
        $result = Horde::callHook('_horde_hook_share_modify', array($this),
                                  'horde', false);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        return $this->storageObject->save();
    }

    /**
     * Returns the properties that need to be serialized.
     *
     * @return array  List of serializable properties.
     */
    function __sleep()
    {
        $properties = get_object_vars($this);
        unset($properties['storageObject'], $properties['_shareOb']);
        $properties = array_keys($properties);
        return $properties;
    }

    /**
     * Associates a storage object object with this share.
     *
     * @param mixed $storageObject  The Storage object.
     */
    function setStorageObject(&$storageObject)
    {
        $this->storageObject = &$storageObject;
    }

    /**
     * Gives a user a certain privilege for this share.
     *
     * @param string $userid       The userid of the user.
     * @param integer $permission  A PERMS_* constant.
     */
    function addUserPermission($userid, $permission)
    {
        $perm = &$this->getPermission();
        $perm->addUserPermission($userid, $permission, false);
        $this->setPermission($perm);
    }

    /**
     * Removes a certain privilege for a user from this share.
     *
     * @param string $userid       The userid of the user.
     * @param integer $permission  A PERMS_* constant.
     */
    function removeUserPermission($userid, $permission)
    {
        $perm = &$this->getPermission();
        $perm->removeUserPermission($userid, $permission, false);
        $this->setPermission($perm);
    }

    /**
     * Gives a group certain privileges for this share.
     *
     * @param string $group        The group to add permissions for.
     * @param integer $permission  A PERMS_* constant.
     */
    function addGroupPermission($group, $permission)
    {
        $perm = &$this->getPermission();
        $perm->addGroupPermission($group, $permission, false);
        $this->setPermission($perm);
    }

    /**
     * Removes a certain privilege from a group.
     *
     * @param string $group         The group to remove permissions from.
     * @param constant $permission  A PERMS_* constant.
     */
    function removeGroupPermission($group, $permission)
    {
        $perm = &$this->getPermission();
        $perm->removeGroupPermission($group, $permission, false);
        $this->setPermission($perm);
    }

    /**
     * Removes a user from this share.
     *
     * @param string $userid  The userid of the user to remove.
     */
    function removeUser($userid)
    {
        /* Remove all $userid's permissions. */
        $perm = &$this->getPermission();
        $perm->removeUserPermission($userid, PERMS_SHOW, false);
        $perm->removeUserPermission($userid, PERMS_READ, false);
        $perm->removeUserPermission($userid, PERMS_EDIT, false);
        $perm->removeUserPermission($userid, PERMS_DELETE, false);
        return $this->setPermission($perm);
    }

    /**
     * Removes a group from this share.
     *
     * @param integer $groupId  The group to remove.
     */
    function removeGroup($groupId)
    {
        /* Remove all $groupId's permissions. */
        $perm = &$this->getPermission();
        $perm->removeGroupPermission($groupId, PERMS_SHOW, false);
        $perm->removeGroupPermission($groupId, PERMS_READ, false);
        $perm->removeGroupPermission($groupId, PERMS_EDIT, false);
        $perm->removeGroupPermission($groupId, PERMS_DELETE, false);
        return $this->setPermission($perm);
    }

    /**
     * Returns an array containing all the userids of the users with access to
     * this share.
     *
     * @param integer $perm_level  List only users with this permission level.
     *                             Defaults to all users.
     *
     * @return array  The users with access to this share.
     */
    function listUsers($perm_level = null)
    {
        $perm = &$this->getPermission();
        return array_keys($perm->getUserPermissions($perm_level));
    }

    /**
     * Returns an array containing all the groupids of the groups with access
     * to this share.
     *
     * @param integer $perm_level  List only users with this permission level.
     *                             Defaults to all users.
     *
     * @return array  The IDs of the groups with access to this share.
     */
    function listGroups($perm_level = null)
    {
        $perm = &$this->getPermission();
        return array_keys($perm->getGroupPermissions($perm_level));
    }

}
