<?php

require_once 'Horde/DataTree.php';

/**
 * Horde_Share_datatree:: provides the datatree backend for the horde share
 * driver.
 *
 * $Horde: framework/Share/Share/datatree.php,v 1.7 2007/07/07 19:11:29 mrubinsk Exp $
 *
 * Copyright 2002-2007 Joel Vandal <jvandal@infoteck.qc.ca>
 * Copyright 2002-2007 Infoteck Internet <webmaster@infoteck.qc.ca>
 * Copyright 2002-2007 The Horde Project (http://www.horde.org/)
 * Copyright 2006-2007 Gunnar Wrobel <wrobel@pardus.de>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Joel Vandal <jvandal@infoteck.qc.ca>
 * @author  Mike Cochrame <mike@graftonhall.co.nz>
 * @author  Chuck Hagenbuch <chuck@horde.org>
 * @author  Jan Schneider <jan@horde.org>
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @since   Horde 3.2
 * @package Horde_Share
 */
class Horde_Share_datatree extends Horde_Share {

    /**
     * The subclass of ShareObject to instantiate shares as.
     *
     * @var string
     */
    var $_shareObject = 'Horde_Share_Object_datatree';

    /**
     * The class of the storage object that will be used to store the data.
     *
     * @var string
     */
    var $_storageObject = 'DataTreeObject_Share';

    /**
     * Initializes the object.
     */
    function __wakeup()
    {
        global $conf, $registry;

        if (empty($conf['datatree']['driver'])) {
            Horde::fatal('You must configure a DataTree backend to use Shares.', __FILE__, __LINE__);
        }

        $driver = $conf['datatree']['driver'];
        $this->_storage = &DataTree::singleton(
            $driver,
            array_merge(Horde::getDriverConfig('datatree', $driver), array('group' => 'horde.shares.' . $this->_app))
        );

        foreach (array_keys($this->_cache) as $name) {
            $this->_cache[$name]->setShareOb($this);
            $this->_cache[$name]->setStorageObject($this->_storage->getObject($name, $this->_storageObject));
        }

        parent::__wakeup();
    }

    /**
     * Lists *all* shares for the current app/share, regardless of
     * permissions. This is for admin functionality and scripting tools, and
     * shouldn't be called from user-level code!
     *
     * @return array  All shares for the current app/share.
     */
    function listAllShares()
    {
        $sharelist = $this->_storage->get(DATATREE_FORMAT_FLAT, DATATREE_ROOT, true);
        if (is_a($sharelist, 'PEAR_Error') || !count($sharelist)) {
            // If we got back an error or an empty array, just return it.
            return $sharelist;
        }
        unset($sharelist[DATATREE_ROOT]);

        $shares = &$this->getShares(array_keys($sharelist));
        if (is_a($shares, 'PEAR_Error')) {
            return $shares;
        }

        $this->_sortList = $shares;
        uasort($shares, array($this, '_sortShares'));
        $this->_sortList = null;

        return $shares;
    }

    /**
     * Returns an array of all shares that $userid has access to.
     *
     * @param string  $userid       The userid of the user to check access for.
     * @param integer $perm         The level of permissions required.
     * @param mixed   $attributes   Restrict the shares counted to those
     *                              matching $attributes. An array of
     *                              attribute/values pairs or a share owner
     *                              username.
     *
     * @return array  The shares the user has access to.
     */
    function &listShares($userid, $perm = PERMS_SHOW, $attributes = null)
    {
        $key = serialize(array($userid, $perm, $attributes));
        if (empty($this->_listCache[$key])) {
            $criteria = $this->_getShareCriteria($userid, $perm, $attributes);
            $sharelist = $this->_storage->getByAttributes(
                $criteria, DATATREE_ROOT, true, 'id');
            if (is_a($sharelist, 'PEAR_Error')) {
                return $sharelist;
            }
            $this->_listCache[$key] = array_keys($sharelist);
        }

        if (!count($this->_listCache[$key])) {
            return $this->_listCache[$key];
        }

        /* Make sure getShares() didn't return an error. */
        $shares = &$this->getShares($this->_listCache[$key]);
        if (is_a($shares, 'PEAR_Error')) {
            return $shares;
        }

        $this->_sortList = $shares;
        uasort($shares, array($this, '_sortShares'));
        $this->_sortList = null;

        $result = Horde::callHook('_horde_hook_share_list',
                                  array($userid, $perm, $attributes, $shares),
                                  'horde',
                                  false);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        return $shares;
    }

    /**
     * Returns an array of criteria for querying shares.
     * @access protected
     *
     * @param string  $userid      The userid of the user to check access for.
     * @param integer $perm        The level of permissions required.
     * @param mixed   $attributes  Restrict the shares returned to those who
     *                             have these attribute values.
     *
     * @return array  The criteria tree for fetching this user's shares.
     */
    function _getShareCriteria($userid, $perm = PERMS_SHOW, $attributes = null)
    {
        if (!empty($userid)) {
            $criteria = array(
                'OR' => array(
                    // (owner == $userid)
                    array(
                        'AND' => array(
                            array('field' => 'name', 'op' => '=', 'test' => 'owner'),
                            array('field' => 'value', 'op' => '=', 'test' => $userid))),

                    // (name == perm_users and key == $userid and val & $perm)
                    array(
                        'AND' => array(
                            array('field' => 'name', 'op' => '=', 'test' => 'perm_users'),
                            array('field' => 'key', 'op' => '=', 'test' => $userid),
                            array('field' => 'value', 'op' => '&', 'test' => $perm))),

                    // (name == perm_creator and val & $perm)
                    array(
                        'AND' => array(
                            array('field' => 'name', 'op' => '=', 'test' => 'perm_creator'),
                            array('field' => 'value', 'op' => '&', 'test' => $perm))),

                    // (name == perm_default and val & $perm)
                    array(
                        'AND' => array(
                            array('field' => 'name', 'op' => '=', 'test' => 'perm_default'),
                            array('field' => 'value', 'op' => '&', 'test' => $perm)))));

            // If the user has any group memberships, check for those also.
            require_once 'Horde/Group.php';
            $group = &Group::singleton();
            $groups = $group->getGroupMemberships($userid, true);
            if (!is_a($groups, 'PEAR_Error') && $groups) {
                // (name == perm_groups and key in ($groups) and val & $perm)
                $criteria['OR'][] = array(
                    'AND' => array(
                        array('field' => 'name', 'op' => '=', 'test' => 'perm_groups'),
                        array('field' => 'key', 'op' => 'IN', 'test' => array_keys($groups)),
                        array('field' => 'value', 'op' => '&', 'test' => $perm)));
            }
        } else {
            $criteria = array(
                'AND' => array(
                     array('field' => 'name', 'op' => '=', 'test' => 'perm_guest'),
                     array('field' => 'value', 'op' => '&', 'test' => $perm)));
        }

        if (is_array($attributes)) {
            // Build attribute/key filter.
            foreach ($attributes as $key => $value) {
                $criteria = array(
                    'AND' => array(
                        $criteria,
                        array(
                            'JOIN' => array(
                                'AND' => array(
                                    array('field' => 'name', 'op' => '=', 'test' => $key),
                                    array('field' => 'value', 'op' => '=', 'test' => $value))))));
            }
        } elseif (!empty($attributes)) {
            // Restrict to shares owned by the user specified in the
            // $attributes string.
            $criteria = array(
                'AND' => array(
                    $criteria,
                    array(
                        'JOIN' => array(
                            array('field' => 'name', 'op' => '=', 'test' => 'owner'),
                            array('field' => 'value', 'op' => '=', 'test' => $attributes)))));
        }

        return $criteria;
    }

    /**
     * Finds out what rights the given user has to this object.
     *
     * @see Perms::getPermissions
     *
     * @param mixed  $share  The share that should be checked for the users
     *                       permissions
     * @param string $user   The user to check for.
     *
     * @return mixed  A bitmask of permissions, a permission value, or an array
     *                of permission values the user has, depending on the
     *                permission type and whether the permission value is
     *                ambiguous. False if there is no such permsission.
     */
    function getPermissions($share, $user = null)
    {
        if (!is_a($share, 'Horde_Share_Object')) {
            $share = &$this->getShare($share);
        }

        $perm = &$share->getPermission();
        return $GLOBALS['perms']->getPermissions($perm, $user);
    }

    /**
     * Prepares a new storage object for the Horde share.
     * @access protected
     *
     * @param string $id  The unique id of the share.
     */
    function _getNewStorageObject($id)
    {
        $storageObject = new $this->_storageObject($id);
        if (is_null($storageObject->data)) {
            $storageObject->data = array();
        }
        $storageObject->setDataTree($this->_storage);

        return $storageObject;
    }

}

/**
 * Extension of the Horde_Share_Object class for storing Share information in
 * the DataTree driver.
 *
 * @author  Mike Cochrane <mike@graftonhall.co.nz>
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @since   Horde 3.2
 * @package Horde_Share
 */
class Horde_Share_Object_datatree extends Horde_Share_Object {

    /**
     * Checks to see if a user has a given permission.
     *
     * @param string $userid       The userid of the user.
     * @param integer $permission  A PERMS_* constant to test for.
     * @param string $creator      The creator of the event.
     *
     * @return boolean  Whether or not $userid has $permission.
     */
    function hasPermission($userid, $permission, $creator = null)
    {
        if ($userid == $this->storageObject->get('owner')) {
            return true;
        }

        return $GLOBALS['perms']->hasPermission($this->getPermission(),
                                                $userid, $permission, $creator);
    }

    /**
     * Sets the permission of this share.
     *
     * @param DataTreeObject_Permission $perm    Permission object
     * @param boolean                   $update  Should the share be saved
     *                                           after this operation?
     *
     * @return boolean  True if no error occured, PEAR_Error otherwise
     */
    function setPermission(&$perm, $update = true)
    {
        $this->storageObject->data['perm'] = $perm->getData();
        if ($update) {
            return $this->storageObject->save();
        }
        return true;
    }

    /**
     * Gets the permission of this share.
     *
     * @return DataTreeObject_Permission  Permission object that represents the
     *                                    permissions on this share
     */
    function &getPermission()
    {
        $perm = new DataTreeObject_Permission($this->storageObject->getName());
        $perm->data = isset($this->storageObject->data['perm'])
            ? $this->storageObject->data['perm']
            : array();

        return $perm;
    }

}

/**
 * Extension of the DataTreeObject class for storing Share information in the
 * DataTree driver. If you want to store specialized Share information, you
 * should extend this class instead of extending DataTreeObject directly.
 *
 * @author  Mike Cochrane <mike@graftonhall.co.nz>
 * @since   Horde 3.0
 * @package Horde_Share
 */
class DataTreeObject_Share extends DataTreeObject {

    /**
     * Saves any changes to this object to the backend permanently. New objects
     * are added instead.
     *
     * @return boolean | PEAR_Error  PEAR_Error on failure.
     */
    function save()
    {
        return parent::save();
    }

    /**
     * Maps this object's attributes from the data array into a format that we
     * can store in the attributes storage backend.
     *
     * @access protected
     *
     * @param boolean $permsonly  Only process permissions? Lets subclasses
     *                            override part of this method while handling
     *                            their additional attributes seperately.
     *
     * @return array  The attributes array.
     */
    function _toAttributes($permsonly = false)
    {
        // Default to no attributes.
        $attributes = array();

        foreach ($this->data as $key => $value) {
            if ($key == 'perm') {
                foreach ($value as $type => $perms) {
                    if (is_array($perms)) {
                        foreach ($perms as $member => $perm) {
                            $attributes[] = array('name' => 'perm_' . $type,
                                                  'key' => $member,
                                                  'value' => $perm);
                        }
                    } else {
                        $attributes[] = array('name' => 'perm_' . $type,
                                              'key' => '',
                                              'value' => $perms);
                    }
                }
            } elseif (!$permsonly) {
                $attributes[] = array('name' => $key,
                                      'key' => '',
                                      'value' => $value);
            }
        }

        return $attributes;
    }

    /**
     * Takes in a list of attributes from the backend and maps it to our
     * internal data array.
     *
     * @access protected
     *
     * @param array $attributes   The list of attributes from the backend
     *                            (attribute name, key, and value).
     * @param boolean $permsonly  Only process permissions? Lets subclasses
     *                            override part of this method while handling
     *                            their additional attributes seperately.
     */
    function _fromAttributes($attributes, $permsonly = false)
    {
        // Initialize data array.
        $this->data['perm'] = array();

        foreach ($attributes as $attr) {
            if (substr($attr['name'], 0, 4) == 'perm') {
                if (!empty($attr['key'])) {
                    $this->data['perm'][substr($attr['name'], 5)][$attr['key']] = $attr['value'];
                } else {
                    $this->data['perm'][substr($attr['name'], 5)] = $attr['value'];
                }
            } elseif (!$permsonly) {
                $this->data[$attr['name']] = $attr['value'];
            }
        }
    }

}
