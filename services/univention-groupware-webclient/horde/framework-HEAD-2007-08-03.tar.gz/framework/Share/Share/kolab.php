<?php
/**
 * $Horde: framework/Share/Share/kolab.php,v 1.27 2007/06/26 13:03:37 jan Exp $
 *
 * @package Horde_Share
 */

/** Kolab */
require_once 'Horde/Kolab.php';

/**
 * Horde-specific annotations on the imap folder have this prefix.
 */
define('KOLAB_ANNOT_SHARE_ATTR', KOLAB_ANNOT_ROOT . 'h-share-attr-');

/**
 * Marks a share without a name. These shares are still invalid
 */
define('KOLAB_SHARE_INVALID', 'KOLAB_SHARE_INVALID');

/**
 * Horde_Share_kolab:: provides the kolab backend for the horde share driver.
 *
 * Copyright 2004-2007 The Horde Project (http://www.horde.org/)
 * Copyright 2006-2007 Gunnar Wrobel <wrobel@pardus.de>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @since   Horde 3.2
 * @package Horde_Share
 */
class Horde_Share_kolab extends Horde_Share {

    /**
     * The subclass of ShareObject to instantiate shares as.
     *
     * @var string
     */
    var $_shareObject = 'Horde_Share_Object_kolab';

    /**
     * The class of the storage object that will be used to store the data.
     *
     * @var string
     */
    var $_storageObject = 'ImapObject_Share';

    /**
     * Constructor
     *
     * @param string $app  The application that the shares belong to.
     */
    function Horde_Share_kolab($app)
    {
        global $conf;

        if (empty($conf['kolab']['enabled'])) {
            Horde::fatal('You must enable the kolab settings to use the Kolab Share driver.', __FILE__, __LINE__);
        }

        $this->_storage = &Horde_Share_Storage_kolab::singleton($app);

        parent::Horde_Share($app);
    }

    /**
     * Returns an array of all shares that $userid has access to.
     *
     * @param string  $userid       The userid of the user to check access for.
     * @param integer $perm         The level of permissions required.
     * @param mixed   $attributes   Restrict the shares counted to those
     *                              matching $attributes. An array of
     *                              attribute/values pairs or a share owner
     *                              username.
     *
     * @return array  The shares the user has access to.
     */
    function &listShares($userid, $perm = PERMS_SHOW, $attributes = null)
    {
        $key = serialize(array($this->_app, $userid, $perm, $attributes));
        if (empty($this->_listCache[$key]) || $this->_storage->dirty) {
            $sharelist = $this->_storage->getShares();
            if (is_a($sharelist, 'PEAR_Error')) {
                return $sharelist;
            }

            $shares = array();
            foreach ($sharelist as $id) {
                $share = &$this->getShare($id);
                if (is_a($share, 'PEAR_Error')) {
                    return $share;
                }

                $keep = true;
                if (!$share->hasPermission($userid, $perm)) {
                    $keep = false;
                }
                if (isset($attributes)) {
                    if (is_array($attributes)) {
                        foreach ($attributes as $key => $value) {
                            if (!$share->get($key) == $value) {
                                $keep = false;
                            }
                        }
                    } elseif (!$share->get('owner') == $attributes) {
                        $keep = false;
                    }
                }
                $shares[] = $id;

            }
            $this->_listCache[$key] = $shares;
            $this->_storage->dirty = false;
        }

        if (!count($this->_listCache[$key])) {
            return $this->_listCache[$key];
        }

        /* Make sure getShares() didn't return an error. */
        $shares = &$this->getShares($this->_listCache[$key]);
        if (is_a($shares, 'PEAR_Error')) {
            return $shares;
        }

        $this->_sortList = &$shares;
        uasort($shares, array($this, '_sortShares'));
        unset($this->_sortList);

        $result = Horde::callHook('_horde_hook_share_list',
                                  array($userid, $perm, $attributes, &$shares),
                                  'horde',
                                  false);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        return $shares;
    }

    /**
     * Finds out what rights the given user has to this object.
     *
     * @see Perms::getPermissions
     *
     * @param mixed  $share  The share that should be checked for the users
     *                       permissions
     * @param string $user   The user to check for.
     *
     * @return mixed  A bitmask of permissions, a permission value, or an array
     *                of permission values the user has, depending on the
     *                permission type and whether the permission value is
     *                ambiguous. False if there is no such permsission.
     */
    function getPermissions(&$share, $user = null)
    {
        if (!is_a($share, 'Horde_Share_Object')) {
            $share = &$this->getShare($share);
        }

        $perm = &$share->getPermission();
        return $GLOBALS['perms']->getPermissions($perm, $user);
    }

    /**
     * Prepares a new storage object for the Horde share.
     * @access protected
     *
     * @param string $id  The unique id of the share
     */
    function _getNewStorageObject($id)
    {
        $id = $this->_storage->parseShareId($id);
        $storageObject = &new $this->_storageObject($id);
        $storageObject->setStorage($this->_storage);

        return $storageObject;
    }
}

/**
 * Extension of the Horde_Share_Object class for storing Share information on
 * the kolab server.
 *
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @author  Stuart Binge <omicron@mighty.co.za>
 * @since   Horde 3.2
 * @package Horde_Share
 */
class Horde_Share_Storage_kolab {

    /**
     * The application we're storing shares for.
     *
     * @var string
     */
    var $_app;

    /**
     * Has the list of mailboxes been modified?
     *
     * @var boolean
     */
    var $dirty = true;

    /**
     * The shares for this app
     *
     * @var array
     */
    var $_shares = null;

    /**
     * Our Kolab_IMAP_Connection object, used to communicate with the
     * Cyrus server.
     *
     * @var Kolab_IMAP_Connection
     */
    var $_imap = null;

    /**
     * A cache for internal share ids
     *
     * @var array
     */
    var $_shareMap = null;

    /**
     * Caches the default share name
     *
     * @var string
     */
    var $_default = null;

    /**
     * Constructor
     *
     * @param string $app  The application that the shares belong to.
     */
    function Horde_Share_Storage_kolab($app)
    {
        $this->_app = $app;

        // Connect to the IMAP server
        $this->_imap = &Kolab_IMAP_Connection::singleton(Kolab::getServer('imap'),
                                                         $GLOBALS['conf']['kolab']['imap']['port'],
                                                         true, false);

        // Login using the current Horde credentials
        $result = $this->_imap->connect(Auth::getAuth(),
                                        Auth::getCredential('password'));
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }
    }

    /**
     * Gets the imap connection from the storage driver.
     *
     * @return Kolab_IMAP_Connection The imap connection.
     */
    function &getImap()
    {
        return $this->_imap;
    }

    /**
     * Attempts to return a reference to a concrete Horde_Share_Storage_kolab
     * instance. It will only create a new instance if no
     * Horde_Share_Storage_kolab instance currently exists.
     *
     * @param string $app  The applications that the shares relate to.
     *
     * @return Horde_Share  The concrete Share reference, or false on an error.
     */
    function &singleton($app)
    {
        static $share_storage = array();

        if (!isset($share_storage[$app])) {
            $share_storage[$app] = &new Horde_Share_Storage_kolab($app);
        }

        return $share_storage[$app];
    }

    /**
     * Fills the _shares variable with the ids of all shares
     * accessible to the user and returns the array.
     *
     * @return array The shares accessible to the user
     */
    function getShares()
    {
        if (!isset($this->_shares)) {
            // Get the application constants
            $app_consts = Kolab::getAppConsts($this->_app);
            if (is_a($app_consts, 'PEAR_Error')) {
                return $app_consts;
            }

            // Obtain a list of all folders the current user has access to
            $folder_list = $this->_imap->getMailboxes();
            if (is_a($folder_list, 'PEAR_Error')) {
                return $folder_list;
            }

            // We're only interested in the shares of the specific resource
            // type for the current application, so filter out the rest
            $shares = array();

            // We will also check that the folder name actually looks
            // like an IMAP folder name.
            $folders_preg = ';shared\.|INBOX[/]?|user/[^/]+[/]?[^@]+(@.*)?;';

            foreach ($folder_list as $folder) {

                // Check for a correct IMAP folder name
                preg_match($folders_preg, $folder, $matches);
                if (!isset($matches)) {
                    continue;
                }

                // Retrieve the folder annotation
                $annotation = $this->_imap->getAnnotation(KOLAB_ANNOT_FOLDER_TYPE, 'value.shared', $folder);
                if (is_a($annotation, 'PEAR_Error')) {
                    return $annotation;
                }

                // If there is no annotation then we treat it as a standard
                // mail folder (i.e. we ignore it).
                if (empty($annotation)) {
                    continue;
                }

                // If the folder is of the correct type then we add it to our
                // list of folders that should correspond to a share. Here we
                // get any other additional information we may need, such as
                // whether the folder was previously mapped to a share, its
                // ACL, its owner (if it is a shared folder) and its display
                // name.
                $type = explode('.', $annotation);
                if ($type[0] == $app_consts['mime_type_suffix']) {
                    if (isset($type[1]) && $type[1] == 'default') {
                        $this->_default = $folder;
                        array_push($shares, $this->buildShareId(Auth::getAuth()));
                    } else {
                        array_push($shares, $this->buildShareId(rawurlencode($folder)));
                    }
                }
            }
            $this->_shares = $shares;
        }

        return $this->_shares;
    }

    /**
     * Returns a Horde_Share_Object_kolab object of the named folder $object.
     *
     * @param string $object  The share to fetch.
     * @param string $class   Subclass of Horde_Share_Object to use. Defaults
     *                        to ImapObject_Share.
     * @return Horde_Share_Object_kolab  The share object or a PEAR error if
     *                                   the share was not found.
     */
    function &getObject($object, $class = 'ImapObject_Share')
    {
        if (empty($object)) {
            $error = PEAR::raiseError('No object requested.');
            return $error;
        }

        if (!class_exists($class)) {
            $error = PEAR::raiseError($class . ' not found.');
            return $error;
        }

        // Get the available folders for this app
        $shares = $this->getShares();
        if (is_a($shares, 'PEAR_Error')) {
            return $shares;
        }

        // Is the specified object really a share for this app?
        if (!in_array($object, $shares)) {
            return PEAR::raiseError(sprintf(_("Share \"%s\" does not exist."), $object));
        }

        $object = $this->parseShareId($object);

        // Create the object from the folder name
        $share = &new $class($object);
        $share->setStorage($this);

        if ($object == Auth::getAuth()) {
            $object = $this->getDefaultShare();
        }

        $share->setFolder($object);
        $result = $share->accessible();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }
        if (!$result) {
            return PEAR::raiseError(sprintf(_("Share \"%s\" not accessible."), $object));
        }
        return $share;
    }

    /**
     * Returns a Horde_Share_Object_kolab object of the named folder $id.
     *
     * @param string $id      The id of the share to fetch.
     * @param string $class   Subclass of the storage object to use. Defaults
     *                        to ImapObject_Share.
     * @return Horde_Share_Object_kolab  The share object or a PEAR error if
     *                                   the share was not found.
     */
    function &getObjectById($id, $class = 'ImapObject_Share')
    {
        // Try to use a cache in order to make getObjects somewhat faster.
        if (isset($this->_shareMap[$id])) {
            return $this->_shareMap[$id];
        }
        $sharelist = $this->getShares();
        foreach ($sharelist as $shareid) {
            $share = &$this->getObject($shareid);
            if (is_a($share, 'PEAR_Error')) {
                return $share;
            }
            $this->_shareMap[$share->getId()] = &$share;
            if ($share->getId() == $id) {
                return $share;
            }
        }
        return PEAR::raiseError(sprintf(_("Share ID \"%s\"  not found."), $id));
    }

    /**
     * Returns an array of Horde_Share_Object_kolab object corresponding to the
     * given folder $ids.
     *
     * @param string $ids     The ids of the shares to fetch.
     * @param string $class   Subclass of the storage object to use. Defaults
     *                        to Horde_Share_Object_kolab.
     * @return array          An array of Horde_Share_Object_kolab objects or
     *                        a PEAR error if a share was not found.
     */
    function &getObjects($ids, $class = 'ImapObject_Share')
    {
        $objects = array();
        foreach ($ids as $id) {
            $result = &$this->getObject($id, $class);
            if (is_a($result, 'PEAR_Error')) {
                return $result;
            }
            $objects[$result->getId()] = &$result;
        }
        return $objects;
    }

    /**
     * Returns the folder name (in share notation, so potentially prefixed
     * with "kolab:") of the default share for the user.
     *
     * @return Horde_Share_Object_kolab  The share object or a PEAR error if
     *                                   the share was not found.
     */
    function &getDefaultShare()
    {
        $this->getShares();
        return $this->_default;
    }

    /**
     * Does the storage have a default share?
     *
     * @return boolean    True if a default share exists.
     */
    function hasDefaultShare()
    {
        $this->getShares();
        if (empty($this->_default)) {
            return false;
        }
        return true;
    }

    /**
     * Get the default share name for the current app.
     *
     * @return string    The default share name.
     */
    function getDefaultShareName()
    {
        switch ($this->_app) {
        case 'turba':
            return _("Contacts");
        case 'mnemo':
            return _("Notes");
        case 'kronolith':
            return _("Calendar");
        case 'nag':
            return _("Tasks");
        case 'ingo':
            return _("Filters");
        }
    }

    /**
     * Tests whether the given share exists.
     *
     * @param string $object  The shares to check for existence.
     *
     * @return mixed          True if the share exist, false if not or a PEAR
     *                        in case the array of folder could not be fetched.
     */
    function exists($object)
    {
        if (empty($object)) {
            return false;
        }

        $object = $this->parseShareId($object);

        if ($object == Auth::getAuth()) {
            return $this->hasDefaultShare();
        }

        // Get the available folders for this app
        $shares = $this->getShares();
        if (is_a($shares, 'PEAR_Error')) {
            return false;
        }

        // Is the specified object really a share for this app?
        if (!in_array($object, $shares)) {
            return false;
        }
        return true;
    }

    /**
     * Adds the share to the storage.
     *
     * @param  Horde_Share_Object_kolab $share  The share object to be added.
     * @return mixed                            PEAR error in case of failure
     */
    function add(&$share)
    {
        // Ensure that the share list has been initialized
        $this->getShares();

        $share_id = $share->get('folder');
        if ($share_id == KOLAB_SHARE_INVALID) {
            return PEAR::raiseError(_("Cannot add this share! The name has not yet been set."));
        }

        $result = $this->_imap->exists($share_id);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }
        if ($result) {
            return PEAR::raiseError(sprintf(_("Unable to add %s: destination folder already exists"), $share_id));
        }

        $share->setFolder($share_id);

        if ($result === false) {
            $result = $this->_imap->create($share_id);
            if (is_a($result, 'PEAR_Error')) {
                return $result;
            }

            // Get the application constants
            $app_consts = Kolab::getAppConsts($this->_app);
            if (is_a($app_consts, 'PEAR_Error')) {
                return $app_consts;
            }
            $folder_type = $app_consts['mime_type_suffix'] . ($share->get('default') ? '.default' : '');
            $result = $this->_imap->setAnnotation(KOLAB_ANNOT_FOLDER_TYPE, array('value.shared' => $folder_type), $share_id);
            if (is_a($result, 'PEAR_Error')) {
                return $result;
            }
        }

        // Save permissions
        $result = $share->save();
        if (is_a($result, 'PEAR_Error')) {
            // If saving did not work, the folder should be removed again
            $this->_imap->delete($share_id);
            return $result;
        }

        array_push($this->_shares, $share->getId());

        if ($share->get('default')) {
            $this->_default = $share->get('folder');
        }
    }

    /**
     * Removes the share from the storage.
     *
     * @param  Horde_Share_Object_kolab $share  The share object to be removed.
     * @return mixed                            PEAR error in case of failure
     */
    function remove(&$share)
    {
        $share_id = $share->getId();
        $folder = $share->get('folder');
        $result = $this->_imap->exists($folder);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if ($result === true) {
            $result = $this->_imap->delete($folder);
            if (is_a($result, 'PEAR_Error')) {
                return $result;
            }
        }

        $shares = $this->getShares();
        $new_shares = array();
        foreach ($shares as $oldshare) {
            if ($oldshare != $share_id) {
                array_push($new_shares, $oldshare);
            }
        }

        $this->_shares = $new_shares;
    }

    /**
     * Reset the share name cache.
     */
    function unsetShares()
    {
        $this->_shares = null;
    }

    /**
     * Convert the share id depending on the app we are called from.
     *
     * @param string $id  The unique id of the share
     *
     * @return string The converted id
     */
    function parseShareId($id)
    {
        if ($this->_app == 'ingo') {
            list(, $id) = explode(':', $id, 2);
        }
        if ($id != Auth::getAuth()) {
            return rawurldecode($id);
        }
        return $id;
    }

    /**
     * Build the share id depending on the app we are called from.
     *
     * @param string $id  The unique id of the share
     *
     * @return string The correct, app dependant id
     */
    function buildShareId($id)
    {
        if ($this->_app == 'ingo') {
            return 'kolab:' . $id;
        }
        return $id;
    }

}

/**
 * Extension of the Horde_Share_Object class for handling kolab Share
 * information
 *
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @since   Horde 3.2
 * @package Horde_Share
 */
class Horde_Share_Object_kolab extends Horde_Share_Object {

    /**
     * Checks to see if a user has a given permission.
     *
     * @param string $userid       The userid of the user.
     * @param integer $permission  A PERMS_* constant to test for.
     * @param string $creator      The creator of the shared object.
     *
     * @return boolean  Whether or not $userid has $permission.
     */
    function hasPermission($userid, $permission, $creator = null)
    {
        $perm = &$this->getPermission();
        return $perm->hasPermission($userid, $permission, $creator);
    }

    /**
     * Sets the permissions on the share
     *
     * @param ImapFolder_Permission Permission object to store on the object.
     * @param boolean $update       Save the updated information?
     *
     * @return mixed  True on success or a PEAR error on failure.
     */
    function setPermission(&$perm, $update = true)
    {
        if (!is_a($perm, 'ImapFolder_Permission')) {
            return PEAR::raiseError('The permissions for this share must be specified as an instance of the ImapFolder_Permission class!');
        }

        $this->storageObject->setPermission($perm);

        if ($update) {
            return $this->storageObject->save();
        }
        return true;
    }

    /**
     * Gets the permissions from the share
     *
     * @return ImapFolder_Permission  The permissions on the share.
     */
    function &getPermission()
    {
        if (!isset($this->_perm)) {
            $this->_perm = &$this->storageObject->getPermission();
        }
        return $this->_perm;
    }

}

/**
 * Represents the share folder in the IMAP system
 *
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @author  Stuart Binge <omicron@mighty.co.za>
 * @since   Horde 3.2
 * @package Horde_Perms
 */
class ImapObject_Share {

    /**
     * The folder name of this share.
     *
     * These names have the same requirements as other object names - they
     * must be unique, etc.
     *
     * @var string
     */
    var $_folder;

    /**
     * The storage driver for this object.
     *
     * @var Horde_Share_Storage_kolab
     */
    var $_storage;

    /**
     * A cache for the folder attributes.
     *
     * @var array
     */
    var $data;

    /**
     * The permission handler for the share
     *
     * @var ImapFolder_Permission
     */
    var $_perm;

    /**
     * ImapObject_Share constructor.
     * Sets the folder name.
     *
     * @param string  $id   The share id.
     */
    function ImapObject_Share($id)
    {
        $this->_folder = KOLAB_SHARE_INVALID;

        // We actually ignore the random id string that all horde apps
        // provide as initial name and wait for a set('name', 'xyz')
        // call. But we want to know if we should create a default
        // share.
        if ($id == Auth::getAuth()) {
            $this->data['default'] = true;
        } else {
            $this->data['default'] = false;
        }
    }

    /**
     * Sets the storage driver for this storage object.
     *
     * @param Horde_Share_Storage_kolab $storage  A {@link Horde_Share_storage_kolab} instance.
     */
    function setStorage(&$storage)
    {
        $this->_storage = &$storage;
    }

    /**
     * Sets the folder name for this storage object.
     *
     * @param string  $folder  Name of the IMAP folder.
     * @param boolean $force   Enforce setting the folder.
     */
    function setFolder($folder, $force = false)
    {
        if ($this->_folder == KOLAB_SHARE_INVALID || $force) {
            $this->_folder = $folder;
            if (isset($this->_perm)) {
                $this->_perm->setFolder($folder);
            } else {
                if ($this->exists()) {
                    $perms = null;
                } else {
                    $perms = array('users' => array(Auth::getAuth() => PERMS_SHOW
                                                                     | PERMS_READ
                                                                     | PERMS_EDIT
                                                                     | PERMS_DELETE));
                }
                $perm = &new ImapFolder_Permission($folder,
                                                   $this->_storage->getImap(),
                                                   $this, $perms);
                $this->setPermission($perm);
            }
        }
    }

    /**
     * Gets the permissions from this storage object.
     *
     * @return ImapFolder_Permission  The permissions on the share.
     */
    function &getPermission()
    {
        if (!isset($this->_perm)) {
            $this->_perm = &new ImapFolder_Permission($this->_folder, $this->_storage->getImap(), $this);
        }
        return $this->_perm;
    }

    /**
     * Set the permission on this storage object.
     *
     * @param ImapFolder_Permission  $perm  The permissions for the share.
     */
    function setPermission(&$perm)
    {
        $this->_perm = &$perm;
    }

    /**
     * Gets the ID of this object.
     *
     * @return string  The object's ID.
     */
    function getId()
    {
        if ($this->get('default')) {
            return $this->_storage->buildShareId(Auth::getAuth());
        }
        return $this->_storage->buildShareId(rawurlencode($this->get('folder')));
    }

    /**
     * Gets the name of this object.
     *
     * @return string The object name.
     */
    function getName()
    {
        return $this->get('folder');
    }

    /**
     * Gets the title of this object.
     *
     * @param string  $title  Name of the IMAP folder.
     *
     * @return string The object title.
     */
    function getTitle($title = null)
    {
        if (empty($title)) {
            $title = $this->get('folder');
        }

        if (substr($title, 0, 6) == 'INBOX/') {
            $title = substr($title, 6);
        }
        $title = str_replace('/', ':', $title);

        return String::convertCharset($title, 'UTF7-IMAP');
    }

    /**
     * Test if the share exists.
     *
     * @return boolean  True if the share exists
     */
    function exists($share = null)
    {
        if (empty($share)) {
            $share = $this->_folder;
        }
        // Verify that the folder can be accessed
        $imap = &$this->_storage->getImap();
        $result = $imap->exists($share);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }
        return $result;
    }

    /**
     * Test if the share is accessible.
     *
     * @return boolean  True if the share can be accessed
     */
    function accessible($share = null)
    {
        if (empty($share)) {
            $share = $this->_folder;
        }
        // Verify that the folder can be accessed
        $imap = &$this->_storage->getImap();
        $result = $imap->select($share);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }
        return $result;
    }

    /**
     * Delete this object from the backend permanently.
     *
     * @return boolean|PEAR_Error  PEAR_Error on failure.
     */
    function delete()
    {
        return $this->_storage->remove($this);
    }

    /**
     * Set the name of this object.
     *
     * @param string $name  The new name of the object.
     *
     * @return mixed        True on success, a PEAR error otherwise
     */
    function setTitle($name)
    {
        return true;
    }

    /**
     * Is this a default share?
     *
     * @return mixed  Boolean that indicates the default status or a PEAR error
     *                if the folder annotation cannot be accessed.
     */
    function isDefault()
    {
        $imap = &$this->_storage->getImap();
        $annotation = $imap->getAnnotation(KOLAB_ANNOT_FOLDER_TYPE, 'value.shared', $this->_folder);
        if (is_a($annotation, 'PEAR_Error')) {
            return false;
        }
        if (empty($annotation)) {
            return false;
        }
        $type = explode('.', $annotation);
        return (!empty($type[1]) && $type[1] == 'default');
    }

    /**
     * Gets the owner of the shared folder.
     *
     * @return mixed The owner or a PEAR error
     */
    function getOwner()
    {
        if (!preg_match(";(shared\.|INBOX[/]?|user/([^/]+)/)([^@]+)(@.*)?;", $this->get('folder'), $matches)) {
            return PEAR::raiseError(sprintf(_("Owner of folder %s cannot be determined."), $this->get('folder')));
        }

        if (substr($matches[1], 0, 6) == 'INBOX/') {
            return Auth::getAuth();
        } elseif (substr($matches[1], 0, 5) == 'user/') {
            $domain = strstr(Auth::getAuth(), '@');
            $user_domain = isset($matches[4]) ? $matches[4] : $domain;
            $folder = isset($matches[4]) ? $this->get('folder') : $this->get('folder') . $user_domain;
            return $matches[2] . $user_domain;
        } elseif ($matches[1] == 'shared.') {
            return 'anonymous';
        }
    }

    /**
     * Gets one of the attributes of the object, or null if it isn't defined.
     *
     * @param string $attribute  The attribute to retrieve.
     *
     * @return mixed  The value of the attribute, or an empty string.
     */
    function getAttribute($attribute)
    {
        $imap = &$this->_storage->getImap();
        $annotation = $imap->getAnnotation(KOLAB_ANNOT_SHARE_ATTR . $attribute, 'value.shared', $this->_folder);
        if (is_a($annotation, 'PEAR_Error') || empty($annotation)) {
            $annotation = '';
        }
        return base64_decode($annotation);
    }

    /**
     * Gets one of the attributes of the object, or null if it isn't defined.
     *
     * @param string $attribute  The attribute to retrieve.
     *
     * @return mixed  The value of the attribute, or an empty string.
     */
    function get($attribute)
    {
        if (isset($this->data[$attribute])) {
            return $this->data[$attribute];
        }

        switch ($attribute) {
        case 'owner':
            $this->data['owner'] = $this->getOwner();
            break;

        case 'folder':
            $this->data['folder'] = $this->_folder;
            break;

        case 'name':
            $this->data['name'] = $this->getTitle();
            break;

        case 'params':
            $params = $this->getAttribute('params');
            if (is_a($params, 'PEAR_Error') || $params == '') {
                $params = serialize(array('source' => 'kolab'));
            }
            $this->data['params'] = $params;
            break;

        case 'default':
            $this->data['default'] = $this->isDefault();
            break;

        default:
            $annotation = $this->getAttribute($attribute);
            if (is_a($annotation, 'PEAR_Error') || empty($annotation)) {
                $annotation = '';
            }
            $this->data[$attribute] = $annotation;
            break;
        }

        return $this->data[$attribute];
    }

    /**
     * Sets one of the attributes of the object.
     *
     * @param string $attribute  The attribute to set.
     * @param mixed $value       The value for $attribute.
     */
    function set($attribute, $value)
    {
        switch ($attribute) {
        case 'name':
            /* On folder creation of default shares we wish to ignore
             * the names provided by the Horde applications. We use
             * the Kolab default names. */
            if ($this->_folder == KOLAB_SHARE_INVALID && $this->get('default')) {
                $value = 'INBOX/' . $this->_storage->getDefaultShareName();
            } else {
                $value = str_replace(':', '/', $value);
                if (substr($value, 0, 5) != 'user/' && substr($value, 0, 7) != 'shared.') {
                    $value = "INBOX/".$value;
                }
            }
            $this->data['folder'] = String::convertCharset($value, NLS::getCharset(), 'UTF7-IMAP');
            $this->data['name'] = $this->getTitle($this->data['folder']);
            break;

        default:
            $this->data[$attribute] = $value;
        }
    }

    /**
     * Saves the current attribute values in the cache to the imap folder.
     *
     * @return mixed  True on success or a PEAR error if the imap call failed
     */
    function save()
    {
        $result = Horde::callHook('_horde_hook_share_modify', array(&$this),
                                  'horde', false);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if ($this->get('folder') != $this->_folder) {
            $new_folder = $this->get('folder');

            if ($this->_folder != KOLAB_SHARE_INVALID) {
                $imap = &$this->_storage->getImap();
                $result = $imap->exists($new_folder);
                if (is_a($result, 'PEAR_Error')) {
                    $this->data['name'] = $this->getTitle($this->_folder);
                    return $result;
                }
                if ($result) {
                    $this->data['name'] = $this->getTitle($this->_folder);
                    return PEAR::raiseError(sprintf(_("Unable to rename %s to %s: destination folder already exists"), $this->_folder, $new_folder));
                }

                $result = $imap->rename($this->_folder, $new_folder);
                if (is_a($result, 'PEAR_Error')) {
                    $this->data['name'] = $this->getTitle($this->_folder);
                    return $result;
                }
            }
            $this->setFolder($new_folder, true);

            /* This is not funny anymore: We need to inform the
             * Horde_Share driver that the list cache needs to be
             * refreshed. This is another bad hack. */
            $this->_storage->dirty = true;
            $this->_storage->unsetShares();
        }

        foreach ($this->data as $attribute => $value) {
            if ($attribute == 'owner') {
                if ($value != $this->getOwner()) {
                    return PEAR::raiseError(_("Cannot modify the owner of a share!"));
                }
            } elseif ($attribute == 'default') {
                $imap = &$this->_storage->getImap();
                $annotation = $imap->getAnnotation(KOLAB_ANNOT_FOLDER_TYPE, 'value.shared', $this->_folder);
                if (is_a($annotation, 'PEAR_Error')) {
                    return $annotation;
                }
                $type = explode('.', $annotation);
                if ($value && empty($type[1])) {
                    $result = $imap->setAnnotation(KOLAB_ANNOT_FOLDER_TYPE, array('value.shared' => $type[0] . '.default'), $this->_folder);
                    if (is_a($result, 'PEAR_Error')) {
                        return $result;
                    }
                } elseif (!$value && !empty($type[1]) && $type[1] == 'default') {
                    $result = $imap->setAnnotation(KOLAB_ANNOT_FOLDER_TYPE, array('value.shared' => $type[0]), $this->_folder);
                    if (is_a($result, 'PEAR_Error')) {
                        return $result;
                    }
                }
            } elseif ($attribute == 'name') {
                continue;
            } elseif ($attribute == 'folder') {
                continue;
            } else {
                $imap = &$this->_storage->getImap();
                // setAnnotation apparently does not suppoort UTF-8 nor any special characters
                $store = base64_encode($value);
                $result = $imap->setAnnotation(KOLAB_ANNOT_SHARE_ATTR . $attribute, array('value.shared' => $store), $this->_folder);
                if (is_a($result, 'PEAR_Error')) {
                    return $result;
                }
            }
        }

        // Now the save object permissions
        if (isset($this->_perm)) {
            $result = $this->_perm->save();
            if (is_a($result, 'PEAR_Error')) {
                return $result;
            }
        }

        return true;
    }

}

/**
 * FIXME: BAD HACK
 *
 * We derive the IMAP implementation from the datatree permission backend.
 * There is a lot of functionality already in that class
 * definition. Nevertheless this is the wrong approach. In principle the
 * shared code should be provided by a basic class and the specific
 * implementations based on it rather than overloading the datatree methods.
 */
require_once 'Horde/Perms/datatree.php';

/**
 * A wrapper that handles permissions on an IMAP folder
 *
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @author  Stuart Binge <omicron@mighty.co.za>
 * @since   Horde 3.2
 * @package Horde_Perms
 */
class ImapFolder_Permission extends DataTreeObject_Permission {

    /**
     * The folder name.
     *
     * @var string
     */
    var $_folder;

    /**
     * The imap connection.
     *
     * @var string
     */
    var $_imap;

    /**
     * A cache for the folder acl settings. The cache holds the permissions
     * in horde compatible format, not in the IMAP permission format.
     *
     * @var string
     */
    var $data;

    /**
     * The storage driver for this object.
     *
     * @var Horde_Share_Storage_kolab
     */
    var $_storage;

    /**
     * The ImapFolder_Permission constructor.
     *
     * @param string                 $folder   The name of the folder that
                                               these permissions belongs to.
     * @param Kolab_IMAP_Connection  $imap     The IMAP connection to the server
     * @param Horde_Storage          $storage  A reference to the storage class
     * @param array                  $perms    A set of initial permissions.
     */
    function ImapFolder_Permission($folder, &$imap, &$storage, $perms = null)
    {
        $this->_folder = $folder;
        $this->_imap = &$imap;
        $this->_storage = &$storage;

        // Load the permission from the folder now
        if (empty($perms)) {
            $perms = $this->getPerm();
            // Exit on error
            if (is_a($perms, 'PEAR_Error')) {
                return $perms;
            }
        }

        $this->data = $perms;
    }

    /**
     * Sets the folder name for this permission object.
     *
     * @param string $folder  Name of the IMAP folder.
     */
    function setFolder($folder)
    {
        $this->_folder = $folder;
    }

    /**
     * Gets one of the attributes of the object, or null if it isn't defined.
     *
     * @param string $attribute  The attribute to get.
     *
     * @return mixed  The value of the attribute, or null.
     */
    function get($attribute)
    {
        // This object only handles permissions. So only return these
        switch ($attribute) {
        case 'perm':
            return $this->data;
        case 'type':
            return 'matrix';
        default:
            // User requested something other than permissions: return null
            return null;
        }
    }

    /**
     * Gets the current permission of the folder and stores the values in the
     * cache.
     *
     * @return mixed  True on success or a PEAR error if the imap call failed
     */
    function getPerm()
    {
        // Perform the imap call
        $acl = $this->_imap->getACL($this->_folder);
        if (is_a($acl, 'PEAR_Error')) {
            return $acl;
        }

        // Loop through the returned users
        $data = array();
        foreach ($acl as $user => $rights) {
            // Convert the user rights to horde format
            $result = 0;
            for ($i = 0, $j = strlen($rights); $i < $j; $i++) {
                switch ($rights[$i]) {
                case 'l':
                    $result |= PERMS_SHOW;
                    break;
                case 'r':
                    $result |= PERMS_READ;
                    break;
                case 'i':
                    $result |= PERMS_EDIT;
                    break;
                case 'd':
                    $result |= PERMS_DELETE;
                    break;
                }
            }

            // Check for special users
            $name = '';
            switch ($user) {
            case 'anyone':
                $name = 'default';
                break;
            case 'anonymous':
                $name = 'guest';
                break;
            }

            // Did we have a special user?
            if ($name) {
                // Store the converted acl in the cache
                $data[$name] = $result;
                continue;
            }

            // Is it a group?
            if (substr($user, 0, 6) == 'group:') {
                // Store the converted acl in the cache
                $data['groups'][substr($user, 6)] = $result;
                continue;
            }

            // Standard user
            // Store the converted acl in the cache
            $data['users'][$user] = $result;
        }

        return $data;
    }

    /**
     * Saves the current permission values in the cache to the imap folder.
     *
     * @return mixed  True on success or a PEAR error if the imap call failed
     */
    function save()
    {
        $current = $this->getPerm();

        foreach ($this->data as $user => $user_perms) {
            if (is_array($user_perms)) {
                foreach ($user_perms as $userentry => $perms) {
                    if ($user == 'groups') {
                        $name = 'group:' . $userentry;
                    } else {
                        $name = $userentry;
                    }
                    $result = $this->savePermission($name, $perms);
                    if (is_a($result, 'PEAR_Error')) {
                        return $result;
                    }
                    unset($current[$user][$userentry]);
                }
            } else {
                switch ($user) {
                case 'default':
                    $name = 'anyone';
                    break;
                case 'guest':
                    $name = 'anonymous';
                    break;
                default:
                    continue;
                }

                $result = $this->savePermission($name, $user_perms);
                if (is_a($result, 'PEAR_Error')) {
                    return $result;
                }
                unset($current[$user]);
            }
        }

        // Delete ACLs that have been removed
        foreach ($current as $user => $user_perms) {
            if (is_array($user_perms)) {
                foreach ($user_perms as $userentry => $perms) {
                    $result = $this->_imap->deleteACL($this->_folder, $userentry);
                    if (is_a($result, 'PEAR_Error')) {
                        return $result;
                    }
                }
            } else {
                switch ($user) {
                case 'default':
                    $name = 'anyone';
                    break;
                case 'guest':
                    $name = 'anonymous';
                    break;
                default:
                    continue;
                }
                $result = $this->_imap->deleteACL($this->_folder, $name);
                if (is_a($result, 'PEAR_Error')) {
                    return $result;
                }
            }
        }

        // Load the permission from the folder again
        $this->data = $this->getPerm();

        return true;
    }

    /**
     * Saves the current permission values in the cache to the imap folder.
     *
     * @return mixed  True on success or a PEAR error if the imap call failed
     */
    function savePermission($user, $perms)
    {
        // Convert the horde permission style to IMAP permissions
        $result = $user == $this->_storage->getOwner() ? 'a' : '';
        if ($perms & PERMS_SHOW) {
            $result .= 'l';
        }
        if ($perms & PERMS_READ) {
            $result .= 'r';
        }
        if ($perms & PERMS_EDIT) {
            $result .= 'iswc';
        }
        if ($perms & PERMS_DELETE) {
            $result .= 'd';
        }

        // Save the ACL
        $result = $this->_imap->setACL($this->_folder, $user, $result);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        return true;
    }

    /**
     * Finds out what rights the given user has to this object.
     *
     * @param string $user       The user to check for. Defaults to the current
     *                           user.
     * @param string $creator    The user who created the object.
     *
     * @return mixed  A bitmask of permissions, a permission value, or an array
     *                of permission values the user has, depending on the
     *                permission type and whether the permission value is
     *                ambiguous. False if there is no such permsission.
     */
    function getPermissions($user = null, $creator = null)
    {
        if ($user === null) {
            $user = Auth::getAuth();
        }
        // If $creator was specified, check creator permissions.
        if ($creator !== null) {
            // If the user is the creator see if there are creator
            // permissions.
            if (strlen($user) && $user === $creator &&
                ($perms = $this->getCreatorPermissions()) !== null) {
                return $perms;
            }
        }

        // Check user-level permissions.
        $userperms = $this->getUserPermissions();
        if (isset($userperms[$user])) {
            return $userperms[$user];
        }

        // If no user permissions are found, try group permissions.
        $groupperms = $this->getGroupPermissions();
        if (!empty($groupperms)) {
            require_once 'Horde/Group.php';
            $groups = &Group::singleton();

            $composite_perm = null;
            foreach ($this->data['groups'] as $group => $perm) {
                if ($groups->userIsInGroup($user, $group)) {
                    if ($composite_perm === null) {
                        $composite_perm = 0;
                    }
                    $composite_perm |= $perm;
                }
            }

            if ($composite_perm !== null) {
                return $composite_perm;
            }
        }

        // If there are default permissions, return them.
        if (($perms = $this->getDefaultPermissions()) !== null) {
            return $perms;
        }

        // Otherwise, deny all permissions to the object.
        return false;
    }

    /**
     * Finds out if the user has the specified rights to the given object.
     *
     * @param string $user        The user to check for.
     * @param integer $perm       The permission level that needs to be checked
     *                            for.
     * @param string $creator     The creator of the shared object.
     *
     * @return boolean  True if the user has the specified permissions.
     */
    function hasPermission($user, $perm, $creator = null)
    {
        return ($this->getPermissions($user, $creator) & $perm);
    }

}
