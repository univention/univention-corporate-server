<?php
/**
 * The Horde_Cache_sql:: class provides a SQL implementation of the Horde
 * Caching system.
 *
 * Required parameters:<pre>
 *   'phptype'      The database type (ie. 'pgsql', 'mysql', etc.).</pre>
 *
 * Required by some database implementations:<pre>
 *   'database'     The name of the database.
 *   'hostspec'     The hostname of the database server.
 *   'username'     The username with which to connect to the database.
 *   'password'     The password associated with 'username'.
 *   'options'      Additional options to pass to the database.
 *   'tty'          The TTY on which to connect to the database.
 *   'port'         The port on which to connect to the database.</pre>
 *
 * Optional parameters:<pre>
 *   'table'               The name of the cache table in 'database'.
 *                         Defaults to 'horde_cache'.
 *   'use_memorycache'     Use a Horde_Cache:: memory caching driver to cache
 *                         the data (to avoid DB accesses).  Either empty or
 *                         'none' if not needed, or else the name of a valid
 *                         Horde_Cache:: driver.</pre>
 *
 * Optional values when using separate reading and writing servers, for example
 * in replication settings:<pre>
 *   'splitread'   Boolean, whether to implement the separation or not.
 *   'read'        Array containing the parameters which are different for
 *                 the read database connection, currently supported
 *                 only 'hostspec' and 'port' parameters.</pre>
 *
 * The table structure for the cache is as follows:
 * <pre>
 * CREATE TABLE horde_cache (
 *     cache_id          VARCHAR(32) NOT NULL,
 *     cache_timestamp   BIGINT NOT NULL,
 *     cache_data        LONGBLOB,
 *     (Or on PostgreSQL:)
 *     cache_data        TEXT,
 *     (Or on some other DBMS systems:)
 *     cache_data        IMAGE,
 *
 *     PRIMARY KEY (cache_id)
 * );
 * </pre>
 *
 * $Horde: framework/Cache/Cache/sql.php,v 1.10 2007/06/14 20:19:17 chuck Exp $
 *
 * Copyright 2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Michael Slusarz <slusarz@curecanti.org>
 * @since   Horde 3.2
 * @package Horde_Cache
 */
class Horde_Cache_sql extends Horde_Cache {

    /**
     * Handle for the current database connection.
     *
     * @var DB
     */
    var $_db;

    /**
     * Handle for the current database connection, used for writing. Defaults
     * to the same handle as $_db if a separate write database isn't required.
     *
     * @var DB
     */
    var $_write_db;

    /**
     * Boolean indicating whether or not we're connected to the SQL server.
     *
     * @var boolean
     */
    var $_connected = false;

    /**
     * The memory cache object to use, if configured.
     *
     * @var Horde_Cache
     */
    var $_mc = null;

    /**
     * Constructs a new Horde_Cache_sql object.
     *
     * @param array $params  A hash containing configuration parameters.
     */
    function Horde_Cache_sql($params = array())
    {
        $options = array(
            'database' => '',
            'username' => '',
            'password' => '',
            'hostspec' => '',
            'table' => 'horde_cache'
        );
        $this->_params = array_merge($options, $params);

        /* Create the memory cache object, if configured. */
        if (!empty($this->_params['use_memorycache'])) {
            $this->_mc = &Horde_Cache::singleton($params['use_memorycache'], !empty($conf['cache'][$params['use_memorycache']]) ? $conf['cache'][$params['use_memorycache']] : array());
        }

        /* Only do garbage collection if asked for, and then only 0.1% of the
         * time we create an object. */
        if (rand(0, 999) == 0) {
            register_shutdown_function(array(&$this, '_doGC'));
        }

        parent::Horde_Cache($params);
    }

    /**
     * Attempts to retrieve cached data.
     *
     * @param string $key        Cache key to fetch.
     * @param integer $lifetime  Lifetime of the data in seconds.
     *
     * @return mixed  Cached data, or false if none was found.
     */
    function get($key, $lifetime = 1)
    {
        $key = md5($key);

        if ($this->_mc) {
            $data = $this->_mc->get($key, $lifetime);
            if ($data !== false) {
                return $data;
            }
        }

        if (is_a(($result = $this->_connect()), 'PEAR_Error')) {
            return false;
        }

        /* Build SQL query. */
        $query = 'SELECT cache_data FROM ' . $this->_params['table']
            . ' WHERE cache_id = ? AND cache_timestamp < ?';
        $values = array($key, time() - $timeout);

        $result = $this->_db->getOne($query, $values);
        if (is_a($result, 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        } else {
            if ($this->_mc) {
                $this->_mc->set($key, $result);
            }
            return $result;
        }
    }

    /**
     * Attempts to store data.
     *
     * @param string $key        Cache key.
     * @param mixed $data        Data to store in the cache. (MUST BE A STRING)
     * @param integer $lifetime  Data lifetime. @since Horde 3.2
     *
     * @return boolean  True on success, false on failure.
     */
    function set($key, $data, $lifetime = null)
    {
        $key = md5($key);
        if ($this->_mc) {
            $this->_mc->set($key, $data);
        }

        if (is_a(($result = $this->_connect()), 'PEAR_Error')) {
            return false;
        }

        $timestamp = time();
        $lifetime = $this->_getLifetime($lifetime);

        // TODO: Non-zero lifetimes not yet supported here yet.

        /* Build SQL query. */
        $query = 'INSERT INTO ' . $this->_params['table']
            . ' (cache_id, cache_timestamp, cache_data)'
            . ' VALUES (?, ?, ?)';
        $values = array($key, time(), $data);

        $result = $this->_write_db->query($query, $values);
        if (is_a($result, 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }

        return true;
    }

    /**
     * Checks if a given key exists in the cache, valid for the given
     * lifetime.
     *
     * @param string $key        Cache key to check.
     * @param integer $lifetime  Lifetime of the key in seconds.
     *
     * @return boolean  Existance.
     */
    function exists($key, $lifetime = 1)
    {
        $md5_key = md5($key);
        $mc_expire = false;

        if ($this->_mc) {
            if ($this->_mc->exists($md5_key, $lifetime)) {
                return true;
            }
            $mc_expire = true;
        }

        if (is_a(($result = $this->_connect()), 'PEAR_Error')) {
            return false;
        }

        if ($mc_expire) {
            $this->expire($key);
            return false;
        }

        /* Build SQL query. */
        $query = 'SELECT cache_id, cache_timestamp'
            . ' FROM ' . $this->_params['table']
            . ' WHERE cache_id = ?';
        $values = array($md5_key, time() - $lifetime);

        $result = $this->_db->getRow($query, $values);
        if (is_a($result, 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }

        if (empty($result)) {
            return false;
        }
        if ((time() - $lifetime) > $result[1]) {
            $this->expire($key);
            // It is possible to make it here and have a memory cached entry
            // that is expired.  This will happen if our memory cache object
            // was built after the SQL entry was created (i.e. memcache server
            // was reloaded) so we need to explicitly expire the entry.
            if ($this->_mc) {
                $this->_mc->expire($md5_key);
            }
            return false;
        }

        return true;
    }

    /**
     * Expire any existing data for the given key.
     *
     * @param string $key  Cache key to expire.
     *
     * @return boolean  Success or failure.
     */
    function expire($key)
    {
        $key = md5($key);
        if ($this->_mc) {
            $this->_mc->expire($key);
        }

        if (is_a(($result = $this->_connect()), 'PEAR_Error')) {
            return false;
        }

        $query = 'DELETE FROM ' . $this->_params['table']
            . ' WHERE cache_id = ?';
        $values = array($key);

        $result = $this->_write_db->query($query, $values);
        if (is_a($result, 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return false;
        }
        return true;
    }

    /**
     * Opens a connection to the SQL server.
     *
     * @return boolean  True on success, a PEAR_Error object on failure.
     */
    function _connect()
    {
        if ($this->_connected) {
            return true;
        }

        $result = Util::assertDriverConfig($this->_params, array('phptype'),
                                           'cache SQL', array('driver' => 'cache'));
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        require_once 'DB.php';
        $this->_write_db = &DB::connect(
            $this->_params,
            array('persistent' => !empty($this->_params['persistent']))
        );
        if (is_a($this->_write_db, 'PEAR_Error')) {
            return $this->_write_db;
        }

        // Set DB portability options.
        $portability = DB_PORTABILITY_LOWERCASE | DB_PORTABILITY_ERRORS;
        if ($this->_write_db->phptype) {
            $portability |= DB_PORTABILITY_RTRIM;
        }
        $this->_write_db->setOption('portability', $portability);

        /* Check if we need to set up the read DB connection
         * seperately. */
        if (!empty($this->_params['splitread'])) {
            $params = array_merge($this->_params, $this->_params['read']);
            $this->_db = &DB::connect(
                $params,
                array('persistent' => !empty($params['persistent']))
            );
            if (is_a($this->_db, 'PEAR_Error')) {
                return $this->_db;
            }

            // Set DB portability options.
            $portability = DB_PORTABILITY_LOWERCASE | DB_PORTABILITY_ERRORS;
            if ($this->_db->phptype) {
                $portability |= DB_PORTABILITY_RTRIM;
            }
            $this->_db->setOption('portability', $portability);
        } else {
            /* Default to the same DB handle for read. */
            $this->_db = $this->_write_db;
        }

        $this->_connected = true;
        return true;
    }

    /**
     * Do garbage collection needed for the driver.
     *
     * @access private
     */
    function _doGC()
    {
        if (is_a(($result = $this->_connect()), 'PEAR_Error')) {
            return false;
        }

        $query = 'DELETE FROM ' . $this->_params['table']
            . ' WHERE cache_id = ? AND cache_timestamp < ? AND cache_timestamp != 0';
        $values = array(md5($key), time() - $secs);

        $result = $this->_write_db->query($query, $values);
        if (is_a($result, 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
        }
    }

}
