<?php
/**
 * $Horde: framework/RPC/RPC/webdav.php,v 1.22 2007/06/29 12:35:16 jan Exp $
 *
 * @package Horde_RPC
 */

/** HTTP_WebDAV_Server */
include_once 'HTTP/WebDAV/Server.php';

/**
 * The Horde_RPC_webdav class provides a WebDAV implementation of the
 * Horde RPC system.
 *
 * Copyright 2004-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Chuck Hagenbuch <chuck@horde.org>
 * @since   Horde 3.0
 * @package Horde_RPC
 */
class Horde_RPC_webdav extends Horde_RPC {

    /**
     * Resource handler for the WebDAV server.
     *
     * @var HTTP_WebDAV_Server_Horde
     */
    var $_server;

    /**
     * WebDav server constructor.
     *
     * @access private
     */
    function Horde_RPC_webdav()
    {
        parent::Horde_RPC();
        $this->_server = new HTTP_WebDAV_Server_Horde();
    }

    /**
     * WebDAV handles authentication internally, so bypass the
     * system-level auth check by just returning true here.
     */
    function authorize()
    {
        return true;
    }

    /**
     * If the webdav backend is used, the input should not be read, it is
     * being read by HTTP_WebDAV_Server.
     */
    function getInput()
    {
    }

    /**
     * Sends an RPC request to the server and returns the result.
     *
     * @param string  The raw request string.
     *
     * @return string  The XML encoded response from the server.
     */
    function getResponse($request)
    {
        $this->_server->ServeRequest();
        exit;
    }

}

/**
 * Horde extension of the base HTTP_WebDAV_Server class.
 *
 * @package Horde_RPC
 */
class HTTP_WebDAV_Server_Horde extends HTTP_WebDAV_Server {

    /**
     * Realm string to be used in authentification popups
     *
     * @var string
     */
    var $http_auth_realm = 'Horde WebDAV';

    /**
     * String to be used in "X-Dav-Powered-By" header
     *
     * @var string
     */
    var $dav_powered_by = 'Horde WebDAV Server';

    /**
     * GET implementation.
     *
     * @param array $options  Array of input and output parameters.
     * <br><strong>input</strong><ul>
     * <li> path -
     * </ul>
     * <br><strong>output</strong><ul>
     * <li> size -
     * </ul>
     *
     * @return string|boolean  HTTP-Statuscode.
     */
    function GET(&$options)
    {
        if ($options['path'] == '/') {
            $options['mimetype'] = 'httpd/unix-directory';
        } else {
            $result = $this->_list($options['path'], 0);
            if ($result === false) {
                return '500 Internal Server Error. Check server logs';
            }
            $options = $result;
        }

        return true;
    }

    /**
     * PUT implementation.
     *
     * @param array &$options  Parameter passing array.
     *
     * @return string|boolean  HTTP-Statuscode.
     */
    function PUT(&$options)
    {
        $path = $options['path'];
        if (substr($path, 0, 1) == '/') {
            $path = substr($path, 1);
        }
        $pieces = explode('/', $path);

        $content = '';
        while (!feof($options['stream'])) {
            $content .= fgets($options['stream']);
        }

        $result = $GLOBALS['registry']->callByPackage($pieces[0], 'put', array('path' => $path, 'content' => $content, 'type' => $options['content_type']));
        if (is_a($result, 'PEAR_Error')) {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            return '500 Internal Server Error. Check server logs';
        }

        return true;
    }

    /**
     * Perform a WebDAV DELETE.
     *
     * Delete a single object from a database.The path passed in must
     * be in [app]/[collection]/[uid] format.
     *
     * @see HTTP_WebDAV_Server::http_DELETE()
     *
     * @param array $options An array of parameters from the setup
     * method in HTTP_WebDAV_Server.
     *
     * @return string|boolean  HTTP-Statuscode.
     */
    function DELETE($options)
    {
        $path = $options['path'];
        $pieces = explode('/', trim($this->path, '/'));

        if (count($pieces) == 3) {
            $app = $pieces[0];
            $collection = $pieces[1];
            $item = $pieces[2];

            // TODO: Support HTTP/1.1 If-Match on ETag here

            // Delete access is checked in each app.
            $result = $GLOBALS['registry']->callByPackage($app, 'delete', array($item));
            if (is_a($result, 'PEAR_Error')) {
                Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_INFO);
                return '500 Internal Server Error. Check server logs';
            }

            return '204 No Content';
        } else {
            Horde::logMessage('Can\'t delete from path "' . $path . '", use [app]/[collection]/[uid]', __FILE__, __LINE__, PEAR_LOG_INFO);
            return '500 Internal Server Error. Check server logs';
        }
    }

    /**
     * PROPFIND method handler
     *
     * @param array $options  General parameter passing array.
     * @param array &$files  Return array for file properties.
     *
     * @return boolean  True on success.
     */
    function PROPFIND($options, &$files)
    {
        $list = $this->_list($options['path'], $options['depth']);
        if ($list === false) {
            return false;
        }
        $files['files'] = $list;
        return true;
    }

    function _list($path, $depth)
    {
        global $registry;

        $list = array(
            array('path' => $this->path,
                'props' => array(
                    $this->mkprop('displayname', $this->path),
                    $this->mkprop('creationdate', time()),
                    $this->mkprop('getlastmodified', time()),
                    $this->mkprop('resourcetype', 'collection'),
                    $this->mkprop('getcontenttype', 'httpd/unix-directory'),
                    $this->mkprop('getcontentlength', 0))));
        if ($path == '/') {
            $apps = $registry->listApps(null, false, PERMS_READ);
            if (is_a($apps, 'PEAR_Error')) {
                Horde::logMessage($apps, __FILE__, __LINE__, PEAR_LOG_ERR);
                return false;
            }
            foreach ($apps as $app) {
                if ($registry->hasMethod('browse', $app)) {
                    $props = array(
                        $this->mkprop('displayname', String::convertCharset($registry->get('name', $app), NLS::getCharset(), 'UTF-8')),
                        $this->mkprop('creationdate', time()),
                        $this->mkprop('getlastmodified', time()),
                        $this->mkprop('resourcetype', 'collection'),
                        $this->mkprop('getcontenttype', 'httpd/unix-directory'),
                        $this->mkprop('getcontentlength', 0));
                    $item = array('path' => $this->path . '/' . $app,
                                  'props' => $props);
                    $list[] = $item;
                }
            }
        } else {
            if (substr($path, 0, 1) == '/') {
                $path = substr($path, 1);
            }
            $pieces = explode('/', $path);
            $items = $registry->callByPackage($pieces[0], 'browse', array('path' => $path, 'properties' => array('name', 'browseable', 'contenttype', 'contentlength', 'created', 'modified')));
            if (is_a($items, 'PEAR_Error')) {
                Horde::logMessage($items, __FILE__, __LINE__, PEAR_LOG_ERR);
                return false;
            }
            if (!is_array(reset($items))) {
                /* We return an object's content. */
                return $items;
            }
            foreach ($items as $sub_path => $i) {
                $props = array(
                    $this->mkprop('displayname', String::convertCharset($i['name'], NLS::getCharset(), 'UTF-8')),
                    $this->mkprop('creationdate', empty($i['created']) ? 0 : $i['created']),
                    $this->mkprop('getlastmodified', empty($i['modified']) ? 0 : $i['modified']),
                    $this->mkprop('resourcetype', $i['browseable'] ? 'collection' : ''),
                    $this->mkprop('getcontenttype', $i['browseable'] ? 'httpd/unix-directory' : (empty($i['contenttype']) ? 'application/octet-stream' : $i['contenttype'])),
                    $this->mkprop('getcontentlength', empty($i['contentlength']) ? 0 : $i['contentlength']));
                $item = array('path' => '/' . $sub_path,
                              'props' => $props);
                $list[] = $item;
            }
        }

        if ($depth) {
            if ($depth == 1) {
                $depth = 0;
            }
            foreach ($list as $app => $item) {
                // _list($path . '/' . $item, $depth);
            }
        }

        return $list;
    }

    /**
     * Check authentication. We always return true here since we
     * handle permissions based on the resource that's requested, but
     * we do record the authenticated user for later use.
     *
     * @param string $type      Authentication type, e.g. "basic" or "digest"
     * @param string $username  Transmitted username.
     * @param string $password  Transmitted password.
     *
     * @return boolean  Authentication status. Always true.
     */
    function check_auth($type, $username, $password)
    {
        $auth = &Auth::singleton($GLOBALS['conf']['auth']['driver']);
        return $auth->authenticate($username, array('password' => $password));
    }

}
