<?php

require_once 'SyncML.php';
require_once 'SyncML/State.php';
require_once 'SyncML/Command/Status.php';

/**
 * The Horde_RPC_syncml class provides a SyncML implementation of the Horde
 * RPC system.
 *
 * $Horde: framework/RPC/RPC/syncml.php,v 1.37 2007/06/27 17:23:00 jan Exp $
 *
 * Copyright 2003-2007 The Horde Project (http://www.horde.org/)
 * Copyright 2003-2007 Anthony Mills <amills@pyramid6.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Chuck Hagenbuch <chuck@horde.org>
 * @author  Anthony Mills <amills@pyramid6.com>
 * @since   Horde 3.0
 * @package Horde_RPC
 */


class Horde_RPC_syncml extends Horde_RPC {

    /**
     * TODO
     *
     * @var integer
     */
    var $_xmlStack = 0;

    /**
     * Default character set.  Only supports UTF-8(ASCII?).
     *
     * @var string
     */
    var $_charset = 'UTF-8';

    /**
     * The contentHandler for parsing the input XML.
     *
     * @var SyncML_ContentHandler
     */
    var $_contentHandler;

    /**
     * SyncML handles authentication internally, so bypass the RPC framework
     * auth check by just returning true here.
     */
    function authorize()
    {
        return true;
    }

    /**
     * Sends an RPC request to the server and returns the result.
     *
     * @param string $request  The raw request string.
     *
     * @return string  The XML encoded response from the server.
     */
    function getResponse($request)
    {
        $backendparms = array(
        /* debug output to this dir, must be writeable be web server: */
        'debug_dir' => '/tmp/sync',
        /* log all (wb)xml packets received or sent to debug_dir: */
        'debug_files' => true,
        /* Log everything: */
        'log_level' => PEAR_LOG_DEBUG);

        /* Create the Backend*/
        $GLOBALS['backend'] = SyncML_Backend::factory('Horde', $backendparms);

        $h = new SyncML_ContentHandler();

        $response = $h->process($request, $this->getResponseContentType());

        $GLOBALS['backend']->close();

        return $response;
    }

    /**
     * Returns the Content-Type of the response.
     *
     * @return string  The MIME Content-Type of the RPC response.
     */
    function getResponseContentType()
    {
        return 'application/vnd.syncml+xml';
    }

    function raiseError($str)
    {
        return Horde::logMessage($str, __FILE__, __LINE__, PEAR_LOG_ERR);
    }

}
