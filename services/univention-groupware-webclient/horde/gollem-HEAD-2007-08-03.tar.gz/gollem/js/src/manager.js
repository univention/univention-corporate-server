/**
 * Provides the javascript for the manager.php script.
 *
 * $Horde: gollem/js/src/manager.js,v 1.3 2007/06/19 04:42:54 chuck Exp $
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */

function toggleRow()
{
    $$('table.striped').each(function(t) {
        $A(t.getElementsByTagName('tr')).each(function(tr) {
            Event.observe(tr, 'mouseover', function() { $A(this.getElementsByTagName('TD')).each(function(t) { Element.addClassName(t, 'selected'); }); }.bindAsEventListener(tr));
            Event.observe(tr, 'mouseout', function() { $A(this.getElementsByTagName('TD')).each(function(t) { Element.removeClassName(t, 'selected'); }); }.bindAsEventListener(tr));
        });
    });
}

function getChecked()
{
    return getElements().findAll(function(e) {
        return e.checked;
    });
}

function getElements()
{
    return Form.getInputs('manager', null, 'items[]');
}

function getSelected()
{
    var sel = '';
    getChecked().each(function(e) {
        sel += e.value + "\n";
    });

    if (sel.charAt(sel.length - 1) == "\n") {
        sel = sel.substring(0, sel.length - 1);
    }

    return sel;
}

function getItemsArray()
{
    var e = getElements(), it = Form.getInputs('manager', null, 'itemTypes[]'), items = [], i = 0;

    e.each(function(m) {
        items.push({ c: m.checked, v: m.value, t: it[i++].value});
    });

    return items;
}

function getSelectedFoldersList()
{
    var sel = '';
    getItemsArray().each(function(i) {
        if (i.checked && i.t == '**dir') {
            sel += i.v + '\n';
        }
    });

    var sel_length = sel.length;
    if (sel.length && sel.charAt(sel.length - 1) == "\n") {
        sel = sel.substring(0, sel.length - 1);
    }

    return sel;
}

function chooseAction(i)
{
    var a = $('action' + i);
    var action = a.options[a.selectedIndex].value;

    if (action == 'create_folder') {
        createFolder();
    } else if (action == 'change_directory') {
        changeDirectory();
    } else if (action == 'paste_items') {
        pasteItems();
    } else if (getChecked().length == 0) {
        alert(GollemText.select_item);
    } else if (action == 'rename_items') {
        renameItems();
    } else if (action == 'delete_items') {
        deleteItems();
    } else if (action == 'chmod_modify') {
        chmodItems();
    } else if (action == 'cut_items') {
        cutItems();
    } else if (action == 'copy_items') {
        copyItems();
    }
}

function createFolder()
{
    getChecked().each(function(e) {
        e.checked = false;
    });

    Element.show('createFolder');
    Field.focus('createfrm_fname');
}

function changeDirectory()
{
    getChecked().each(function(e) {
        e.checked = false;
    });

    Element.show('changeDirectory');
    Field.focus('createfrm_fname');
}

function renameItems()
{
    var c = getChecked();
    if (c.length) {
        c[0].checked = false;
        $('renamefrm_oldname').value = $('renamefrm_newname').value = c[0].value;
        Element.show('rename');
        Field.focus('renamefrm_newname');
    }
}

function deleteItems()
{
    var cont = false;

    if (window.confirm(GollemText.delete_confirm_1 + '\n' + getSelected() + '\n' + GollemText.delete_confirm_2)) {
        if (warn_recursive) {
            var sf = getSelectedFoldersList();
            if (sf.length > 0) {
                if (window.confirm(GollemText.delete_recurs_1 + '\n' + sf + '\n' + GollemText.delete_recurs_2)) {
                    cont = true;
                }
            } else {
                cont = true;
            }
        } else {
            cont = true;
        }
    }

    if (cont) {
        $('actionID').value = 'delete_items';
        $('manager').submit();
    }
}

function chmodItems()
{
    Element.show('attributes');
}

function cutItems()
{
    $('actionID').value = 'cut_items';
    $('manager').submit();
}

function copyItems()
{
    $('actionID').value = 'copy_items';
    $('manager').submit();
}

function pasteItems()
{
    $('actionID').value = 'paste_items';
    $('manager').submit();
}

function toggleSelection()
{
    var c = getChecked(), e = getElements();
    var checked = (c.length != e.length);
    e.each(function(f) {
        f.checked = checked;
    });
}

function createFolderOK()
{
    Element.hide('createFolder');
    if ($F('createfrm_fname')) {
        $('new_folder').value = $F('createfrm_fname');
        $('actionID').value = 'create_folder';
        $('manager').submit();
    }
}

function createFolderKeyCheck(e)
{
    if (e.keyCode == Event.KEY_ESC) {
        createFolderCancel();
        return false;
    } else if (e.keyCode == EVENT.KEY_RETURN) {
        createFolderOK();
        return false;
    }
    return true;
}

function createFolderCancel()
{
    Element.hide('createFolder');
    Form.reset('createfrm');
}

function chmodCancel()
{
    Element.hide('attributes');
    Form.reset('chmodfrm');
}

function chmodSave()
{
    var owner = 0, group = 0, all = 0;

    $A(document.chmodfrm.elements).each(function(e) {
        if (e.name == "owner[]" && e.checked) {
            owner |= e.value;
        } else if (e.name == "group[]" && e.checked) {
            group |= e.value;
        } else if (e.name == "all[]" && e.checked) {
            all |= e.value;
        }
    });

    Element.hide('attributes');

    $('chmod').value = "0" + owner + "" + group + "" + all;
    $('actionID').value = 'chmod_modify';
    $('manager').submit();
}

function renameOK()
{
    var newNames = $F('new_names');
    var oldNames = $F('old_names');
    var newname = $F('renamefrm_newname');
    var oldname = $F('renamefrm_oldname');

    if (newname && newname != oldname) {
        newNames += "|" + newname;
        oldNames += "|" + oldname;
    }

    if (newNames.charAt(0) == "|") {
        newNames = newNames.substring(1);
    }
    if (oldNames.charAt(0) == "|") {
        oldNames = oldNames.substring(1);
    }

    $('new_names').value = newNames;
    $('old_names').value = oldNames;

    var c = getChecked();
    if (c.length) {
        c[0].checked = false;
        found = true;
        Element.show('rename');
        Field.focus(c[0].value);
    } else {
        $('actionID').value = 'rename_items';
        $('manager').submit();
    }

    return false;
}

function renameCancel()
{
    $('new_names').value = $('old_names').value = '';
    Element.hide('rename');
}

function renameKeyCheck(e)
{
    if (e.keyCode == Event.KEY_ESC) {
        renameOK();
        return false;
    }
    if (e.keyCode == Event.KEY_RETURN) {
        renameCancel();
        return false;
    }
    return true;
}

function changeDirectoryOK()
{
    Element.hide('changeDirectory');
    if ($F('cdfrm_fname')) {
        $('dir').value = $F('cdfrm_fname');
        $('manager').submit();
    }
}

function changeDirectoryKeyCheck(event)
{
    if (event.keyCode == Event.KEY_ESC) {
        changeDirectoryCancel();
        return false;
    } else if (event.keyCode == Event.KEY_RETURN) {
        changeDirectoryOK();
        return false;
    }
    return true;
}

function changeDirectoryCancel()
{
    Element.hide('changeDirectory');
    Form.reset('cdfrm');
}

function uploadFields()
{
    var fields = [];
    Form.getInputs('manager', 'file').each(function(m) {
        if (m.name.substr(0, 12) == 'file_upload_') {
            fields.push(m);
        }
    });
    return fields;
}

function uploadFile()
{
    if (uploadsExist()) {
        $('actionID').value = 'upload_file';
        $('manager').submit();
    }
}

function uploadsExist()
{
    if (GollemVar.empty_input ||
        uploadFields().detect(function(f) { return f.value.length; })) {
        return true;
    }
    alert(GollemText.specify_upload);
    Field.focus('file_upload_1');
    return false;
}

function uploadChanged()
{
    if (GollemVar.empty_input) {
        return;
    }

    var fields = uploadFields();
    var usedFields = fields.findAll(function(f) { return f.value.length; }).length;

    if (usedFields == fields.length) {
        var lastRow = $('upload_row_' + usedFields);
        if (lastRow) {
            var newRow = document.createElement('DIV');
            newRow.id = 'upload_row_' + (usedFields + 1);
            var strong = document.createElement('STRONG');
            newRow.appendChild(strong);
            strong.appendChild(document.createTextNode(GollemText.file + ' ' + (usedFields + 1) + ':'));
            newRow.appendChild(document.createTextNode(' '));
            var file = document.createElement('INPUT');
            file.type = 'file';
            newRow.appendChild(file);
            file.name = 'file_upload_' + (usedFields + 1);
            Event.observe(file, 'change', uploadChanged);
            file.size = 25;
            lastRow.parentNode.insertBefore(newRow, lastRow.nextSibling);
        }
    }
}

Event.observe(window, 'load', toggleRow);
