<?php define('GOLLEM_VERSION', 'H3 (1.1-cvs)') ?>
