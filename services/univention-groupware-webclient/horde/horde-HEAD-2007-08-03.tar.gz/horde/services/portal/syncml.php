<?php
/**
 * $Horde: horde/services/portal/syncml.php,v 1.18 2007/06/27 17:24:06 jan Exp $
 *
 * Copyright 2005-2007 Karsten Fourmont <karsten@horde.org>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */

@define('HORDE_BASE', dirname(__FILE__) . '/../..');
require_once HORDE_BASE . '/lib/base.php';
require_once 'Horde/Prefs/UI.php';

if (!Auth::isAuthenticated()) {
    Horde::authenticationFailureRedirect();
}

$driver = $GLOBALS['conf']['datatree']['driver'];
$params = Horde::getDriverConfig('datatree', $driver);
$params = array_merge($params, array( 'group' => 'horde.syncml' ));

$dt = &DataTree::singleton($driver, $params);

/* Username is used as root for syncml datatree.  (For historic
 * reasons.) */
$username = Auth::getAuth();
$group = 'syncml'; // preference group

$actionID = Util::getFormData('actionID');
switch ($actionID) {
case 'deleteanchor':
    $deviceid = Util::getFormData('deviceid');
    $db = Util::getFormData('db');
    $id = $username . ':' . $deviceid . ':' . $db;
    $id = $dt->remove($id, false);
    if (is_a($id, 'PEAR_Error')) {
        $notification->push(sprintf(_("Error deleting sync anchor: %s"), $id->getMessage()),
                            'horde.error');
    } else {
        $notification->push(_("$id Sync anchor for device '$deviceid' database '$db' deleted."),
                            'horde.success');
    }
    break;

case 'deletelog':
    $id = $dt->remove('previousSyncLog', false);
    if (is_a($id, 'PEAR_Error')) {
        $notification->push(sprintf(_("Error deleting sync log: %s"), $id->getMessage()),
                            'horde.error');
    } else {
        $notification->push(_("Sync log deleted"),
                            'horde.success');
    }
    break;

case 'deleteall':
    $id = $dt->remove($username, true);
    if (is_a($id, 'PEAR_Error')) {
        $notification->push(sprintf(_("Error deleting sync info: %s"), $id->getMessage()),
                            'horde.error');
    } else {
        $notification->push(_("$id Sync data deleted."),
                            'horde.success');
    }
    break;
}

/* Show the header. */
require_once 'Horde/Prefs/UI.php';
$result = Horde::loadConfiguration('prefs.php', array('prefGroups', '_prefs'), 'horde');
if (!is_a($result, 'PEAR_Error')) {
    extract($result);
}
$app = 'horde';

Prefs_UI::handleForm($group, $prefs);
Prefs_UI::generateHeader($group);

// @todo: move this to template
?>

<form method="post" name="prefs" action="<?php echo Horde::applicationUrl('/services/prefs.php') ?>">
<input type="hidden" name="actionID" value="update_prefs" />
<input type="hidden" name="group" value="<?php echo $group ?>" />
<input type="hidden" name="app" value="horde" />
Sorry, no configurable options yet.
<p>See <a href="http://wiki.horde.org/SyncHowTo">Sync HowTo</a> for further information.</p>
<?php /* $helplink=''; $pref='syncml_create_log'; require $registry->get('templates', 'horde') . '/prefs/checkbox.inc' */ ?>

<p class="nowrap">
 <input type="submit" class="button" value="Save Options" />
 <input type="reset" class="button" value="Undo Changes" />
 <input type="button" class="button" value="Return to Options" onclick="document.prefs.actionID.value=0; document.prefs.group.value=''; document.prefs.submit();" />
</p>
</form>
<?php

$id = $dt->getId($username);
if (is_a($id, 'PEAR_Error')) {
    $devices = null;
} else {
  $devices = $dt->get(DATATREE_FORMAT_FLAT, $username, true, DATATREE_ROOT, -1);
    if (is_array($devices) && count($devices) > 1) {
        array_shift($devices);
    }
}

// @todo: move to template
?>
<div class="header">
 <?php echo Horde::link(Horde::selfURL(), _("Refresh")) . Horde::img('reload.png', _("Reload"), '', $registry->getImageDir('horde')) ?></a>
 Timestamps of successful sync sessions
</div>
<table class="striped" >

<?php
    if (!is_array($devices)) {
        echo '<tr><td colspan=5>None</tr>';
    } else {
        echo '<tr><th>Device</th><th>Database</th><th>Server-TS</th><th>Client-TS</th><th>Delete</th></tr>';

        foreach ($devices as $device) {
            $tmp = explode(':', $device);
            if (is_array($tmp)) {
                $device_name = array_pop($tmp);
            }

            $id = $dt->getId($device);
            if (is_a($id, 'PEAR_Error')) {
                continue;
            }
            $summaries = $dt->get(DATATREE_FORMAT_TREE, $device, true,
                                      DATATREE_ROOT, 2);

            if (is_array($summaries[$id])) {
                $o = & $dt->getObjects(array_keys($summaries[$id]));

                foreach ($o as $oo) {
                    $t = explode(':', $oo->getName());
                    $db = array_pop($t);
                    $sa = $oo->get('ServerAnchor');
                    if (is_array($sa)) {
                        $sa = array_pop($sa);
                    }
                    $ca = $oo->get("ClientAnchor");
                    if (is_array($ca)) {
                        $ca = array_pop($ca);
                    }
                    // @todo: move to template
                    echo '<tr><td>' . $device_name . '</td><td>' . $db . '</td><td>' .
                        strftime($prefs->getValue('date_format') . ' %H:%M', $sa) .
                        '</td><td>' . $ca . '</td><td>' .
                        '<form method="post"><input type="hidden" name="deviceid" value="' .
                        $device_name . '"/>' .
                        '<input type="hidden" name="actionID" value="deleteanchor" />' .
                        '<input type="hidden" name="db" value="' . $db . '" />' .
                        '<input type="submit" class="button" value="Delete" /></form>' .
                        '</td></tr>';
                }
            }
        }
    }
        echo '<tr><td<colspan=5>'
             . '<form method="post">'
             . '<input type="hidden" name="actionID" value="deleteall" />'
             . '<input type="submit" class="button" value="Delete All SyncML Data" /></form>';

        echo '</table>';



require HORDE_TEMPLATES . '/common-footer.inc';
