<?php
/**
 * Script to set the new language.
 *
 * $Horde: horde/services/language.php,v 1.11 2007/01/02 12:49:01 jan Exp $
 *
 * Copyright 2003-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author Marko Djukic <marko@oblo.com>
 */

@define('HORDE_BASE', dirname(__FILE__) . '/..');
require_once HORDE_BASE . '/lib/base.php';

/* Set the language. */
$_SESSION['horde_language'] = NLS::select();
$prefs->setValue('language', $_SESSION['horde_language']);

/* Redirect to the url or login page if none given. */
$url = Util::getFormData('url');
if (empty($url)) {
    $url = Horde::applicationUrl('index.php', true);
}
header('Location: ' . $url);
