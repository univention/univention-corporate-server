/**
 * Javascript code for finding all tables with classname "striped" and
 * dynamically striping their row colors.
 *
 * $Horde: horde/js/src/stripe.js-prototype.js,v 1.3 2007/05/02 19:40:50 chuck Exp $
 *
 * @author Chuck Hagenbuch <chuck@horde.org>
 * @author Matt Warden <mwarden@gmail.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */

/* We do everything onload so that the entire document is present
 * before we start searching it for tables. */
Event.observe(window, 'load', findStripedElements);

function findStripedElements()
{
    $$('.striped').each(stripeElement);
}

function stripeElement(elt)
{
    if (elt.tagName == 'TABLE') {
        return stripeTable(elt);
    }

    var classes = ['rowEven', 'rowOdd'];

    // Toggle the classname of any child node that is an element.
    $A(elt.childNodes).each(function(t) {
        if (t.nodeType && t.nodeType == 1) {
            Element.removeClassName(t, classes[1]);
            Element.addClassName(t, classes[0]);
            classes.reverse(true);
        }
    });
}

function stripeTable(table)
{
    var classes = ['rowEven', 'rowOdd'];

    // Tables can have more than one tbody element; get all child
    // tbody tags and interate through them.
    $A(table.childNodes).each(function(t) {
        if (t.tagName == 'TBODY') {
            $A(t.childNodes).each(function(c) {
                if (c.tagName == 'TR') {
                    Element.removeClassName(c, classes[1]);
                    Element.addClassName(c, classes[0]);
                    classes.reverse(true);
                }
            });
        }
    });
}
