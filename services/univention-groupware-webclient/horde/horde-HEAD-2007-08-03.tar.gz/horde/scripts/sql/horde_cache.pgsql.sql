-- $Horde: horde/scripts/sql/horde_cache.pgsql.sql,v 1.1 2007/05/23 12:15:25 slusarz Exp $

CREATE TABLE horde_cache (
    cache_id          VARCHAR(32) NOT NULL,
    cache_timestamp   BIGINT NOT NULL,
    cache_data        TEXT,

    PRIMARY KEY  (cache_id)
);
