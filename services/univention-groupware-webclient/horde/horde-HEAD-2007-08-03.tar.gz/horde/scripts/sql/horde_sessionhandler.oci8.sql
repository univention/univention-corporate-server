-- $Horde: horde/scripts/sql/horde_sessionhandler.oci8.sql,v 1.4 2006/12/13 04:58:19 chuck Exp $

CREATE TABLE horde_sessionhandler (
    session_id             VARCHAR2(32) NOT NULL,
    session_lastmodified   INT NOT NULL,
    session_data           BLOB,
--
    PRIMARY KEY (session_id)
);
