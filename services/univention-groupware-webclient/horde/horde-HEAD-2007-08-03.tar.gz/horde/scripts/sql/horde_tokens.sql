-- $Horde: horde/scripts/sql/horde_tokens.sql,v 1.4 2006/12/13 04:58:19 chuck Exp $

CREATE TABLE horde_tokens (
    token_address    VARCHAR(100) NOT NULL,
    token_id         VARCHAR(32) NOT NULL,
    token_timestamp  BIGINT NOT NULL,
--
    PRIMARY KEY (token_address, token_id)
);
