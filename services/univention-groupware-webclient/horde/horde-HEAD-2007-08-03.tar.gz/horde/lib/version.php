<?php define('HORDE_VERSION', '3.2-cvs') ?>
