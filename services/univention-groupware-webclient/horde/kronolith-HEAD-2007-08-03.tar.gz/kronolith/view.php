<?php
/**
 * $Horde: kronolith/view.php,v 1.8 2007/01/02 12:48:29 jan Exp $
 *
 * Copyright 2005-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 *
 * @author Chuck Hagenbuch <chuck@horde.org>
 */

@define('KRONOLITH_BASE', dirname(__FILE__));
require_once KRONOLITH_BASE . '/lib/base.php';

$view = Kronolith::getView(Util::getFormData('view'));
if ($view) {
    $print_view = false;
    Kronolith::tabs(strtolower(str_replace('kronolith_view_', '', String::lower(get_class($view)))));
    $view->html();
    echo '<div style="display:none" id="view_vars" view="' . htmlspecialchars(Util::getFormData('view')) . '" timestamp="' . Kronolith::currentTimestamp() . '" print="' . Util::addParameter($view->link(), 'print', 1) . '">';
}
