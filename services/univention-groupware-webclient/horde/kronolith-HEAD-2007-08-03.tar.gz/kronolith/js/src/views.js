var Views = {

    hash: {},
    keys: [],

    get: function(key)
    {
        return (typeof Views.hash[key] != 'undefined') ? Views.hash[key] : null;
    },

    push: function(key, val)
    {
        Views.hash[key] = val;
        Views.keys.push(key);
        if (Views.keys.length > 10) {
            prune = Views.keys.pop();
            Views.hash[prune] = null;
        }
    }

};

function ShowView(view, time, cache)
{
    if (typeof Ajax.Updater == 'undefined') {
        return true;
    }

    if (typeof cache == 'undefined') {
        cache = true;
    }

    // Build the request URL for later use, and as a hash key.
    var url = KronolithVar.view_url;
    var glue = (url.indexOf('?') == -1) ? '?' : '&';
    url += glue + 'view=' + encodeURIComponent(view);
    if (typeof time == 'object') {
        for (var name in time) {
            url += '&' + encodeURIComponent(name) + '=' + encodeURIComponent(time[name]);
        }
    } else {
        url += '&timestamp=' + encodeURIComponent(time);
    }

    // Look for cached views.
    if (Views.get(url)) {
        $('page').innerHTML = Views.get(url);
        _ShowView();
    } else {
        // Add the Loading ... notice.
        p = document.createElement('DIV');
        p.id = 'pageLoading';
        p.appendChild(document.createTextNode(KronolithText.loading));
        $('page').appendChild(p);
        Position.clone('page', 'pageLoading');
        new Effect.Opacity('pageLoading', { from: 0.0, to: 0.5 });

        // Update the page div.
        if (cache) {
            new Ajax.Updater('page', url, { onComplete: function() { Views.push(url, $('page').innerHTML); _ShowView(); } });
        } else {
            new Ajax.Updater('page', url, { onComplete: _ShowView });
        }
    }

    return false;
}

function _ShowView()
{
    if (typeof findStripedTables == 'function') {
        findStripedTables();
    }
    if (typeof ToolTips == 'object') {
        ToolTips.out();
        ToolTips.attachBehavior();
    }

    var titleDiv = $('view_title');
    if (titleDiv && titleDiv.firstChild && titleDiv.firstChild.nodeValue) {
        var title = KronolithVar.page_title + titleDiv.firstChild.nodeValue;
        try {
            document.title = title;
            if (parent.frames.horde_main) {
                parent.document.title = title;
            }
        } catch (e) {}
    }

    var viewVars = $('view_vars');
    if (viewVars) {
        kronolithView = viewVars.getAttribute('view');
        kronolithTimestamp = viewVars.getAttribute('timestamp');
        kronolithPrintLink = viewVars.getAttribute('print');
    }
}

var eventTabs = null;
function ShowTab(tab)
{
    if (eventTabs == null) {
        eventTabs = document.getElementsByClassName('tabset', $('page'))[0].childNodes[0];
    }

    var elts = eventTabs.childNodes;
    for (var i = 0; i < elts.length; i++) {
        var item = elts[i];
        if (item.tagName == 'LI') {
            if (item.id == 'tab' + tab) {
                Element.addClassName(item, 'activeTab');
                Element.show(item.id.substring(3));
            } else {
                Element.removeClassName(item, 'activeTab');
                Element.hide(item.id.substring(3));
            }
        }
    }

    return false;
}

/**
 * Javascript code for finding all tables with classname "striped" and
 * dynamically striping their row colors.
 */
function findStripedTables()
{
    if (!document.getElementsByTagName) {
        return;
    }
    tables = document.getElementsByTagName('table');
    for (var i = 0; i < tables.length; i++) {
        if (tables[i].className.indexOf('striped') != -1) {
            stripe(tables[i]);
        }
    }
}

function stripe(table)
{
    // The flag we'll use to keep track of whether the current row is
    // odd or even.
    var even = false;

    // Tables can have more than one tbody element; get all child
    // tbody tags and interate through them.
    var tbodies = table.childNodes;
    for (var c = 0; c < tbodies.length; c++) {
        if (tbodies[c].tagName == 'TBODY') {
            var trs = tbodies[c].childNodes;
            for (var i = 0; i < trs.length; i++) {
                if (trs[i].tagName == 'TR') {
                    trs[i].className = trs[i].className.replace(/ ?rowEven ?/, '').replace(/ ?rowOdd ?/, '');
                    if (trs[i].className) {
                        trs[i].className += ' ';
                    }
                    trs[i].className += even ? 'rowEven' : 'rowOdd';

                    // Flip from odd to even, or vice-versa.
                    even = !even;
                }
            }
        }
    }
}

Event.observe(window, 'load', findStripedTables);
