<?php

$block_name = _("Menu List");
$block_type = 'tree';

/**
 * $Horde: mnemo/lib/Block/tree_menu.php,v 1.1 2006/05/24 04:02:20 chuck Exp $
 *
 * @package Horde_Block
 */
class Horde_Block_mnemo_tree_menu extends Horde_Block {

    var $_app = 'mnemo';

    function _buildTree(&$tree, $indent = 0, $parent = null)
    {
        global $registry;

        $tree->addNode($parent . '__new',
                       $parent,
                       _("New Note"),
                       $indent + 1,
                       false,
                       array('icon' => 'add.png',
                             'icondir' => $registry->getImageDir(),
                             'url' => Horde::applicationUrl('memo.php?actionID=add_memo')));

        $tree->addNode($parent . '__search',
                       $parent,
                       _("Search"),
                       $indent + 1,
                       false,
                       array('icon' => 'search.png',
                             'icondir' => $registry->getImageDir('horde'),
                             'url' => Horde::applicationUrl('search.php')));
    }

}
