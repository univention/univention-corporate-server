var contactTabs = null;
function ShowTab(tab)
{
    if (contactTabs == null) {
        contactTabs = document.getElementsByClassName('tabset', $('page'))[0].childNodes[0];
    }

    $A(contactTabs.childNodes).each(function(item) {
        if (item.tagName == 'LI') {
            if (item.id == 'tab' + tab) {
                Element.addClassName(item, 'activeTab');
                Element.show(item.id.substring(3));
            } else {
                Element.removeClassName(item, 'activeTab');
                Element.hide(item.id.substring(3));
            }
        }
    });

    return false;
}
