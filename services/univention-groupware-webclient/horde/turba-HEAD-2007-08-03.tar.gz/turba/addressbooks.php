<?php
/**
 * Turba script to manage the user's address book shares.
 *
 * Copyright 2005-2007 The Horde Project (http://www.horde.org/)
 *
 * $Horde: turba/addressbooks.php,v 1.32 2007/08/01 10:43:29 jan Exp $
 *
 * See the enclosed file LICENSE for license information (ASL).  If you did
 * did not receive this file, see http://www.horde.org/licenses/asl.php.
 *
 * @author  Michael J. Rubinsky <mrubinsk@horde.org>
 * @package Turba
 */

/**
 * Update a Turba share.
 *
 * @param string $name   The name of the share to update.
 * @param array $params  The params to update.
 *
 * @return mixed  The display name of the updated share or PEAR_Error.
 */
function _updateShare($name, $params)
{
    $share = &$GLOBALS['turba_shares']->getShare($name);
    if (is_a($share, 'PEAR_Error')) {
        return $share;
    }
    foreach ($params as $key => $value) {
        $share->set($key, $value);
    }
    $result = $share->save();
    if (is_a($result, 'PEAR_Error')) {
        return $result;
    } else {
        return $share->get('name');
    }
}

/**
 * Remove a Turba share.
 *
 * @TODO Remove share from 'addressbooks' pref
 *
 * @param string $name  The name of the share to remove.
 *
 * @return mixed  The display name of the deleted share or PEAR_Error.
 */
function _deleteShare($name)
{
    $share = &$GLOBALS['turba_shares']->getShare($name);
    if (is_a($share, 'PEAR_Error')) {
        return $share;
    }

    /* Enforce the requirement that only the share's owner can delete it. */
    if ($share->get('owner') != Auth::getAuth()) {
        return PEAR::raiseError(_("You do not have permissions to delete this source."));
    }
    $name = $share->get('name');
    $result = $GLOBALS['turba_shares']->removeShare($share);
    if (is_a($result, 'PEAR_Error')) {
        return $result;
    } else {
        return $name;
    }
}

@define('TURBA_BASE', dirname(__FILE__));
require_once TURBA_BASE . '/lib/base.php';

// Exit if this isn't an authenticated user, or if there's no source
// configured for shares.
if (!Auth::getAuth() || empty($_SESSION['turba']['has_share'])) {
    require TURBA_BASE . '/'
        . ($browse_source_count ? basename($prefs->getValue('initial_page')) : 'search.php');
    exit;
}

// Figure out why we are here.
$actionID = Util::getFormData('actionID');
switch ($actionID) {
case 'add':
    // Need a clean cfgSources array
    include TURBA_BASE . '/config/sources.php';

    $params = array(
        'params' => array('source' => $conf['shares']['source']),
        'name' => Util::getFormData('sharename'),
    );
    $driver = &Turba_Driver::singleton($cfgSources[$conf['shares']['source']]);
    if (!is_a($driver, 'PEAR_Error')) {
        $share = &$driver->createShare(md5(mt_rand()), $params);
    } else {
        $notification->push(sprintf(_("There was an error creating this address book: %s"), $driver->getMessage()), 'horde.error');
        header('Location: ' . Horde::applicationUrl('addressbooks.php', true));
        exit;
    }

    if (is_a($share, 'PEAR_Error')) {
        $notification->push(sprintf(_("There was an error creating this address book: %s"), $share->getMessage()), 'horde.error');
    } else {
        $notification->push(sprintf(_("The address book \"%s\" was created successfully."), $share->get('name')), 'horde.success');
        Turba::addSourceFromShare($share);
    }

    header('Location: ' . Horde::applicationUrl('addressbooks.php', true));
    exit;

case 'delete':
    $driver = &Turba_Driver::singleton(Util::getFormData('deleteshare'));
    if (is_a($driver, 'PEAR_Error')) {
        $notification->push(sprintf(_("There was an error removing this address book: %s"), $driver->getMessage()), 'horde.error');
        break;
    }

    // We have a Turba_Driver, try to delete the address book.
    $result = $driver->deleteAll();
    if (is_a($result, 'PEAR_Error')) {
        $notification->push(sprintf(_("There was an error removing this address book: %s"), $result->getMessage()), 'horde.error');
        break;
    }

    // Address book successfully deleted from backend, remove the
    // share.
    $result = _deleteShare(Util::getFormData('deleteshare'));
    if (is_a($result, 'PEAR_Error')) {
        $notification->push(sprintf(_("There was an error removing this address book: %s"), $result->getMessage()), 'horde.error');
    } else {
        $notification->push(sprintf(_("The address book \"%s\" was removed successfully."), $result), 'horde.success');
    }

    if (isset($_SESSION['turba']['source']) && $_SESSION['turba']['source'] == Util::getFormData('deleteshare')) {
        unset($_SESSION['turba']['source']);
    }

    header('Location: ' . Horde::applicationUrl('addressbooks.php', true));
    exit;

case 'update':
    // Updating some info on an existing share.
    $shareName = Util::getFormData('editshare');
    $params = array(
        'name' => Util::getFormData('sharetitle'),
        'desc' => Util::getFormData('desc')
    );
    $result = _updateShare($shareName, $params);
    if (is_a($result, 'PEAR_Error')) {
        $notification->push(sprintf(_("There was an error updating this address book: %s"), $result->getMessage()), 'horde.error');
    } else {
        $notification->push(sprintf(_("The address book \"%s\" was successfully updated."), $result), 'horde.success');
    }

    header('Location: ' . Horde::applicationUrl('addressbooks.php', true));
    exit;
}

// Get all the info we will need to display the page.
$mySources = array();
$myRemovable = array();

// Get the shares owned by the current user, and figure out what we will
// display the share name as to the user.
$shares = Turba::listShares(true);
$me = Auth::getAuth();
foreach ($shares as $share_id => $share) {
    $mySources[$share_id] = $share->get('name');
    if ($share->get('owner') == $me) {
        $myRemovable[] = $share_id;
    }
}

Horde::addScriptFile('popup.js', 'horde', true);
$title = _("My Address Books");
require TURBA_TEMPLATES . '/common-header.inc';
require TURBA_TEMPLATES . '/menu.inc';
require TURBA_TEMPLATES . '/addressbooks.inc';
require $registry->get('templates', 'horde') . '/common-footer.inc';
