<?php
/**
 * $Horde: turba/browse.php,v 1.124 2007/08/01 10:32:32 jan Exp $
 *
 * Copyright 2000-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (ASL).  If you did
 * did not receive this file, see http://www.horde.org/licenses/asl.php.
 *
 * @author  Chuck Hagenbuch <chuck@horde.org>
 * @package Turba
 */

@define('TURBA_BASE', dirname(__FILE__));
require_once TURBA_BASE . '/lib/base.php';
require_once 'Horde/Variables.php';
require_once TURBA_BASE . '/lib/Views/Browse.php';

$params = array('vars' => Variables::getDefaultVariables(),
                'prefs' => &$prefs,
                'notification' => &$notification,
                'registry' => &$registry,
                'browse_source_count' => $browse_source_count,
                'browse_source_options' => $browse_source_options,
                'copymove_source_options' => $copymove_source_options,
                'copymoveSources' => $copymoveSources,
                'addSources' => $addSources,
                'cfgSources' => $cfgSources,
                'attributes' => $attributes,
                'turba_shares' => &$turba_shares,
                'conf' => $conf,
                'source' => $default_source,
                'browser' => $browser);
$browse = new Turba_View_Browse($params);
$browse->run();
