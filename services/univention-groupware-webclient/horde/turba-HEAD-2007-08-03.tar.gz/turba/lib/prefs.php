<?php
/**
 * $Horde: turba/lib/prefs.php,v 1.14 2007/08/01 04:11:08 chuck Exp $
 *
 * Copyright 2001-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (ASL).  If you
 * did not receive this file, see http://www.horde.org/licenses/asl.php.
 */

function handle_columnselect($updated)
{
    $columns = Util::getFormData('columns');
    if (!empty($columns)) {
        $GLOBALS['prefs']->setValue('columns', $columns);
        return true;
    }

    return false;
}

function handle_addressbookselect($updated)
{
    $addressbooks = Util::getFormData('addressbooks');
    if (!empty($addressbooks)) {
        $GLOBALS['prefs']->setValue('addressbooks', $addressbooks);
        return true;
    }

    return false;
}

/* Assign variables for select lists. */
if (!$prefs->isLocked('default_dir')) {
    $default_dir_options = array();
    foreach ($cfgSources as $key => $info) {
        $default_dir_options[$key] = $info['title'];
    }
}
