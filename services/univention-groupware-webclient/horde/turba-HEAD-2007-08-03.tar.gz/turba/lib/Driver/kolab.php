<?php
/**
 * @package Turba
 *
 * $Horde: turba/lib/Driver/kolab.php,v 1.27 2007/06/19 09:50:30 wrobel Exp $
 */

/** Kolab support class. */
require_once 'Horde/Kolab.php';

/**
 * Horde Turba driver for the Kolab IMAP Server.
 * Copyright 2004-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (ASL).  If you
 * did not receive this file, see http://www.horde.org/licenses/asl.php.
 *
 * @author  Thomas Jarosch <thomas.jarosch@intra2net.com>
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @author  Stuart Binge <omicron@mighty.co.za>
 * @package Turba
 */
class Turba_Driver_kolab extends Turba_Driver {

    /**
     * Our Kolab server connection.
     *
     * @var Kolab
     */
    var $_kolab = null;

    /**
     * The wrapper to decide between the Kolab implementation
     *
     * @var Turba_Driver_kolab_wrapper
     */
    var $_wrapper = null;

    var $_capabilities = array(
        'delete_addressbook' => true,
        'delete_all' => true,
    );

    /**
     * Attempts to open a Kolab Groupware folder.
     *
     * @return boolean  True on success, PEAR_Error on failure.
     */
    function _init()
    {
        $this->_kolab = &new Kolab();
        if (empty($this->_kolab->version)) {
            $wrapper = "Turba_Driver_kolab_wrapper_old";
        } else {
            $wrapper = "Turba_Driver_kolab_wrapper_new";
        }

        $this->_wrapper = &new $wrapper($this->name, $this->_kolab);
    }

    /**
     * Searches the Kolab message store with the given criteria and returns a
     * filtered list of results. If the criteria parameter is an empty
     * array, all records will be returned.
     *
     * @param $criteria      Array containing the search criteria.
     * @param $fields        List of fields to return.
     *
     * @return               Hash containing the search results.
     */
    function _search($criteria, $fields)
    {
        return $this->_wrapper->_search($criteria, $fields);
    }

    /**
     * Read the given data from the Kolab message store and returns the
     * result's fields.
     *
     * @param $criteria      Search criteria.
     * @param $id            Data identifier.
     * @param $fields        List of fields to return.
     *
     * @return               Hash containing the search results.
     */
    function _read($criteria, $id_list, $fields)
    {
        return $this->_wrapper->_read($criteria, $id_list, $fields);
    }

    /**
     * Adds the specified object to the Kolab message store.
     */
    function _add($attributes)
    {
        return $this->_wrapper->_add($attributes);
    }

    /**
     * Removes the specified object from the Kolab message store.
     */
    function _delete($object_key, $object_id)
    {
        return $this->_wrapper->_delete($object_key, $object_id);
    }

    /**
     * Deletes all contacts from a specific address book.
     *
     * @return boolean  True if the operation worked.
     */
    function _deleteAll($sourceName = null)
    {
        return $this->_wrapper->_deleteAll($sourceName);
    }

    /**
     * Updates an existing object in the Kolab message store.
     *
     * @return string  The object id, possibly updated.
     */
    function _save($object_key, $object_id, $attributes)
    {
        return $this->_wrapper->_save($object_key, $object_id, $attributes);
    }

    /**
     * Create an object key for a new object.
     *
     * @param array $attributes  The attributes (in driver keys) of the
     *                           object being added.
     *
     * @return string  A unique ID for the new object.
     */
    function _makeKey($attributes)
    {
        return $this->generateUID();
    }

    /**
     * Create an object key for a new object.
     *
     * @return string  A unique ID for the new object.
     */
    function generateUID()
    {
        if (method_exists($this->_wrapper, 'generateUID')) {
            return $this->_wrapper->generateUID();
        } else {
            return parent::generateUID();
        }
    }

}

/**
 * Horde Turba wrapper to distinguish between both Kolab driver implementations.
 *
 * $Horde: turba/lib/Driver/kolab.php,v 1.27 2007/06/19 09:50:30 wrobel Exp $
 *
 * Copyright 2004-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (ASL). If you
 * did not receive this file, see http://www.horde.org/licenses/asl.php.
 *
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @package Turba
 */

class Turba_Driver_kolab_wrapper {

    /**
     * Indicates if the wrapper has connected or not
     *
     * @var boolean
     */
    var $_connected = false;

    /**
     * String containing the current addressbook name.
     *
     * @var string
     */
    var $_addressbook = '';

    /**
     * Our Kolab server connection.
     *
     * @var Kolab
     */
    var $_kolab = null;

    /**
     * Constructor
     *
     * @param string      $addressbook  The addressbook to load.
     * @param Horde_Kolab $kolab        The Kolab connection object
     */
    function Turba_Driver_kolab_wrapper($addressbook, &$kolab)
    {
        if ($addressbook[0] == '_') {
            $addressbook = substr($addressbook, 1);
        }
        $this->_addressbook = $addressbook;
        $this->_kolab = &$kolab;
    }

    /**
     * Connect to the Kolab backend
     *
     * @param int    $loader         The version of the XML
     *                               loader
     *
     * @return mixed True on success, a PEAR error otherwise
     */
    function connect($loader = 0)
    {
        if ($this->_connected) {
            return true;
        }

        $result = $this->_kolab->open($this->_addressbook, $loader);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        $this->_connected = true;

        return true;
    }
}

/**
 * Horde Turba driver for the Kolab IMAP Server.
 * Copyright 2004-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (ASL).  If you
 * did not receive this file, see http://www.horde.org/licenses/asl.php.
 *
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @author  Stuart Binge <omicron@mighty.co.za>
 * @package Turba
 */
class Turba_Driver_kolab_wrapper_old extends Turba_Driver_kolab_wrapper {

    function _buildContact()
    {
        $k = &$this->_kolab;

        $contact = array(
            'uid' => $k->getUID(),
            'owner' => Auth::getAuth(),
            'job-title' => $k->getStr('job-title'),
            'organization' => $k->getStr('organization'),
            'body' => $k->getStr('body'),
            'web-page' => $k->getStr('web-page'),
            'nick-name' => $k->getStr('nick-name'),
        );

        $name = &$k->getRootElem('name');
        $contact['full-name'] = $k->getElemStr($name, 'full-name');
        $contact['given-name'] = $k->getElemStr($name, 'given-name');
        $contact['last-name'] = $k->getElemStr($name, 'last-name');

        $email = &$k->getRootElem('email');
        $contact['smtp-address'] = $k->getElemStr($email, 'smtp-address');

        $phones = &$k->getAllRootElems('phone');
        for ($i = 0, $j = count($phones); $i < $j; $i++) {
            $phone = &$phones[$i];
            $type = $k->getElemStr($phone, 'type');

            switch ($type) {
            case 'home1':
                $contact['home1'] = $k->getElemStr($phone, 'number');
                break;

            case 'business1':
                $contact['business1'] = $k->getElemStr($phone, 'number');
                break;

            case 'mobile':
                $contact['mobile'] = $k->getElemStr($phone, 'number');
                break;

            case 'businessfax':
                $contact['businessfax'] = $k->getElemStr($phone, 'number');
                break;
            }
        }

        $addresses = &$k->getAllRootElems('address');
        for ($i = 0, $j = count($addresses); $i < $j; $i++) {
            $address = &$addresses[$i];
            $type = $k->getElemStr($address, 'type');

            switch ($type) {
            case 'home':
                $contact['home-street'] = $k->getElemStr($address, 'street');
                $contact['home-locality'] = $k->getElemStr($address, 'locality');
                $contact['home-region'] = $k->getElemStr($address, 'region');
                $contact['home-postal-code'] = $k->getElemStr($address, 'postal-code');
                $contact['home-country'] = $k->getElemStr($address, 'country');
                break;

            case 'business':
                $contact['business-street'] = $k->getElemStr($address, 'street');
                $contact['business-locality'] = $k->getElemStr($address, 'locality');
                $contact['business-region'] = $k->getElemStr($address, 'region');
                $contact['business-postal-code'] = $k->getElemStr($address, 'postal-code');
                $contact['business-country'] = $k->getElemStr($address, 'country');
                break;
            }
        }

        return $contact;
    }

    function _setPhone($type, &$phone, $attributes)
    {
        if (empty($attributes[$type])) {
            $this->_kolab->delRootElem($phone);
        } else {
            if ($phone === false) {
                $phone = &$this->_kolab->appendRootElem('phone');
                $this->_kolab->setElemStr($phone, 'type', $type);
            }
            $this->_kolab->setElemStr($phone, 'number', $attributes[$type]);
        }
    }

    function _setAddress($type, &$address, $attributes)
    {
        if (empty($attributes["$type-street"]) && empty($attributes["$type-locality"]) &&
            empty($attributes["$type-region"]) && empty($attributes["$type-postal-code"]) &&
            empty($attributes["$type-country"])) {
            $this->_kolab->delRootElem($address);
        } else {
            if ($address === false) {
                $address = &$this->_kolab->appendRootElem('address');
                $this->_kolab->setElemStr($address, 'type', $type);
            }
            $this->_kolab->setElemStr($address, 'street', $attributes["$type-street"]);
            $this->_kolab->setElemStr($address, 'locality', $attributes["$type-locality"]);
            $this->_kolab->setElemStr($address, 'region', $attributes["$type-region"]);
            $this->_kolab->setElemStr($address, 'postal-code', $attributes["$type-postal-code"]);
            $this->_kolab->setElemStr($address, 'country', $attributes["$type-country"]);
        }
    }

    function _createContact(&$xml, $attributes)
    {
        $k = &$this->_kolab;

        $name = &$k->initRootElem('name');
        if (!empty($attributes['full-name'])) {
            $k->setElemStr($name, 'full-name', $attributes['full-name']);
        }
        if (!empty($attributes['given-name'])) {
            $k->setElemStr($name, 'given-name', $attributes['given-name']);
        }
        if (!empty($attributes['last-name'])) {
            $k->setElemStr($name, 'last-name', $attributes['last-name']);
        }

        $email = &$k->initRootElem('email');
        $k->setElemStr($email, 'display-name', $attributes['full-name']);
        $k->setElemStr($email, 'smtp-address', $attributes['smtp-address']);

        if (!empty($attributes['job-title'])) {
            $k->setStr('job-title', $attributes['job-title']);
        }
        if (!empty($attributes['organization'])) {
            $k->setStr('organization', $attributes['organization']);
        }
        if (!empty($attributes['body'])) {
            $k->setStr('body', $attributes['body']);
        }
        if (!empty($attributes['web-page'])) {
            $k->setStr('web-page', $attributes['web-page']);
        }
        if (!empty($attributes['nick-name'])) {
            $k->setStr('nick-name', $attributes['nick-name']);
        }

        // Phones
        $phones = &$k->getAllRootElems('phone');
        $home = false;
        $bus = false;
        $mob = false;
        $fax = false;
        for ($i = 0, $j = count($phones); $i < $j; $i++) {
            $phone = &$phones[$i];
            $type = $k->getElemStr($phone, 'type');

            switch ($type) {
            case 'home1':
                $home = &$phone;
                break;

            case 'business1':
                $bus = &$phone;
                break;

            case 'mobile':
                $mob = &$phone;
                break;

            case 'businessfax':
                $fax = &$phone;
                break;
            }
        }

        $this->_setPhone('home1', $home, $attributes);
        $this->_setPhone('business1', $bus, $attributes);
        $this->_setPhone('mobile', $mob, $attributes);
        $this->_setPhone('businessfax', $fax, $attributes);

        // Addresses
        $home = false;
        $bus = false;
        $addresses = &$k->getAllRootElems('address');
        for ($i = 0, $j = count($addresses); $i < $j; $i++) {
            $address = &$addresses[$i];
            $type = $k->getElemStr($address, 'type');

            switch ($type) {
            case 'home':
                $home = &$address;
                break;

            case 'business':
                $bus = &$address;
                break;
            }
        }

        $this->_setAddress('home', $home, $attributes);
        $this->_setAddress('business', $bus, $attributes);
    }

    /**
     * Searches the Kolab message store with the given criteria and returns a
     * filtered list of results. If the criteria parameter is an empty
     * array, all records will be returned.
     *
     * @param $criteria      Array containing the search criteria.
     * @param $fields        List of fields to return.
     *
     * @return               Hash containing the search results.
     */
    function _search($criteria, $fields)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if (!is_callable(array($this->_kolab, 'listObjectsInFolder'))) {
            Horde::logMessage('The Framework Kolab package must be upgraded', __FILE__, __LINE__, PEAR_LOG_ERR);
            return PEAR::raiseError(_("Unable to search."));
        }

        $results = array();
        $folders = $this->_kolab->listFolders();
        foreach ($folders as $folder) {
            if ($folder[1] != 'contact') {
                continue;
            }

            $msg_list = $this->_kolab->listObjectsInFolder($folder[0]);
            if (is_a($msg_list, 'PEAR_Error') || empty($msg_list)) {
                return $msg_list;
            }

            foreach ($msg_list as $msg) {
                $result = $this->_kolab->loadObject($msg, true);
                if (is_a($result, 'PEAR_Error')) {
                    return $result;
                }

                $contact = $this->_buildContact();

                if ($this->_matchCriteria($contact, $criteria) == false) {
                    continue;
                }

                $card = array();
                foreach ($fields as $field) {
                    $card[$field] = (isset($contact[$field]) ? $contact[$field] : '');
                }

                $results[] = $card;
            }
        }

        return $results;
    }

    /**
     * Read the given data from the Kolab message store and returns the
     * result's fields.
     *
     * @param $criteria      Search criteria.
     * @param $id            Data identifier.
     * @param $fields        List of fields to return.
     *
     * @return               Hash containing the search results.
     */
    function _read($criteria, $id_list, $fields)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if ($criteria != 'uid') {
            return array();
        }

        if (!is_array($id_list)) {
            $id_list = array($id_list);
        }

        $results = array();
        foreach ($id_list as $id) {
            $result = $this->_kolab->loadObject($id);
            if (is_a($result, 'PEAR_Error')) {
                return $result;
            }

            $contact = $this->_buildContact($result);
            $card = array();
            foreach ($fields as $field) {
                $card[$field] = (isset($contact[$field]) ? $contact[$field] : '');
            }

            $results[] = $card;
        }

        return $results;
    }

    /**
     * Adds the specified object to the Kolab message store.
     */
    function _add($attributes)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        $xml = &$this->_kolab->newObject($attributes['uid']);
        if (is_a($xml, 'PEAR_Error')) {
            return $xml;
        }

        $this->_createContact($xml, $attributes);

        return $this->_kolab->saveObject();
    }

    /**
     * Removes the specified object from the Kolab message store.
     */
    function _delete($object_key, $object_id)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if ($object_key != 'uid') {
            return false;
        }

        return $this->_kolab->removeObjects($object_id);
    }

    /**
     * Deletes all contacts from a specific address book.
     *
     * @return boolean  True if the operation worked.
     */
    function _deleteAll($sourceName = null)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if ($sourceName != null) {
            Horde::logMessage('deleteAll only working for current share. Called for $sourceName', __FILE__, __LINE__, PEAR_LOG_ERR);
            return PEAR::raiseError(sprintf(_("Cannot delete all address book entries for %s"), $sourceName));
        }

        return $this->_kolab->removeAllObjects();
    }

    /**
     * Updates an existing object in the Kolab message store.
     *
     * @return string  The object id, possibly updated.
     */
    function _save($object_key, $object_id, $attributes)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if ($object_key != 'uid') {
            return PEAR::raiseError('key must be uid');
        }

        $xml = &$this->_kolab->loadObject($object_id);
        if (is_a($xml, 'PEAR_Error')) {
            return $xml;
        }

        $this->_createContact($xml, $attributes);

        $result = $this->_kolab->saveObject();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        return $object_id;
    }

    /**
     * Checks whether a contact matches a given criteria.
     *
     * @param array $contact       The contact.
     * @param array $criteria      The criteria.
     *
     * @return boolean  Wether the passed string corresponding to $criteria.
     *
     * @access private
     */
    function _matchCriteria($contact, $criteria)
    {
        $values = array_values($criteria);
        $values = $values[0];
        $ok = true;

        for ($current = 0; $current < count($values); ++$current) {
            $temp = $values[$current];

            while (!empty($temp) && !array_key_exists('field', $temp)) {
                $temp = array_values($temp);
                $temp = $temp[0];
            }

            if (empty($temp)) {
                continue;
            }

            $searchkey = $temp['field'];
            $searchval = $temp['test'];

            if (stristr($contact[$searchkey], $searchval) == false) {
                $ok = $ok && false;
            } else {
                $ok = $ok && true;
            }
        }

        return $ok;
    }
}

/**
 * New Horde Turba driver for the Kolab IMAP Server.
 * Copyright 2004-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file LICENSE for license information (ASL).  If you
 * did not receive this file, see http://www.horde.org/licenses/asl.php.
 *
 * @author  Gunnar Wrobel <wrobel@pardus.de>
 * @author  Thomas Jarosch <thomas.jarosch@intra2net.com>
 * @package Turba
 */
class Turba_Driver_kolab_wrapper_new extends Turba_Driver_kolab_wrapper {

    /**
     * Shortcut to the imap connection
     *
     * @var Kolab_IMAP
     */
    var $_store = null;

    /**
     * Connect to the Kolab backend
     *
     * @return mixed True on success, a PEAR error otherwise
     */
    function connect()
    {
        $result = parent::connect(1);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        $this->_store = &$this->_kolab->_storage;

        return true;
    }

    /**
     * Searches the Kolab message store with the given criteria and returns a
     * filtered list of results. If the criteria parameter is an empty
     * array, all records will be returned.
     *
     * @param $criteria      Array containing the search criteria.
     * @param $fields        List of fields to return.
     *
     * @return               Hash containing the search results.
     */
    function _search($criteria, $fields)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        $entries = $this->_store->getObjects();

        // keep only entries matching criteria
        if (count($criteria)) {
            $new_entries = array();

            foreach($entries as $entry) {
                $keep_entry = false;

                foreach ($criteria as $key => $tests) {
                    if ($key == 'AND' || $key == 'OR') {
                        $all_matched = true;

                        foreach ($tests as $test) {
                            $field = $test['field'];
                            $needle = $test['test'];

                            if (empty($needle)) {
                                $keep_entry = true;
                            } elseif (stristr($entry[$field], $needle) !== false) {
                                $keep_entry = true;
                            } else {
                                $all_matched = false;
                            }
                        }
                    }

                    if ($key == 'AND' && !$all_matched) {
                        $keep_entry = false;
                    }
                }

                if ($keep_entry) {
                    $new_entries[] = $entry;
                }
            }

            $entries = $new_entries;
        }

        return $entries;
    }

    /**
     * Read the given data from the Kolab message store and returns the
     * result's fields.
     *
     * @param $criteria      Search criteria.
     * @param $ids           Data identifiers
     * @param $fields        List of fields to return.
     *
     * @return               Hash containing the search results.
     */
    function _read($criteria, $ids, $fields)
    {
        //FIXME: What about the criteria?
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        $results = array();

        if (!is_array($ids)) {
            $ids = array($ids);
        }

        foreach ($ids as $id) {
            if ($this->_store->ObjectUidExists($id)) {
                $results[] = $this->_store->getObject($id);
            }
        }

        return $results;
    }

    /**
     * Adds the specified object to the Kolab message store.
     */
    function _add($attributes)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        return $this->_store->save($attributes, null);
    }

    /**
     * Updates an existing object in the Kolab message store.
     *
     * @return string  The object id, possibly updated.
     */
    function _save($object_key, $object_id, $attributes)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if ($object_key != 'uid') {
            return PEAR::raiseError(sprintf(_("Key for saving must be a UID not %s!"), $object_key));
        }

        $result = $this->_store->save($attributes, $object_id);
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        return $object_id;
    }

    /**
     * Removes the specified object from the Kolab message store.
     */
    function _delete($object_key, $object_id)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if ($object_key != 'uid') {
            return PEAR::raiseError(sprintf(_("Key for saving must be a UID not %s!"), $object_key));
        }

        return $this->_store->delete($object_id);
    }

    /**
     * Deletes all contacts from a specific address book.
     *
     * @return boolean  True if the operation worked.
     */
    function _deleteAll($sourceName = null)
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        if ($sourceName != null) {
            Horde::logMessage('deleteAll only working for current share. Called for $sourceName', __FILE__, __LINE__, PEAR_LOG_ERR);
            return PEAR::raiseError(sprintf(_("Cannot delete all address book entries for %s"), $sourceName));
        }

        return $this->_store->deleteAll();
    }

    /**
     * Create an object key for a new object.
     *
     * @return string  A unique ID for the new object.
     */
    function generateUID()
    {
        $result = $this->connect();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        return $this->_store->generateUID();
    }
}
