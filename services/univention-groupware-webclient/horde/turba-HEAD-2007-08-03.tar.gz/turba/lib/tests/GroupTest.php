<?php

require_once dirname(__FILE__) . '/TestBase.php';

/**
 * $Horde: turba/lib/tests/GroupTest.php,v 1.1 2007/06/02 23:15:15 chuck Exp $
 *
 * @author  Jason M. Felice <jfelice@cronosys.com>
 * @package Turba
 * @subpackage UnitTests
 */
class Turba_GroupTest extends Turba_TestBase {

    var $group;

    function setUp()
    {
        parent::setUp();
        $this->setUpDatabase();

        $driver = $this->getDriver();
        $this->group = $driver->getObject('fff');
        $this->assertOk($this->group);
    }

    function test_listMembers_returns_objects_sorted_according_to_parameters()
    {
        $this->assertSortsList(array($this->group, 'listMembers'));
    }

}
