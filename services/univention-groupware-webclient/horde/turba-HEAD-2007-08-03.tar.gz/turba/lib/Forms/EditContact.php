<?php
/**
 * @package Turba
 *
 * $Horde: turba/lib/Forms/EditContact.php,v 1.5 2007/07/29 22:44:01 jan Exp $
 */

/** Turba_ContactForm */
require_once dirname(__FILE__) . '/Contact.php';

/**
 * @package Turba
 */
class Turba_EditContactForm extends Turba_ContactForm {

    var $_source;
    var $_contact;

    function Turba_EditContactForm(&$vars, &$contact)
    {
        global $conf;

        parent::Horde_Form($vars, '', 'Turba_View_EditContact');
        $this->_contact = &$contact;

        $this->setButtons(_("Save"), _("Undo Changes"));
        $this->addHidden('', 'url', 'text', false);
        $this->addHidden('', 'source', 'text', true);
        $this->addHidden('', 'key', 'text', false);

        parent::_addFields($this->_contact);

        if ($conf['documents']['type'] != 'none') {
            $this->addVariable(_("Add file"), 'vfs', 'file', false);
        }

        $object_values = $vars->get('object');
        $object_keys = array_keys($contact->attributes);
        foreach ($object_keys as $info_key) {
            if (!isset($object_values[$info_key])) {
                $object_values[$info_key] = $contact->getValue($info_key);
            }
        }
        $vars->set('object', $object_values);
        $vars->set('source', $contact->getSource());
    }

    function getSource()
    {
        return $this->_source;
    }

    function execute()
    {
        global $conf, $notification;

        if (!$this->validate($this->_vars)) {
            return PEAR::raiseError('Invalid');
        }

        /* Form valid, save data. */
        $this->getInfo($this->_vars, $info);

        /* Update the contact. */
        foreach ($info['object'] as $info_key => $info_val) {
            if ($info_key != '__key') {
                $this->_contact->setValue($info_key, $info_val);
            }
        }

        $result = $this->_contact->store();
        if (!is_a($result, 'PEAR_Error')) {
            if ($conf['documents']['type'] != 'none' && isset($info['vfs'])) {
                $result = $this->_contact->addFile($info['vfs']);
                if (is_a($result, 'PEAR_Error')) {
                    $notification->push(sprintf(_("\"%s\" updated, but saving the uploaded file failed: %s"), $this->_contact->getValue('name'), $result->getMessage()), 'horde.warning');
                } else {
                    $notification->push(sprintf(_("\"%s\" updated."), $this->_contact->getValue('name')), 'horde.success');
                }
            } else {
                $notification->push(sprintf(_("\"%s\" updated."), $this->_contact->getValue('name')), 'horde.success');
            }
            return true;
        } else {
            Horde::logMessage($result, __FILE__, __LINE__, PEAR_LOG_ERR);
            $notification->push(_("There was an error saving the contact. Contact your system administrator for further help."), 'horde.error');
            return $result;
        }
    }

}

/**
 * @package Turba
 */
class Turba_EditContactGroupForm extends Turba_EditContactForm {

    function Turba_EditContactGroupForm(&$vars, &$contact)
    {
        $this->addHidden('', 'objectkeys', 'text', false);
        $this->addHidden('', 'original_source', 'text', false);
        $this->addHidden('', 'actionID', 'text', false);

        parent::Turba_EditContactForm($vars, $contact);
        $vars->set('actionID', 'groupedit');

        $objectkeys = $vars->get('objectkeys');
        $source = $vars->get('source');
        $key = $vars->get('key');
        if ($source . ':' . $key == $objectkeys[0]) {
            /* First contact */
            $this->setButtons(_("Next"), _("Undo Changes"));
        } elseif ($source . ':' . $key == $objectkeys[count($objectkeys) - 1]) {
            /* Last contact */
            $this->setButtons(_("Previous"), _("Undo Changes"));
        } else {
            /* In between */
            $this->setButtons(_("Previous"), _("Undo Changes"));
            $this->appendButtons(_("Next"));
        }
        $this->appendButtons(_("Finish"));
    }

    function renderActive($renderer, &$vars, $action, $method)
    {
        parent::renderActive($renderer, $vars, $action, $method);

        /* Read the columns to display from the preferences. */
        $source = $vars->get('source');
        $sources = Turba::getColumns();
        $columns = isset($sources[$source]) ? $sources[$source] : array();

        require_once TURBA_BASE . '/lib/List.php';
        require_once TURBA_BASE . '/lib/ListView.php';
        $results = new Turba_List($vars->get('objectkeys'));
        $listView = new Turba_ListView($results, array('Group' => true), $columns);
        echo '<br />' . $listView->getPage($numDisplayed);
    }

    function execute()
    {
        $result = parent::execute();
        if (is_a($result, 'PEAR_Error')) {
            return $result;
        }

        $next_page = Horde::applicationUrl('edit.php', true);
        $next_page = Util::addParameter($next_page,
                                        array('source' => $source,
                                              'original_source' => $original_source,
                                              'objectkeys' => $objectkeys,
                                              'url' => $vars->get('url'),
                                              'actionID' => 'groupedit'),
                                        null, false);
        $objectkey = array_search($source . ':' . $key, $objectkeys);

        if ($vars->get('submitbutton') == _("Finish")) {
            $next_page = Horde::url('browse.php', true);
            if ($original_source == '**search') {
                $next_page = Util::addParameter($next_page, 'key', $original_source, false);
            } else {
                $next_page = Util::addParameter($next_page, 'source', $original_source, false);
            }
        } elseif ($vars->get('submitbutton') == _("Previous") && $source . ':' . $key != $objectkeys[0]) {
            /* Previous contact */
            $form->setButtons(_("Undo Changes"));
            list(, $previous_key) = explode(':', $objectkeys[$objectkey - 1]);
            $next_page = Util::addParameter($next_page, 'key', $previous_key, false);
            if ($form->getOpenSection()) {
                $next_page = Util::addParameter($next_page, '__formOpenSection', $form->getOpenSection(), false);
            }
        } elseif ($vars->get('submitbutton') == _("Next") &&
                  $source . ':' . $key != $objectkeys[count($objectkeys) - 1]) {
            /* Next contact */
            list(, $next_key) = explode(':', $objectkeys[$objectkey + 1]);
            $next_page = Util::addParameter($next_page, 'key', $next_key, false);
            if ($form->getOpenSection()) {
                $next_page = Util::addParameter($next_page, '__formOpenSection', $form->getOpenSection(), false);
            }
        }

        header('Location: ' . $next_page);
        exit;
    }

}
