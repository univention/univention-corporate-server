/**
 * IMP Popup JavaScript.
 *
 * Provides the javascript to toggle address blocks.
 * This file should be included via Horde::addScriptFile().
 *
 * $Horde: imp/js/src/addressesBlocks.js,v 1.2 2006/12/30 20:24:38 jan Exp $
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */
function toggleAddressesBlock(field, count)
{
    var b = $('ab_' + field);

    $('at_' + field).firstChild.innerHTML = (Element.visible(b)) ?
        '[' + ImpText.toggle_show + ' - ' + count + ' ' + ImpText.recipients + ']' :
        '[' + ImpText.toggle_hide + ']';

    Element.toggle(b);
}
