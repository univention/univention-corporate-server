/**
 * Provides the javascript for the message.php script
 *
 * $Horde: imp/js/src/message.js,v 1.6 2007/03/13 07:22:03 slusarz Exp $
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

function arrowHandler(e, key)
{
    if (e.altKey || e.shiftKey || e.ctrlKey) {
        return false;
    }

    var loc;
    if (key == Event.KEY_LEFT && $('prev')) {
        loc = $('prev').href;
    } else if (key == Event.KEY_RIGHT && $('next')) {
        loc = $('next').href;
    }

    if (loc) {
        document.location.href = loc;
    }
    return true;
}

function message_submit(actID)
{
    if (actID == 'spam_report') {
        if (!window.confirm(ImpText.spam_report)) {
            return;
        }
    } else if (actID == 'notspam_report') {
        if (!window.confirm(ImpText.notspam_report)) {
            return;
        }
    }
    $('actionID').value = actID;
    $('messages').submit();
}

function flagMessage(form)
{
    var f1 = $('flag1'), f2 = $('flag2');
    if ((form == 1 && f1.options[f1.selectedIndex].value != "") ||
        (form == 2 && f2.options[f2.selectedIndex].value != "")) {
        $('flag').value = (form == 1) ? f1.options[f1.selectedIndex].value : f2.options[f2.selectedIndex].value;;
        message_submit('flag_message');
    }
}

function transfer(actID, form)
{
    var t1 = $('target1'), t2 = $('target2');
    var tmbox = $('targetMbox');
    tmbox.value = (form == 1) ? t1.options[t1.selectedIndex].value : t2.options[t2.selectedIndex].value;

    // Check for a mailbox actually being selected.
    if (tmbox.value == '*new*') {
        var newFolder = window.prompt(ImpText.newfolder, '');
        if (newFolder != null && newFolder != '') {
            $('newMbox').value = 1;
            tmbox.value = newFolder;
            message_submit(actID);
        }
    } else {
        if (tmbox.value == '') {
            window.alert(ImpText.target_mbox);
        } else {
            message_submit(actID);
        }
    }
}

function updateFolders(form)
{
    var f = (form == 1) ? 2 : 1;
    $('target' + f).selectedIndex = $('target' + form).selectedIndex;
}

/* Function needed for IE compatibilty with drop-down menus. */
function messageActionsHover()
{
    $$('UL').each(function(ul) {
        if (!Element.hasClassName(ul, 'msgactions')) {
            return;
        }
        $A(ul.getElementsByTagName('LI')).each(function(li) {
            Event.observe(li, 'mouseout', function() {
                Element.removeClassName(this, 'hover');
                var iefix = $('msgactions_iefix');
                if (iefix) {
                    Element.hide(iefix);
                }
            }.bindAsEventListener(li));
            Event.observe(li, 'mouseover', function() {
                var uls = this.getElementsByTagName('UL');
                if (!uls.length) {
                    return;
                }

                Element.addClassName(this, 'hover');
                var iefix = $('msgactions_iefix');
                if (!iefix) {
                    iefix = document.createElement('IFRAME');
                    iefix.id = 'msgactions_iefix';
                    iefix.src = 'javascript:false;';
                    iefix.scrolling = 'no';
                    iefix.frameborder = 0;
                    Element.hide(iefix);
                    Element.setStyle(iefix, { position: 'absolute' });
                    document.body.appendChild(iefix);
                }
                Position.clone(uls[0], iefix);

                var zindex = Element.getStyle(this, 'zIndex');
                if (zindex == '') {
                    Element.setStyle(this, { zIndex: 2 });
                    Element.setStyle(iefix, { zIndex: 1 });
                } else {
                    Element.setStyle(iefix, { zIndex: zindex - 1 });
                }
                Element.show(iefix);
            }.bindAsEventListener(li));
        });
    });
}

Event.observe(window, 'load', function() {
    // Set up left and right arrows to go to the previous/next page.
    setKeybinding(Event.KEY_LEFT, arrowHandler);
    setKeybinding(Event.KEY_RIGHT, arrowHandler);

    if (Prototype.Browser.IE) {
         messageActionsHover();
    }
});
