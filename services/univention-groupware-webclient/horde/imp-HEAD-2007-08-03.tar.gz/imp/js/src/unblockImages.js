/**
 * $Horde: imp/js/src/unblockImages.js,v 1.3 2006/08/19 18:13:04 selsky Exp $
 *
 * Use DOM manipulation to un-block images that had been redirected.
 */
function IMPUnblockImages(parent, message)
{
    if (!document.getElementById || !document.getElementsByTagName || !parent) {
        return true;
    }

    var elements = parent.getElementsByTagName('*');
    for (i = 0; i < elements.length; ++i) {
        var elt = elements[i];
        if (_hasAttribute(elt, 'blocked')) {
            var src = decodeURIComponent(elt.getAttribute('blocked'));
            if (_hasAttribute(elt, 'src')) {
                elt.setAttribute('src', src);
            } else if (_hasAttribute(elt, 'background')) {
                elt.setAttribute('background', src);
            } else if (_hasAttribute(elt, 'background-image')) {
                elt.setAttribute('background-image', src);
            }
        }
    }

    var message = document.getElementById(message);
    if (message) {
        message.parentNode.removeChild(message);
    }

    // On success return false to stop event propagation.
    return false;
}

function _hasAttribute(element, attribute) {
    if (element.hasAttribute) {
        return element.hasAttribute(attribute);
    } else {
        return (typeof element[attribute] != 'undefined');
    }
}
