/**
 * Provides the javascript for the contacts.php script
 *
 * $Horde: imp/js/src/contacts.js,v 1.3 2007/02/28 23:46:26 jan Exp $
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

// The following variables are defined in contacts.php:
//   display, formname, to_only

function adjustSize()
{
    var ow = $('contactstable').offsetWidth;
    if (ow && ow > 550) {
        window.resizeTo(ow, 300);
    }
}

function changeDisplay()
{
    var d = $('display')

    if (d.options[d.selectedIndex].value != display) {
        display = d.options[d.selectedIndex].value;

        ['search_results', 'selected_addresses'].each(function(e) {
            $A($(e)).each(function(s) {
                var temp = s.value;
                if (!temp) {
                    return; 
                }

                s.value = encodeURIComponent(s.text);
                s.text = decodeURIComponent(temp);
            });
        });
    }
}

function passAddresses()
{
    var sa = '';

    $A($('selected_addresses')).each(function(s) {
        if (!s.value) {
            return;
        }
        sa += s.value + '|' + s.text + '|';
    });
    $('sa').value = sa;
}

function sameOption(f, item, itemj)
{
    var t = f + ": " + item.text, v = f + ": " + item.value;
    var tj = itemj.text, vj = itemj.value;

    return Try.these(
        function() {
            return ((t == tj) || (decodeURIComponent(t) == decodeURIComponent(tj))) &&
                ((v == vj) || (decodeURIComponent(v) == decodeURIComponent(vj)));
        },
        // Catch exception with NS 7.1
        function() {
            return (t == tj && v == vj);
        }
    );
}

function addAddress(f)
{
    var s = $('search_results'), add = [];

    if (s.selectedIndex < 0) {
        alert(ImpText.contacts_select);
        return false;
    } else {
        var d = $('selected_addresses'), l = $A(d).length;
        $A(s).each(function(i) {
            if (i.value && i.selected) {
                if (!$A(d).any(function(j) {
                    return sameOption(f, i, j);
                })) {
                    d[l++] = new Option(f + ': ' + i.text, f + ': ' + i.value);
                }
            }
        });
    }

    return true;
}

function updateMessage()
{
    if (parent.opener.closed) {
        alert(ImpText.contacts_closed);
        this.close();
        return;
    }

    if (!parent.opener.document[formname]) {
        alert(ImpText.contacts_called);
        this.close();
        return;
    }

    $A($('selected_addresses')).each(function(s) {
        var address, f, fullname, field = null, pos, v;
        if (display == "name") {
            address = decodeURIComponent(s.value);
            fullname = s.text;
        } else {
            address = s.text;
            fullname = decodeURIComponent(s.value);
        }
        pos = address.indexOf(':');
        f = address.substring(0, pos);

        if (f == 'to') {
            field = parent.opener.document[formname].to;
        } else if (!to_only && f == 'cc') {
            field = parent.opener.document[formname].cc;
        } else if (!to_only && f == 'bcc') {
            field = parent.opener.document[formname].bcc;
        } else {
            return;
        }

        fullname = fullname.substring(pos + 2, fullname.length).replace(/\\/g, '\\\\').replace(/"/g, '\\"');

        if (address.substring(pos + 2, address.length).indexOf(',') > 0) {
            address = fullname + ': ' + address.substring(pos + 2, address.length) + ';';
        } else {
            address = '"' + fullname + '" <' + address.substring(pos + 2, address.length) + '>';
        }

        // Always delimit with commas.
        if (field.value.length) {
            v = field.value.replace(/, +/g, ',').split(',').findAll(function(s) { return s; });
            v.push(address);
            field.value = v.join(', ');
        } else {
            field.value = address;
        }
        if (address.lastIndexOf(';') != address.length - 1) {
            field.value += ', ';
        }
    });

    this.close();
}

function removeAddress()
{
    var s = $('selected_addresses');
    $A(s).each(function(o) {
        if (o.selected) {
            s[o.index] = null;
        }
    });
}

Event.observe(window, 'load', adjustSize);
