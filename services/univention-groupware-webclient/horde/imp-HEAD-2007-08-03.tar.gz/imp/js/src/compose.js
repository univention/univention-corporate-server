/**
 * Provides the javascript for the compose.php script.
 *
 * $Horde: imp/js/src/compose.js,v 1.7 2007/08/03 05:54:15 chuck Exp $
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

/*
 * Variables defined in compose.php:
 *    cancel_url, compose_spellcheck, cursor_pos, identities, max_attachments,
 *    popup, redirect, rtemode, smf_check
 */

var display_unload_warning = true, spellcheck_done = false;

function confirmCancel(event)
{
    if (window.confirm(ImpText.compose_cancel)) {
        display_unload_warning = false;
        if (popup) {
            if (cancel_url) {
                self.location.href = cancel_url;
            } else {
                self.close();
            }
        } else {
            window.location = cancel_url;
        }
        return true;
    } else {
        Event.stop(event);
        return false;
    }
}

/**
 * Sets the cursor to the given position.
 */
function setCursorPosition(input, position)
{
    if (input.setSelectionRange) {
        /* This works in Mozilla */
        Field.focus(input);
        input.setSelectionRange(position, position);
    } else if (input.createTextRange) {
        /* This works in IE */
        var range = input.createTextRange();
        range.collapse(true);
        range.moveStart('character', position);
        range.moveEnd('character', 0);
        Field.select(range);
        range.scrollIntoView(true);
    }
}

function redirectSubmit(event)
{
    if ($F('to') == '') {
        alert(ImpText.compose_recipient);
        Field.focus('to');
        Event.stop(event);
        return false;
    }

    Element.setStyle('redirect', { cursor: 'wait' });
    display_unload_warning = false;

    return true;
}

function change_identity(id)
{
    var last = identities[$F('last_identity')];
    var next = identities[id];
    var msg, ed;
    if (rtemode) {
        ed = (typeof __editors != 'undefined') ? __editors.message : _editors.message;
        msg = ed.getHTML();
    } else {
        msg = $F('message');
    }
    msg = msg.replace(/\r\n/g, '\n');

    if (rtemode) {
        next[0] = next[0].replace(/^ ?<br \/>\n/, '').replace(/ +/g, ' '); //.replace(/<br \/>/, '<BR>');
        last[0] = last[0].replace(/^ ?<br \/>\n/, '').replace(/ +/g, ' '); //.replace(/<br \/>/, '<BR>');
    } else {
        next[0] = next[0].replace(/^\n/, '');
        last[0] = last[0].replace(/^\n/, '');
    }

    var pos = (last[1]) ? msg.indexOf(last[0]) : msg.lastIndexOf(last[0]);

    if (pos != -1) {
        if (next[1] == last[1]) {
            msg = msg.substring(0, pos) + next[0] + msg.substring(pos + last[0].length, msg.length);
        } else if (next[1]) {
            msg = next[0] + msg.substring(0, pos) + msg.substring(pos + last[0].length, msg.length);
        } else {
            msg = msg.substring(0, pos) + msg.substring(pos + last[0].length, msg.length) + next[0];
        }

        msg = msg.replace(/\r\n/g, '\n').replace(/\n/g, '\r\n');
        if (rtemode) {
            ed.setHTML(msg);
        } else {
            $('message').value = msg;
        }

        $('last_identity').value = id;
        window.status = ImpText.compose_sigreplace;
    } else {
        window.status = ImpText.compose_signotreplace;
    }

    var smf = $('sent_mail_folder');

    if (smf_check) {
        var i = 0;
        $A(smf.options).detect(function(f) {
            if (f.value == next[2]) {
                smf.selectedIndex = i;
                return true;
            }
            ++i;
        });
    } else {
        if (smf.firstChild) {
            smf.replaceChild(document.createTextNode(next[2]), smf.firstChild);
        } else {
            smf.appendChild(document.createTextNode(next[2]));
        }
    }

    var save = $('ssm');
    if (save) {
        save.checked = next[3];
    }
    var bcc = $('bcc');
    if (bcc) {
        bccval = bcc.value;
        var re = new RegExp(last[4] + ",? ?", 'gi');
        bccval = bccval.replace(re, "");
        if (bccval) {
            bccval = bccval.replace(/, ?$/, "");
        }
        if (next[4]) {
            if (bccval) {
                bccval += ', ';
            }
            bccval += next[4];
        }

        bcc.value = bccval;
    }
}

function uniqSubmit(actionID, event)
{
    if (actionID == 'send_message') {
        if (($F('subject') == '') &&
            !window.confirm(ImpText.compose_nosubject)) {
            if (event) {
                Event.stop(event);
            }
            return false;
        }

        if (compose_spellcheck && !spellcheck_done) {
            /* TODO: Automatically send when finished with spellcheck. */
            SpellCheckerObject.spellCheck();
            spellcheck_done = true;
            if (event) {
                Event.stop(event);
            }
            return false;
        }
    }

    Element.setStyle('compose', { cursor: 'wait' });
    display_unload_warning = false;
    $('actionID').value = actionID;
    $('compose').submit();
}

function attachmentChanged()
{
    var fields = [], usedFields = 0;

    $A(document.compose.elements).each(function(i) {
        if (i.type == 'file' && i.name.substr(0, 7) == 'upload_') {
            fields[fields.length] = i;
        }
    });

    if (max_attachments !== null &&
        fields.length == max_attachments) {
        return;
    }

    fields.each(function(i) {
        if (i.value.length > 0) {
            usedFields++;
        }
    });

    if (usedFields == fields.length) {
        var lastRow = $('attachment_row_' + usedFields);
        if (lastRow) {
            var newRow = document.createElement('TR');
            newRow.id = 'attachment_row_' + (usedFields + 1);

            var td = document.createElement('TD');
            td.align = 'left';
            newRow.appendChild(td);

            var strong = document.createElement('STRONG');
            strong.appendChild(document.createTextNode(ImpText.compose_file + ' ' + (usedFields + 1) + ':'));
            td.appendChild(strong);

            td.appendChild(document.createTextNode(' '));

            var file = document.createElement('INPUT');
            file.type = 'file';
            file.name = 'upload_' + (usedFields + 1);
            Event.observe(file, 'change', function() { attachmentChanged(); });
            file.size = 25;
            td.appendChild(file);

            td2 = document.createElement('TD');
            td2.align = 'left';

            var select = document.createElement('SELECT');
            select.name = 'upload_disposition_' + (usedFields + 1);
            select.options[0] = new Option(ImpText.compose_attachment, 'attachment', true);
            select.options[1] = new Option(ImpText.compose_inline, 'inline');
            td2.appendChild(select);
            newRow.appendChild(td2);

            lastRow.parentNode.insertBefore(newRow, lastRow.nextSibling);
        }
    }
}

function initializeSpellChecker()
{
    if (typeof SpellCheckerObject != 'object') {
        // If we fired before the onload that initializes the
        // spellcheck, wait.
        window.setTimeout(initializeSpellChecker, 100);
        return;
    }

    SpellCheckerObject.onBeforeSpellCheck = function() {
        // TODO: BC break as xinha has changed its internal storage structure
        // to the former.
        var ed = (typeof __editors != 'undefined') ? __editors.message : _editors.message;
        SpellCheckerObject.htmlArea = ed._htmlArea;
        SpellCheckerObject.htmlAreaParent = 'messageParent';
        ed._textArea.value = ed.outwardHtml(ed.getHTML());
    }
    SpellCheckerObject.onAfterSpellCheck = function() {
        var ed = (typeof __editors != 'undefined') ? __editors.message : _editors.message;
        SpellCheckerObject.htmlArea = SpellCheckerObject.htmlAreaParent = null;
        ed.setHTML(ed.inwardHtml(ed._textArea.value));
    }
}

/**
 * Code to run on window load.
 */
Event.observe(window, 'load', function() {
    /* Prevent Return from sending messages - it should bring us out of
     * autocomplete, not submit the whole form. */
    $A(document.getElementsByTagName('INPUT')).each(function(i) {
        /* Attach to everything but button and submit elements. */
        if (i.type != 'submit' && i.type != 'button') {
            Event.observe(i, 'keydown', function(e) {
                if (e.keyCode == 10 || e.keyCode == Event.KEY_RETURN) {
                    Event.stop(e);
                    return false;
                }
            }.bindAsEventListener());
        }
    });

    if (cursor_pos !== null) {
        setCursorPosition($('message'), cursor_pos);
    }

    if (redirect) {
        Field.focus('to');
    } else {
        if (Prototype.Browser.IE) {
            Event.observe('subject', 'keydown', function(e) {
                if (e.keyCode == Event.KEY_TAB && !e.shiftKey) {
                    Event.stop(e);
                    Field.focus('message');
                }
            });
        }

        if (rtemode) {
            initializeSpellChecker();
        }

        if ($('to') && !Field.present('to')) {
            Field.focus('to');
        } else if (!Field.present('subject')) {
            if (rtemode) {
                Field.focus('subject');
            } else {
                Field.focus('message');
            }
        }
    }
});

/**
 * Warn before closing the window.
 */
Event.observe(window, 'beforeunload', function() {
    if (display_unload_warning) {
        return ImpText.compose_discard;
    }
});
