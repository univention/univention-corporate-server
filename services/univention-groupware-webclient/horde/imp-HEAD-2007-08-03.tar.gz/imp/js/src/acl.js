/**
 * Provides the javascript for the acl.php script
 *
 * $Horde: imp/js/src/acl.js,v 1.2 2006/12/30 20:24:38 jan Exp $
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

var loading;

function ACLFolderChange(clear)
{
    if (document.folders.folder[document.folders.folder.selectedIndex].value != '') {
        if (loading == null || clear != null) {
            loading = true;
            disableButtons();
            document.folders.submit();
        }
    }
}

function disableButtons() {
    if (document.acl.fbutton) {
        document.acl.fbutton.disabled = true;
    }
    if (document.acl.resetbut) {
        document.acl.resetbut.disabled = true;
    }
    if (document.acl.back) {
        document.acl.back.disabled = true;
    }
    if (document.acl.number) {
        for (var i = 0; i < document.acl.number.length; i++) {
            document.acl.number[i].disabled = true;
        }
    }
    return true;
}
