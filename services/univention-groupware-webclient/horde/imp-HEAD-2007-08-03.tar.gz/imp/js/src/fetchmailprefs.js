/**
 * Provides the javascript for the fetchmailprefs.php script.
 *
 * $Horde: imp/js/src/fetchmailprefs.js,v 1.2 2006/12/30 20:24:38 jan Exp $
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

var loading = false;

function accountSubmit(isnew)
{
    if ((isnew != null) || (document.fm_switch.account[document.fm_switch.account.selectedIndex].value != '')) {
        if (!loading) {
            loading = true;
            document.fm_switch.submit();
        }
    }
}

function driverSubmit()
{
    if (document.fm_driver.fm_driver[document.fm_driver.fm_driver.selectedIndex].value != '') {
        if (!loading) {
            loading = true;
            document.fm_driver.submit();
        }
    }
}
