/**
 * Provides the javascript for the login.php script.
 *
 * $Horde: imp/js/src/login.js,v 1.3 2007/04/12 15:08:58 slusarz Exp $
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

function setFocus()
{
    if (document.imp_login.imapuser.value == "") {
        document.imp_login.imapuser.focus();
    } else {
        document.imp_login.pass.focus();
    }
}

function imp_reload()
{
    window.top.document.location = autologin_url + document.imp_login.server_key[document.imp_login.server_key.selectedIndex].value;
}

function submit_login()
{
    if (show_list && document.imp_login.server[document.imp_login.server.selectedIndex].value.substr(0, 1) == "_") {
        return false;
    }
    if (document.imp_login.imapuser.value == "") {
        alert(ImpText.login_username);
        document.imp_login.imapuser.focus();
        return false;
    } else if (document.imp_login.pass.value == "") {
        alert(ImpText.login_password);
        document.imp_login.pass.focus();
        return false;
    } else {
        document.imp_login.loginButton.disabled = true;
        if (ie_clientcaps) {
            try {
                document.imp_login.ie_version.value = objCCaps.getComponentVersion("{89820200-ECBD-11CF-8B85-00AA005B4383}","componentid");
            } catch (e) { }
        }
        document.imp_login.submit();
        return true;
    }
}

function selectLang()
{
    // We need to reload the login page here, but only if the user hasn't
    // already entered a username and password.
    if (document.imp_login.imapuser.value == '' &&
        document.imp_login.pass.value == '') {
        var lang_page = 'login.php?new_lang=' + document.imp_login.new_lang[document.imp_login.new_lang.selectedIndex].value;
        if (lang_url !== null) {
            lang_page += '&url=' + lang_url;
        }
        self.location = lang_page;
    }
}

function updatePort()
{
    var v = document.imp_login.protocol.options[document.imp_login.protocol.selectedIndex].value;
    if (protocols[v]) {
        document.imp_login.port.value = protocols[v];
    }
}

function serverChangeHandler()
{
    if (change_smtphost) {
        document.imp_login.smtphost.value = document.imp_login.server.value;
    }
}

/* Removes any leading hash that might be on a location string. */
function removeHash(h) {
    if (h == null || h == undefined) {
        return null;
    } else if (h.length && h.charAt(0) == '#') {
        if (h.length == 1) {
            return "";
        } else {
            return h.substring(1);
        }
    }
    return h;
}

Event.observe(window, 'load', function() {
    if (imp_auth) {
        if (parent.frames.horde_main) {
            if (nomenu) {
                parent.location = self.location;
            } else {
                document.imp_login.target = '_parent';
            }
        }
    }

    // Need to capture hash information if it exists in URL
    if (location.hash) {
        $('anchor_string').value = removeHash(location.hash);
    }
});
