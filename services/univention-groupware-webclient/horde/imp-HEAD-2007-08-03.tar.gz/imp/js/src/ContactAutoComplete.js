/**
 * Javascript code used by ContactAutoCompleter to display results box.
 *
 * $Horde: imp/js/src/ContactAutoComplete.js,v 1.2 2007/06/15 13:28:11 jan Exp $
 *
 * Copyright 2005-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

function ContactAutoCompleter_onShow(e, u) {
    if (!u.style.position || u.style.position == 'absolute') {
        u.setStyle({ position: 'absolute' });
        Position.clone(e, u, { setHeight: false, offsetTop: e.offsetHeight + e.scrollTop });
    }

    Effect.Appear(u, {
        duration: 0.15,
        beforeStart: function(effect) {
            var elt = effect.element;
            elt.setStyle({ height: 'auto', overflow: 'none' });
            elt.setStyle({
                height: Math.min(elt.getHeight(), ((window.innerHeight ? window.innerHeight : document.body.clientHeight) - Position.page(e)[1] - e.offsetHeight - 10)) + 'px',
                overflow: 'auto'
            });
        }
    });
}
