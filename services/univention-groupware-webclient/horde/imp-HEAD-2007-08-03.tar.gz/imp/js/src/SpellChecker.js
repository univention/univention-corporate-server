/*
 * This spell checker was inspired by work done by Garrison Locke, but
 * was rewritten almost completely by Chuck Hagenbuch to use
 * Prototype/Scriptaculous.
 *
 * $Horde: imp/js/src/SpellChecker.js,v 1.29 2007/03/13 06:53:53 slusarz Exp $
 *
 * Copyright 2005-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

SpellChecker = Class.create();
Object.extend(SpellChecker.prototype, {
    // Vars used and defaulting to null:
    //   bad, choices, choicesDiv, curWord, htmlArea, htmlAreaParent, locale,
    //   localeChoices, onAfterSpellCheck, onBeforeSpellCheck, reviewDiv,
    //   statusButton, statusClass, suggestions, target, url
    options: {},
    resumeOnDblClick: true,
    state: 'CheckSpelling',

    initialize: function(url, target, statusButton)
    {
        var d, li, locales, popdown, sb, ul;

        this.url = url;
        this.target = target;
        this.options.onComplete = this.onComplete.bind(this);
        this.statusButton = $(statusButton);
        Event.observe(this.statusButton, 'click', this.process.bindAsEventListener(this));
        this.buttonStates = arguments[3];

        locales = arguments[4] || {};
        if (locales) {
            d = document.createElement('DIV');
            d.id = 'spellcheckpopdown';
            Element.addClassName(d, 'autocomplete');
            Element.setStyle(d, { position: 'absolute' });
            Element.hide(d);

            ul = document.createElement('UL');
            // Can't use $H() here
            for (var lc in locales) {
                li = document.createElement('LI');
                li.setAttribute('lc', lc);
                Element.update(li, locales[lc]);
                ul.appendChild(li);
            }
            d.appendChild(ul);

            this.localeChoices = new KeyNavList(d, { onChoose: this.setLocale.bindAsEventListener(this) } );

            popdown = document.createElement('A');
            Element.update(popdown, '&nbsp;');
            Element.addClassName(popdown, 'popdown');
            Event.observe(popdown, 'click', function() {
                sb = $(this.statusButton);
                Position.clone(sb, 'spellcheckpopdown', {
                    setHeight: false,
                    setWidth: false,
                    offsetTop: sb.offsetHeight
                });
                this.localeChoices.show();
            }.bind(this));

            this.statusButton.parentNode.insertBefore(popdown, this.statusButton.nextSibling);

            document.body.appendChild(d);
        }

        this.statusClass = arguments[5] || '';

        // Make sure that the form gets turned back into real text
        // when it's submitted.
        Event.observe($(this.target).form, 'submit', this.resume.bindAsEventListener(this));

        // We need to monitor clicks to know when to go out of
        // showSuggestions mode.
        Event.observe(document, 'click', this.onClick.bindAsEventListener(this));

        this.status('CheckSpelling');
    },

    setLocale: function(event)
    {
        this.locale = event.getAttribute('lc');
    },

    targetValue: function(value)
    {
        // Ensure we have the correct input.
        var input = $(this.target);

        if (value) {
            input.value = value;
            return;
        }

        return (typeof input.value == 'undefined') ? input.innerHTML : input.value;
    },

    process: function(e)
    {
        switch (this.state) {
        case 'CheckSpelling':
            this.spellCheck();
            break;

        case 'ResumeEdit':
            this.resume();
            break;
        }

        Event.stop(e);
    },

    spellCheck: function()
    {
        if (this.onBeforeSpellCheck) {
            this.onBeforeSpellCheck();
        }

        this.status('Checking');

        if (this.choicesDiv) {
            Element.remove(this.choicesDiv);
            this.choicesDiv = null;
        }

        this.options.parameters = encodeURIComponent(this.target) + '=' + encodeURIComponent(this.targetValue());

        var url = this.url;
        if (this.locale) {
            url += '/locale=' + this.locale;
        }
        if (this.htmlAreaParent) {
            url += '/html=1';
        }

        new Ajax.Request(url, this.options);
    },

    onClick: function(event)
    {
        // If the language dropdown is currently active, and the click
        // got here, then we should hide the language dropdown.
        if (this.localeChoices) {
            this.localeChoices.hide();
        }

        // If we're not currently showing any choices, then we return
        // and let the click go.
        if (!this.choicesDiv) {
            return true;
        }

        // If the click was on the word that we're currently showing
        // results for, then we do nothing and let the list be
        // redisplayed by the link's own onclick handler.
        var link = Event.findElement(event, 'SPAN');
        if (link && link == this.curWord) {
            return true;
        }

        // The KeyNavList will have already handled any valid clicks,
        // so that just leaves the rest of the window - in this case
        // we want to hide the KeyNavList and reset curWord without
        // changing anything.
        this.curWord = null;
        this.choices.hide();
        Element.remove(this.choicesDiv);
        this.choicesDiv = null;
    },

    getElementsBySpanName: function(name, parentElm) {
        return $A(($(parentElm) || document.body).getElementsByTagName('SPAN')).findAll(function(e) {
            return e.getAttribute('name') == name;
        });
    },

    falsify: function() {
        return false;
    },

    falsifyLinks: function() {
        $A(this.reviewDiv.getElementsByTagName('A')).each(function(e) {
            Event.observe(e, 'click', this.falsify);
        });
    },

    unfalsifyLinks: function() {
        $A(this.reviewDiv.getElementsByTagName('A')).each(function(e) {
            Event.stopObserving(e, 'click', this.falsify);
        });
    },

    onComplete: function(request)
    {
        var content,
            i = 0,
            input = $(this.target),
            map = {},
            reEscape = new RegExp('([().+*^$])'),
            result = request.responseText.evalJSON(true);

        if (this.choicesDiv) {
            Element.remove(this.choicesDiv);
            this.choicesDiv = null;
        }

        if (typeof result == 'undefined') {
            this.resume();
            this.status('Error');
            return;
        }

        this.bad = result.bad || [];
        this.suggestions = result.suggestions || [];

        content = this.targetValue();
        if (this.htmlAreaParent) {
            content = content.replace(/\r?\n/g, '');
        } else {
            content = content.replace(/\r?\n/g, '~~~').escapeHTML();
        }

        $A(this.bad).each(function(node) {
            map[node] = i++;
            var re = new RegExp("(?:^|\\b)" + node.replace(reEscape, '\\' + RegExp.$1) + "(?:\\b|$)", 'g');
            content = content.replace(re, '<span name="incorrect" class="incorrect">' + node + '</span>');
        });

        if (!this.reviewDiv) {
            this.reviewDiv = document.createElement('DIV');
            Element.addClassName(this.reviewDiv, input.className);
            Element.addClassName(this.reviewDiv, 'spellcheck');
            Element.setStyle(this.reviewDiv, { overflow: 'auto' });
            if (this.resumeOnDblClick) {
                Event.observe(this.reviewDiv, 'dblclick', this.resume.bind(this));
            }
        }

        Element.setStyle(this.reviewDiv, { width: Element.getStyle(input, 'width'), height: Element.getStyle(input, 'height') });
        if (Element.getStyle(this.reviewDiv, 'height') === 0) {
            Element.setStyle(this.reviewDiv, { height: Element.getHeight(input) + 'px' });
        }

        Element.update(this.reviewDiv, content);
        if (!this.htmlAreaParent) {
            Element.update(this.reviewDiv, this.reviewDiv.innerHTML.replace(/~~~/g, '<br />'));
        }

        // Now attach results behavior to each link.
        var links = this.getElementsBySpanName('incorrect', this.reviewDiv);
        for (i = 0; i < links.length; ++i) {
            links[i].index = map[links[i].innerHTML];
            Event.observe(links[i], 'click', this.showSuggestions.bindAsEventListener(this));
            links[i].id = this.target + i;
        }

        this.falsifyLinks();

        if (this.htmlAreaParent) {
            Element.hide(this.htmlArea);
            $(this.htmlAreaParent).appendChild(this.reviewDiv);
        } else {
            Element.hide(input);
            input.parentNode.insertBefore(this.reviewDiv, input);
        }

        this.status('ResumeEdit');
    },

    showSuggestions: function(event)
    {
        var el, pos, ul;

        el = Event.findElement(event, 'SPAN');
        this.curWord = el;

        this.removeChoices();

        this.choicesDiv = document.createElement('DIV');
        Element.addClassName(this.choicesDiv, 'autocomplete');
        Element.hide(this.choicesDiv);

        pos = Position.page(el);
        Element.setStyle(this.choicesDiv, { left: pos[0] + 'px', top: (pos[1] + 16) + 'px' });

        ul = document.createElement('UL');
        $A(this.suggestions[el.index]).each(function (node) {
            var li = document.createElement('LI');
            li.appendChild(document.createTextNode(node));
            ul.appendChild(li);
        });

        this.choicesDiv.appendChild(ul);
        this.choices = new KeyNavList(this.choicesDiv, { onChoose: function(event) { this.replaceWord(event, el.id); }.bind(this) });
        this.choices.show();
        document.body.appendChild(this.choicesDiv);
    },

    replaceWord: function(li, word)
    {
        Element.update(word, li.innerHTML);
        $(word).className = 'corrected';
        this.removeChoices();
    },

    removeChoices: function() 
    {
        if (this.choicesDiv) {
            Element.remove(this.choicesDiv);
            this.choicesDiv = null;
        }
    },

    resume: function()
    {
        this.removeChoices();

        if (!this.reviewDiv) {
            return;
        }

        var incorrectWords = this.getElementsBySpanName('incorrect', this.reviewDiv), input = $(this.target), tmpWord = false;

        if (incorrectWords.length > 0) {
            for (var i = (incorrectWords.length - 1); i >= 0; i--) {
                tmpWord = incorrectWords[i].innerHTML;
                incorrectWords[i].parentNode.replaceChild(document.createTextNode(tmpWord), incorrectWords[i]);
            }
        }

        this.unfalsifyLinks();

        var t = this.reviewDiv.innerHTML;
        if (!this.htmlAreaParent) {
            t = t.replace(/<br *\/?>/gi, '~~~').unescapeHTML().replace(/~~~/g, "\n");
        }
        this.targetValue(t);
        input.disabled = false;

        Element.remove(this.reviewDiv);
        this.reviewDiv = null;

        this.status('CheckSpelling');

        if (this.htmlAreaParent) {
            Element.show(this.htmlArea);
        } else {
            Element.show(input);
        }

        if (this.onAfterSpellCheck) {
            this.onAfterSpellCheck();
        }
    },

    status: function(state)
    {
        if (!this.statusButton) {
            return;
        }

        this.state = state;
        switch (this.statusButton.tagName) {
        case 'INPUT':
            this.statusButton.value = this.buttonStates[state];
            break;

        case 'A':
            Element.update(this.statusButton, this.buttonStates[state]);
            break;
        }
        this.statusButton.className = this.statusClass + ' ' + state;
    }

});
