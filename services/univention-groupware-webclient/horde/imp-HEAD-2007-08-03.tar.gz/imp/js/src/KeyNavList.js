/**
 * Reuseable keyboard or mouse driven list component. Based on
 * Scriptaculous' AutoCompleter.
 *
 * $Horde: imp/js/src/KeyNavList.js,v 1.6 2007/06/15 13:19:14 jan Exp $
 *
 * Copyright 2005-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

KeyNavList = Class.create();
KeyNavList.prototype = {
    initialize: function(element, options) {
        this.element = $(element);
        this.active = false;
        this.index = -1;
        this.entryCount = 0;

        this.entryCount = this.element.firstChild.childNodes.length;
        for (var i = 0; i < this.entryCount; i++) {
            var entry = this.getEntry(i);
            entry.autocompleteIndex = i;
            this.addObservers(entry);
        }

        if (this.setOptions) {
            this.setOptions(options);
        } else {
            this.options = options || {};
        }

        this.options.onShow = this.options.onShow ||
            function(element) { Effect.Appear(element,{duration:0.15}); };
        this.options.onHide = this.options.onHide ||
            function(element) { new Effect.Fade(element,{duration:0.15}); };

        Event.observe(this.element, 'blur', this.onBlur.bindAsEventListener(this));
        Event.observe(document, 'keypress', this.onKeyPress.bindAsEventListener(this));
    },

    show: function() {
        this.active = true;
        if (Element.getStyle(this.element, 'display') == 'none') {
            this.options.onShow(this.element);
        }
        if (!this.iefix &&
            (navigator.appVersion.indexOf('MSIE') > 0) &&
            (Element.getStyle(this.element, 'position') == 'absolute')) {
            new Insertion.After(this.element,
                                '<iframe id="' + this.element.id + '_iefix" '
                                + 'style="display:none;position:absolute;filter:progid:DXImageTransform.Microsoft.Alpha(opacity=0);" '
                                + 'src="javascript:false;" frameborder="0" scrolling="no"></iframe>');
            this.iefix = $(this.element.id+'_iefix');
        }
        if (this.iefix) {
            setTimeout(this.fixIEOverlapping.bind(this), 50);
        }
    },

    fixIEOverlapping: function() {
        Position.clone(this.element, this.iefix);
        this.iefix.style.zIndex = 1;
        this.element.style.zIndex = 2;
        Element.show(this.iefix);
    },

    hide: function() {
        this.active = false;
        this.stopIndicator();
        if (Element.getStyle(this.element, 'display') != 'none') {
            this.options.onHide(this.element);
        }
        if (this.iefix) {
            Element.hide(this.iefix);
        }
    },

    startIndicator: function() {
        if (this.options.indicator) {
            Element.show(this.options.indicator);
        }
    },

    stopIndicator: function() {
        if (this.options.indicator) {
            Element.hide(this.options.indicator);
        }
    },

    onKeyPress: function(event) {
        if (this.active) {
            switch (event.keyCode) {
            case Event.KEY_TAB:
            case Event.KEY_RETURN:
                this.selectEntry();
                Event.stop(event);
            case Event.KEY_ESC:
                this.hide();
                this.active = false;
                Event.stop(event);
                return;
            case Event.KEY_LEFT:
            case Event.KEY_RIGHT:
                return;
            case Event.KEY_UP:
                this.markPrevious();
                this.render();
                if (navigator.appVersion.indexOf('AppleWebKit') > 0) {
                    Event.stop(event);
                }
                return;
            case Event.KEY_DOWN:
                this.markNext();
                this.render();
                if (navigator.appVersion.indexOf('AppleWebKit') > 0) {
                    Event.stop(event);
                }
                return;
            }
        } else if (event.keyCode==Event.KEY_TAB ||
                   event.keyCode==Event.KEY_RETURN) {
            return;
        }
    },

    onHover: function(event) {
        var element = Event.findElement(event, 'LI');
        if (this.index != element.autocompleteIndex) {
            this.index = element.autocompleteIndex;
            this.render();
        }
        Event.stop(event);
    },

    onClick: function(event) {
        var element = Event.findElement(event, 'LI');
        this.index = element.autocompleteIndex;
        this.selectEntry();
        this.hide();
        Event.stop(event);
    },

    onBlur: function(event) {
        setTimeout(this.hide.bind(this), 250);
        this.active = false;
    },

    render: function() {
        if (this.entryCount > 0) {
            for (var i = 0; i < this.entryCount; i++) {
                this.index == i
                ? Element.addClassName(this.getEntry(i), 'selected')
                : Element.removeClassName(this.getEntry(i), 'selected');
            }

            this.show();
            this.active = true;
        } else {
            this.active = false;
            this.hide();
        }
    },

    markPrevious: function() {
        if (this.index > 0) {
            this.index--;
        } else {
            this.index = this.entryCount - 1;
        }
    },

    markNext: function() {
        if (this.index < this.entryCount - 1) {
            this.index++;
        } else {
            this.index = 0;
        }
    },

    getEntry: function(index) {
        return this.element.firstChild.childNodes[index];
    },

    getCurrentEntry: function() {
        return this.getEntry(this.index);
    },

    selectEntry: function() {
        this.active = false;
        if (typeof this.options.onChoose == 'function') {
            this.options.onChoose(this.getCurrentEntry());
        }
    },

    addObservers: function(element) {
        Event.observe(element, 'mouseover', this.onHover.bindAsEventListener(this));
        Event.observe(element, 'click', this.onClick.bindAsEventListener(this));
    }

}
