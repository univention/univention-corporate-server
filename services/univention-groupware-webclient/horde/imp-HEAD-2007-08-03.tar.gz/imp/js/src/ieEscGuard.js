/**
 * Javascript code for attaching an onkeydown listener to textarea and
 * text input elements to prevent loss of data when the user hits the
 * ESC key.
 *
 * $Horde: imp/js/src/ieEscGuard.js,v 1.3 2006/12/30 20:24:38 jan Exp $
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */

/* This code is only relevant for IE. Object-sniff for IE's event
 * model. */
if (window.attachEvent) {
    window.attachEvent('onload', guard);
}

/**
 * Finds all text inputs (input type="text") and textarea tags, and
 * attaches the onkeydown listener to them to avoid ESC clearing the
 * text.
 */
function guard()
{
    /* Finds all textareas. */
    var textareas = document.getElementsByTagName('TEXTAREA');
    for (var i = 0; i < textareas.length; ++i) {
        textareas[i].attachEvent('onkeydown', function() { return window.event.keyCode != 27; });
    }

    /* Finds _all_ <input> tags. */
    var inputs = document.getElementsByTagName('INPUT');
    for (var i = 0; i < inputs.length; ++i) {
        /* Only attach to <input type="text"> tags. */
        if (inputs[i].type == 'text') {
            inputs[i].attachEvent('onkeydown', function() { return window.event.keyCode != 27; });
        }
    }
}
