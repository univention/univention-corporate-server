<?php

require_once 'Horde/IMAP/Cache.php';

/**
 * The IMP_IMAP_Cache:: class extends Horde's IMAP_Cache:: class to add extra
 * IMP-specific functionality.
 *
 * $Horde: imp/lib/IMAP/Cache.php,v 1.26 2007/06/05 16:43:03 jan Exp $
 *
 * Copyright 2006-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 *
 * @author  Michael Slusarz <slusarz@horde.org>
 * @since   IMP 4.2
 * @package Horde_IMAP
 */
class IMP_IMAP_Cache extends IMAP_Cache {

    /**
     * The cached results of imap_status() calls.
     *
     * @var array
     */
    var $_statuscache = array();

    /**
     * Cached results for the imap_search() call to determine arrival time.
     *
     * @var $_arrival
     */
    var $_arrival = array();

    /**
     * Returns a reference to the global IMP_IMAP_Cache object, only creating
     * it if it doesn't already exist.
     *
     * This method must be invoked as:
     *   $imap_cache = &IMP_IMAP_Cache::singleton();
     *
     * @return IMP_IMAP_Cache  The global IMP_IMAP_Cache instance.
     */
    function &singleton()
    {
        static $object;

        if (!isset($object)) {
            $object = new IMP_IMAP_Cache();
        }

        return $object;
    }

    /**
     * Get data from the cache.
     *
     * @param resource $imap   The IMAP resource stream (not needed).
     * @param string $mailbox  The full ({hostname}mailbox) mailbox name.
     * @param string $key      The name of a specific entry to return.
     * @param boolean $check   Check for updated mailbox?
     *
     * @return mixed  The data requested, or false if not available.
     */
    function getCache($imap, $mailbox, $key = null, $check = true)
    {
        $imp_imap = &IMP_IMAP::singleton();
        return parent::getCache($imp_imap->stream(), $mailbox, $key, $check);
    }

    /**
     * Store data in the cache.
     *
     * @param resource $imap   The IMAP resource stream (not needed).
     * @param string $mailbox  The full ({hostname}mailbox) mailbox name.
     * @param array $values    The data to add to the cache.
     */
    function storeCache($imap, $mailbox, $values = array())
    {
        $this->_cache[$mailbox] = array(
            'k' => $this->_getCacheID($imap, $mailbox),
            'd' => $values
        );
    }

    /**
     * Store data in the cache, preserving any data already in the cache
     * entry and not altering the current cache key.
     *
     * @param resource $imap   The IMAP resource stream (not needed).
     * @param string $mailbox  The full ({hostname}mailbox) mailbox name.
     * @param array $values    The data to add to the cache.
     */
    function updateCache($imap, $mailbox, $values = array())
    {
        if (isset($this->_cache[$mailbox])) {
            $ptr = &$this->_cache[$mailbox];
            $ptr['d'] = array_merge($ptr['d'], $values);
        } else {
            $this->storeCache($imap, $mailbox, $values);
        }
    }

    /**
     * Flag cached entries as expired.
     *
     * @param string $mailbox  A mailbox name.
     * @param integer $mask    A bitmask for the following updates:
     * <pre>
     * 1 = Expire cache entries
     * 2 = Expire imap_status() entries
     * 4 = Expire getMailboxArrival() entries
     * </pre>
     */
    function expireCache($mailbox, $mask = 0)
    {
        $full_mailbox = IMP::serverString($mailbox);

        if ($mask & 1) {
            if (isset($this->_cache[$full_mailbox])) {
                $this->_cache[$full_mailbox]['k'] = '';
            }
        }

        if ($mask & 2) {
            unset($this->_statuscache[$full_mailbox]);
        }

        if ($mask & 4) {
            unset($this->_arrival[$mailbox]);
        }
    }

    /**
     * Returns and caches the results of an imap_status() call.
     *
     * @param resource $imap   The IMAP resource stream (not needed).
     * @param string $mailbox  A mailbox name.
     *
     * @return stdClass  The imap_status() object or the empty string.
     */
    function getStatus($imap, $mailbox)
    {
        $mailbox = IMP::serverString($mailbox);
        if (!isset($this->_statuscache[$mailbox]) &&
            !$GLOBALS['imp_search']->isSearchMbox(substr($mailbox, strpos($mailbox, '}') + 1))) {
            require_once IMP_BASE . '/lib/IMAP.php';
            $imp_imap = &IMP_IMAP::singleton();
            $this->_statuscache[$mailbox] = @imap_status($imp_imap->stream(), $mailbox, SA_ALL);
            if (!$this->_statuscache[$mailbox] &&
                ($err = imap_last_error())) {
                Horde::logMessage($err, __FILE__, __LINE__, PEAR_LOG_NOTICE);
            }
        }

        return empty($this->_statuscache[$mailbox]) ? '' : $this->_statuscache[$mailbox];
    }

    /**
     * Generate the unique ID string for the mailbox.
     *
     * @access private
     *
     * @param resource $imap   The IMAP resource stream (not needed).
     * @param string $mailbox  The full ({hostname}mailbox) mailbox name.
     *
     * @return string  A unique string for the current state of the mailbox.
     */
    function _getCacheID($imap, $mailbox)
    {
        $this->getStatus($imap, $mailbox);
        if (!empty($this->_statuscache[$mailbox])) {
            $ob = $this->_statuscache[$mailbox];
            $sortpref = IMP::getSort(substr($mailbox, strpos($mailbox, '}') + 1));
            return implode('|', array($ob->messages, $ob->uidnext, $ob->uidvalidity, $sortpref['by'], $sortpref['dir']));
        } else {
            return $mailbox;
        }
    }

    /**
     * Returns the list of message UIDs in arrival order.
     *
     * @param string $mailbox   The mailbox to query.
     * @param boolean $delhide  Use this value instead of the value from
     *                          IMP::hideDeleteMsgs().
     * @param string $base      The base IMAP search string - defaults to all.
     *
     * @return array  See imap_search().
     */
    function getMailboxArrival($mailbox, $delhide = null, $base = 'ALL')
    {
        $search = array(strtoupper(trim($base)));

        if ($delhide === null) {
            $delhide = IMP::hideDeletedMsgs();
        }

        if ($delhide) {
            $search[] = 'UNDELETED';
        }

        $cache_id = serialize($search);

        if (!isset($this->_arrival[$mailbox][$cache_id])) {
            $imp_imap = &IMP_IMAP::singleton();
            if ($imp_imap->changeMbox($mailbox, IMP_IMAP_AUTO)) {
                $res = @imap_search($imp_imap->stream(), implode(' ', $search), SE_UID);
                if (!isset($this->_arrival[$mailbox])) {
                    $this->_arrival[$mailbox] = array();
                }
            } else {
                $res = array();
            }
            $this->_arrival[$mailbox][$cache_id] = (empty($res)) ? array() : $res;
        }

        return $this->_arrival[$mailbox][$cache_id];
    }

    /**
     * Get the unique mailbox ID for the current mailbox status. Needed
     * because some applications (such as DIMP) may be keeping more than 1
     * copy of IMAP data (i.e. on the browser, on the server).
     *
     * @since IMP 4.2
     *
     * @param string $mailbox  The full ({hostname}mailbox) mailbox name.
     *
     * @return string  A unique string for the current state of the mailbox.
     */
    function getCacheID($mailbox)
    {
        return $this->_getCacheID(null, $mailbox);
    }

}
