<?php

$block_name = _("Mailbox View");

/**
 * Output the message summaries.
 */
function _outputSummaries($msgs)
{
    static $template;

    if (!isset($template)) {
        $template = new IMP_Template();
        $template->setOption('gettext', true);

        // Some browsers have trouble with hidden overflow in table cells
        // but not in divs.
        if ($GLOBALS['browser']->hasQuirk('no_hidden_overflow_tables')) {
            $template->set('overflow_begin', '<div class="ohide">');
            $template->set('overflow_end', '</div>');
        }
    }

    $template->set('messages', $msgs, true);
    echo $template->fetch(IMP_TEMPLATES . '/mailbox/mailbox.html');
}

function showMailboxOverview()
{
    global $imp_mbox;

/* There is a chance that this page is loaded directly via message.php. If so,
 * don't re-include config files, and the following variables will already be
 * set: $actionID, $start. */
$mailbox_url = Horde::applicationUrl('mailbox.php');
$mailbox_imp_url = IMP::generateIMPUrl('mailbox.php', $imp_mbox['mailbox']);
if (!isset($from_message_page)) {
    $actionID = Util::getFormData('actionID');
    $start = Util::getFormData('start');
}

/* Initialize the user's identities. */
require_once 'Horde/Identity.php';
$identity = &Identity::singleton(array('imp', 'imp'));

$do_filter = false;

/* Build the list of messages in the mailbox. */
$imp_mailbox = &IMP_Mailbox::singleton($imp_mbox['mailbox']);
$pageOb = $imp_mailbox->buildMailboxPage(Util::getFormData('page'), $start);
$show_preview = ($GLOBALS['conf']['mailbox']['show_preview'] && $GLOBALS['prefs']->getValue('preview_enabled'));
$mailboxOverview = $imp_mailbox->getMailboxArray(range($pageOb->begin, $pageOb->end), $show_preview);

/* Determine sorting preferences. */
$sortpref = IMP::getSort();

/* Cache this value since we use it a lot on this page. */
$graphicsdir = $GLOBALS['registry']->getImageDir('horde');

$showdelete = array('hide' => false, 'purge' => false);

/* If user wants the mailbox to be refreshed, set time here. */
$refresh_time = $GLOBALS['prefs']->getValue('refresh_time');
$refresh_url = Util::addParameter($mailbox_imp_url, 'page', $pageOb->page);
if (isset($filter_url)) {
    $filter_url = Util::addParameter($filter_url, 'page', $pageOb->page);
}

/* Set the folder for the sort links. */
$sort_url = Util::addParameter($mailbox_imp_url, 'sortdir', ($sortpref['dir']) ? 0 : 1);

/* Determine if we are showing previews. */
$preview_tooltip = ($show_preview) ? $GLOBALS['prefs']->getValue('preview_show_tooltip') : false;
if ($preview_tooltip) {
    Horde::addScriptFile('tooltip.js', 'horde', true);
} else {
    $strip_preview = $GLOBALS['prefs']->getValue('preview_strip_nl');
}

$unread = $imp_mailbox->unseenMessages(true);

/* Get the recent message count. */
$newmsgs = 0;
if ($GLOBALS['prefs']->getValue('nav_popup') || $GLOBALS['prefs']->getValue('nav_audio')) {
    $newmsgs = $imp_mailbox->newMessages(true);
}

$pagetitle = $rawtitle = $title = IMP::getLabel($imp_mbox['mailbox']);
$refresh_title = sprintf(_("_Refresh %s"), $title);
$refresh_ak = Horde::getAccessKey($refresh_title);
$refresh_title = Horde::stripAccessKey($refresh_title);
if (!empty($refresh_ak)) {
    $refresh_title .= sprintf(_(" (Accesskey %s)"), $refresh_ak);
}
if ($unread) {
    $pagetitle = $title .= ' (' . $unread . ')';
}
$pagetitle = $title = htmlspecialchars($title);

Horde::addScriptFile('prototype.js', 'imp', true);
Horde::addScriptFile('effects.js', 'imp', true);
Horde::addScriptFile('redbox.js', 'imp', true);
Horde::addScriptFile('mailbox.js', 'imp', true);

if (!empty($newmsgs)) {
    /* Reopen the mailbox R/W so we ensure the 'recent' flags are cleared
     * from the current mailbox. */
    require_once IMP_BASE . '/lib/IMAP.php';
    $imp_imap = &IMP_IMAP::singleton();
    $imp_imap->changeMbox($imp_mbox['mailbox']);

    /* Newmail audio. */
    if (class_exists('Notification_Listener_audio') &&
        $GLOBALS['prefs']->getValue('nav_audio')) {
        $GLOBALS['notification']->push($GLOBALS['registry']->getImageDir() . '/audio/theetone.wav', 'audio');
    }
    /* Newmail alert. */
    if ($GLOBALS['prefs']->getValue('nav_popup')) {
        $GLOBALS['notification']->push(IMP::getNewMessagePopup($newmsgs), 'javascript');
    }
}

/* Define some variables now so we don't have to keep redefining in
 * the foreach () loop or the templates. */
$lastMbox = '';
$messages = array();
$threadlevel = array();

/* Don't show header row if this is a search mailbox or if no messages
 * in the current mailbox. */
$mh_count = 0;
if ($pageOb->msgcount != 0) {
    $sortImg = ($sortpref['dir']) ? 'za.png' : 'az.png';
    $sortText = ($sortpref['dir']) ? '\/' : '/\\';
    $headers = array(
        SORTARRIVAL => array(
            'stext' => _("Sort by Arrival"),
            'text' => _("#"),
            'width' => '4%'
        ),
        SORTDATE => array(
            'stext' => _("Sort by Date"),
            'text' => _("Dat_e"),
            'width' => '10%'
        ),
        SORTTO => array(
            'stext' => _("Sort by To Address"),
            'text' => _("To"),
            'width' => '20%'
        ),
        SORTFROM => array(
            'stext' => _("Sort by From Address"),
            'text' => _("Fro_m"),
            'width' => '20%'
        ),
        SORTTHREAD => array(
            'stext' => _("Sort by Thread"),
            'text' => _("_Thread"),
            'width' => '52%'
        ),
        SORTSUBJECT => array(
            'stext' => _("Sort by Subject"),
            'text' => _("Sub_ject"),
            'width' => '52%'
        ),
        SORTSIZE => array(
            'stext' => _("Sort by Message Size"),
            'text' => _("Si_ze"),
            'width' => '6%'
        )
    );

    /* If this is the Drafts or Sent-Mail Folder, sort by To instead of
     * From. */
    if (IMP::isSpecialFolder($imp_mbox['mailbox'])) {
        unset($headers[SORTFROM]);
    } else {
        unset($headers[SORTTO]);
    }

    /* Determine which of Subject/Thread to emphasize. */
    $extra = SORTTHREAD;
    $standard = SORTSUBJECT;
    if ($sortpref['by'] == SORTTHREAD) {
        $extra = SORTSUBJECT;
        $standard = SORTTHREAD;
    }
    $headers[$standard]['extra'] = '&nbsp;<span style="font-size:95%">[' . Horde::widget(Util::addParameter($mailbox_imp_url, array('sortby' => $extra, 'actionID' => 'change_sort')), $headers[$extra]['stext'], 'widget" style="font-size:95%; font-weight:normal;', null, 'if (window.event) window.event.cancelBubble = true; else if (event) event.stopPropagation();', $headers[$extra]['text']) . ']</span>';
    unset($headers[$extra]);

    foreach ($headers as $key => $val) {
        $ptr = &$headers[$key];
        $ptr['class'] = ($sortpref['by'] == $key) ? 'selected' : 'item';
        if ($sortpref['by'] == $key) {
            $ptr['change_sort_link'] = Horde::link(Util::addParameter($sort_url, array('sortby' => $key, 'actionID' => 'change_sort')), $val['stext'], null, null, null, $val['stext']) . Horde::img($sortImg, $sortText, '', $graphicsdir) . '</a>';
        } else {
            $ptr['change_sort_link'] = null;
        }
        if ($sortpref['limit']) {
            $ptr['sortlimit_text'] = Horde::stripAccessKey($val['text']);
        } else {
            $ptr['change_sort'] = addslashes(Util::addParameter(($sortpref['by'] == $key) ? $sort_url : $mailbox_imp_url, array('sortby' => $key, 'actionID' => 'change_sort')));
            $ptr['change_sort_widget'] = Horde::widget(Util::addParameter(($sortpref['by'] == $key) ? $sort_url : $mailbox_imp_url, array('sortby' => $key, 'actionID' => 'change_sort')), $val['stext'], 'widget', null, null, $val['text']);
            if (!isset($val['extra'])) {
                $ptr['extra'] = null;
            }
        }
    }

    /* Prepare the message headers template. */
    $mh_template = new IMP_Template();
    $mh_template->setOption('gettext', true);
    $mh_template->set('check_all', Horde::getAccessKeyAndTitle(_("Check _All/None")));
    $mh_template->set('form_tag', true);
    $mh_template->set('mailbox_url', $mailbox_url);
    $mh_template->set('mailbox', htmlspecialchars($imp_mbox['mailbox']));
    $mh_template->set('sessiontag', Util::formInput());
    $mh_template->set('sortlimit', $sortpref['limit']);
    $mh_template->set('headers', $headers);

    $mh_template->set('mh_count', $mh_count++);
    echo $mh_template->fetch(IMP_TEMPLATES . '/mailbox/message_headers.html');
}

/* Cache some repetitively used variables. */
$fromlinkstyle = $GLOBALS['prefs']->getValue('from_link');

require_once IMP_BASE . '/lib/UI/Mailbox.php';
$imp_ui = new IMP_UI_Mailbox($imp_mbox['mailbox'], NLS::getCharset(), $identity);

/* Display message information. */
require_once 'Horde/MIME.php';
require_once 'Horde/Text.php';
$ids = $msgs = array();
$search_template = null;
foreach ($mailboxOverview as $msgIndex => $ob) {
    /* Initialize the header fields. */
    $msg = array(
        'bg' => '',
        'color' => !empty($ob->color) ? htmlspecialchars($ob->color) : '',
        'preview' => '',
        'size' => '?',
        'status' => '',
        'subject' => _("[No Subject]"),
        'uid' => htmlspecialchars($ob->uid . IMP_IDX_SEP . $ob->mailbox),
    );

    /* Since this value will be used for an ID element, it can not contain
     * certain characters.  Replace those unavailable chars with '_', and
     * double existing underscores to ensure we don't have a duplicate ID. */
    $msg['id'] = preg_replace('/[^0-9a-z\-_:\.]/i', '_', str_replace('_', '__', rawurlencode($ob->uid . $ob->mailbox)));

    /* Formats the header date string nicely. */
    $msg['date'] = $imp_ui->getDate((isset($ob->date)) ? $ob->date : null);

    /* Format the from header. */
    $from_res = $imp_ui->getFrom($ob);
    $msg['from'] = $from_res['from'];
    $msg['fullfrom'] = $from_res['fullfrom'];

    if (!empty($ob->subject)) {
        $msg['subject'] = $imp_ui->getSubject($ob->subject);
    }

    if (isset($ob->size)) {
        $msg['size'] = $imp_ui->getSize($ob->size);
    }

    /* Generate the target link. */
    $target = IMP::generateIMPUrl('message.php', $imp_mbox['mailbox'], $ob->uid, $ob->mailbox);

    /* Get all the flag information. */
    $flagbits = 0;
    $xprio = (isset($ob->xpriority)) ? $ob->xpriority : false;

    if ($_SESSION['imp']['base_protocol'] != 'pop3') {
        $bg = array();
        if (!empty($ob->to) && $identity->hasAddress(IMP::bareAddress($ob->to))) {
            $msg['status'] .= Horde::img('mail_personal.png', _("Personal"));
            $flagbits |= IMP_PERSONAL;
        }
        if (!$ob->seen) {
            $flagbits |= IMP_UNSEEN;
            $msg['status'] .= Horde::img('mail_unseen.png', _("Unseen"));
            $bg[] = 'unseen';
        } else {
            $bg[] = 'seen';
        }
        if ($ob->answered) {
            $flagbits |= IMP_ANSWERED;
            $msg['status'] .= Horde::img('mail_answered.png', _("Answered"));
            $bg[] = 'answered';
        }
        if ($ob->draft) {
            $flagbits |= IMP_DRAFT;
            $msg['status'] .= Horde::img('mail_draft.png', _("Draft"));
            $target = IMP::composeLink(array(), array('actionID' => 'draft', 'thismailbox' => $ob->mailbox, 'index' => $ob->uid));
        }
        if ($xprio == 'high') {
            $flagbits |= IMP_FLAGGED;
            $msg['status'] .= Horde::img('mail_priority_high.png', _("High Priority"));
            $bg[] = 'important';
        } elseif ($xprio == 'low') {
            $msg['status'] .= Horde::img('mail_priority_low.png', _("Low Priority"));
            $bg[] = 'unimportant';
        }
        if ($ob->flagged) {
            $flagbits |= IMP_FLAGGED;
            $msg['status'] .= Horde::img('mail_flagged.png', _("Important"));
            $bg[] = 'important';
        }
        if ($ob->deleted) {
            $flagbits |= IMP_DELETED;
            $msg['status'] .= Horde::img('mail_deleted.png', _("Deleted"));
            $bg[] = 'deleted';
        }
        $msg['bg'] = implode(' ', $bg);
    }

    $ids[$msg['id']] = $flagbits;

    if (!empty($ob->attachment)) {
        $msg['status'] .= Horde::img($ob->attachment . '.png', $imp_ui->getAttachmentAlt($ob->attachment));
    }

    /* Show message preview? */
    if ($show_preview && isset($ob->preview)) {
        if (empty($ob->preview)) {
            $ptext = '[[' . _("No Preview Text") . ']]';
        } else {
            if (!empty($strip_preview)) {
                $ptext = str_replace("\r", "\n", $ob->preview);
                $ptext = preg_replace('/\n/', ' ', $ptext);
                $ptext = preg_replace('/(\s)+/', '$1', $ptext);
            } else {
                $ptext = str_replace("\r", '', $ob->preview);
            }

            if (!$preview_tooltip) {
                require_once 'Horde/Text/Filter.php';
                $ptext = Text_Filter::filter($ptext, 'text2html', array('parselevel' => TEXT_HTML_NOHTML, 'charset' => '', 'class' => ''));
            }

            $maxlen = $GLOBALS['prefs']->getValue('preview_maxlen');
            if (String::length($ptext) > $maxlen) {
                $ptext = String::substr($ptext, 0, $maxlen) . ' ...';
            } elseif (empty($ob->preview_cut)) {
                $ptext .= '[[' . _("END") . ']]';
            }
        }
        $msg['preview'] = $ptext;
    }

    /* Set the message number. */
    $msg['number'] = $ob->msgno;

    /* Format the Date: Header. */
    $msg['date'] = htmlspecialchars($msg['date']);

    /* Format message size. */
    $msg['size'] = htmlspecialchars($msg['size']);

    /* Format the From: Header. */
    $msg['from'] = htmlspecialchars($msg['from']);
    switch ($fromlinkstyle) {
    case 0:
        if (!$from_res['error']) {
            $msg['from'] = Horde::link(IMP::composeLink(array(), array('actionID' => 'mailto', 'thismailbox' => $ob->mailbox, 'index' => $ob->uid, 'mailto' => $from_res['to'])), sprintf(_("New Message to %s"), stripslashes($msg['fullfrom']))) . $msg['from'] . '</a>';
        }
        break;

    case 1:
        $from_uri = IMP::generateIMPUrl('message.php', $imp_mbox['mailbox'], $ob->uid, $ob->mailbox);
        $msg['from'] = Horde::link($from_uri, $msg['fullfrom']) . $msg['from'] . '</a>';
        break;
    }

    /* Format the Subject: Header. */
    $msg['subject'] = Text::htmlSpaces($msg['subject']);
    if ($preview_tooltip) {
        $msg['subject'] = substr(Horde::linkTooltip($target, $msg['preview'], '', '', '', $msg['preview']), 0, -1) . ' id="subject' . $msg['id'] . '">' . $msg['subject'] . '</a>';
    } else {
        $msg['subject'] = substr(Horde::link($target, $msg['preview']), 0, -1) . ' id="subject' . $msg['id'] . '">' . $msg['subject'] . '</a>' . (!empty($msg['preview']) ? '<br /><small>' . $msg['preview'] . '</small>' : '');
    }

    /* Set up threading tree now. */
    if ($sortpref['by'] == SORTTHREAD) {
        if (!empty($threadtree[$ob->uid])) {
            $msg['subject'] = $threadtree[$ob->uid] . ' ' . $msg['subject'];
        }
    }

    $msgs[] = $msg;
}

_outputSummaries($msgs);
return count($msgs);
}

/**
 * Creates the folder summary.
 */
function create_folder_summary($folder, $max_msgs, $hide_cols)
{
    $_SESSION['imp']['mailbox'] = $folder;

@define('IMPBLOCK_BASE', dirname(__FILE__));
require_once IMPBLOCK_BASE . '/../../lib/base.php';
require_once IMPBLOCK_BASE . '/../../lib/Mailbox.php';
require_once IMPBLOCK_BASE . '/../../lib/Search.php';
require_once 'Horde/MIME.php';
require_once 'Horde/Identity.php';
require_once 'Horde/Template.php';
require_once 'Horde/Text.php';

    $msg_count = 3;
    $_SESSION['imp']['mailbox'] = $folder;

    ob_start();

    $tmp = $GLOBALS['prefs']->getValue('max_msgs');
    $GLOBALS['prefs']->setValue('max_msgs', $max_msgs);

    showMailboxOverview();

    $GLOBALS['prefs']->setValue('max_msgs', $tmp);

    $html_out = ob_get_clean();
    return array($msg_count, $html_out);
}

/**
 * A Block that displays a small view of a mailbox.
 */
class Horde_Block_Imp_mailbox extends Horde_Block {

    var $_app = 'imp';
    var $_msg_count;
    var $_content;

    function getParams()
    {
        return array('max_msgs' => array('type' => 'text',
                                         'name' => _("Number of messages to display"),
                                         'default' => '3'),
                     'folder' => array(
                                       'type' => 'enum',
                                       'name' => _("Folder"),
                                       'values' => $this->_getFolderArray()),
                     'hidecols' => array(
                                         'type' => 'multienum',
                                         'name' => _("Hide Columns"),
                                         'values' => array('arrival' => 'Arrival',
                                                           "date"=> 'Date',
                                                           "address" => 'Address',
                                                           "subject" => 'Subject',
                                                           "msgsize"=> 'Message Size'
                                                           ))
                     );
    }

    function _title()
    {
        $folder = $this->_params['folder'];

        // Convert $this->_params['hidecols'] to convenient format.
        if (isset($this->_params['hidecols']) && is_array($this->_params['hidecols'])) {
            foreach ($this->_params['hidecols'] as $k) {
                $hide_cols[$k] = true;
            }
        }

        // Always hide first (checkbox) column as there is no form.
        $hide_cols['checkbox'] = true;

        list($this->_msg_count, $this->_content)
            = create_folder_summary($folder, $this->_params['max_msgs'], $hide_cols);

        return Horde::link(Horde::url($GLOBALS['registry']->getInitialPage(), true), $GLOBALS['registry']->get('name')) . htmlspecialchars($GLOBALS['registry']->get('name')) . '</a>';
    }

    function _content()
    {
        return '<table cellspacing="0" width="100%"><tr><td>' . $this->_content . '</td></tr></table>';
    }

    /**
     * Create the list of folders in a format that can be put in a
     * block config dialog.
     */
    function _getFolderArray()
    {
        require_once dirname(dirname(__FILE__)) . '/base.php';
        require_once IMP_BASE . '/lib/Folder.php';
        require_once 'Horde/Text.php';

        $imp_folder = &IMP_Folder::singleton();
        $mailboxes = $imp_folder->flist_IMP(array());

        $folders = array();
        foreach ($mailboxes as $mbox) {
            $folders[htmlspecialchars($mbox['val'])] = $mbox['label']; // Text::htmlSpaces($mbox['label']);
        }

        return $folders;
    }

}
