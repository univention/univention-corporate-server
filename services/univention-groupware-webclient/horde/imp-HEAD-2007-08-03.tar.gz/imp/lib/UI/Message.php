<?php
/**
 * The IMP_UI_Message:: class is designed to provide a place to dump common
 * code shared among IMP's various UI views for the message page.
 *
 * $Horde: imp/lib/UI/Message.php,v 1.6 2007/01/02 12:48:00 jan Exp $
 *
 * Copyright 2006-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 *
 * @author  Michael Slusarz <slusarz@horde.org>
 * @package IMP
 * @since   IMP 4.2
 */
class IMP_UI_Message {

    /**
     */
    function basicHeaders()
    {
        return array(
            'date'      =>  _("Date"),
            'from'      =>  _("From"),
            'to'        =>  _("To"),
            'cc'        =>  _("Cc"),
            'bcc'       =>  _("Bcc"),
            'reply-to'  =>  _("Reply-To"),
            'subject'   =>  _("Subject")
        );
    }

    /**
     */
    function getUserHeaders()
    {
        $user_hdrs = $GLOBALS['prefs']->getValue('mail_hdr');

        /* Split the list of headers by new lines and sort the list of headers
         * to make sure there are no duplicates. */
        if (is_array($user_hdrs)) {
            $user_hdrs = implode("\n", $user_hdrs);
        }
        $user_hdrs = trim($user_hdrs);
        if (empty($user_hdrs)) {
            return $user_hdrs;
        }

        $user_hdrs = str_replace(':', '', $user_hdrs);
        $user_hdrs = preg_split("/[\n\r]+/", $user_hdrs);
        $user_hdrs = array_map('trim', $user_hdrs);
        $user_hdrs = array_unique($user_hdrs);
        natcasesort($user_hdrs);

        return $user_hdrs;
    }

    /**
     */
    function getListInformation($imp_headers)
    {
        $ret = array('exists' => false, 'reply_list' => null);

        if ($imp_headers->listHeadersExist()) {
            $ret['exists'] = true;

            /* See if the List-Post header provides an e-mail address for the
             * list. */
            if ($imp_headers->getValue('list-post')) {
                $ret['reply_list'] = $imp_headers->parseListHeaders('list-post', true);
            }
        }

        return $ret;
    }

}
