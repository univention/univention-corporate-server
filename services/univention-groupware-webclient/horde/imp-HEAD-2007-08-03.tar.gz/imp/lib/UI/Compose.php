<?php
/**
 * The IMP_UI_Compose:: class is designed to provide a place to dump common
 * code shared among IMP's various UI views for the compose page.
 *
 * $Horde: imp/lib/UI/Compose.php,v 1.13 2007/07/18 01:41:38 slusarz Exp $
 *
 * Copyright 2006-2007 The Horde Project (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 *
 * @author  Michael Slusarz <slusarz@horde.org>
 * @package IMP
 * @since   IMP 4.2
 */
class IMP_UI_Compose {

    /**
     */
    function expandAddresses($input, &$imp_compose)
    {
        $result = $imp_compose->expandAddresses($imp_compose->getAddressList($input, null, null, null, true), true);

        if (is_array($result)) {
            $GLOBALS['notification']->push(_("Please resolve ambiguous or invalid addresses."), 'horde.warning');
        } elseif (is_a($result, 'PEAR_Error')) {
            $error = $result;
            $result = array();

            $list = $error->getUserInfo();
            if (is_array($list)) {
                foreach ($list as $entry) {
                    if (is_object($entry)) {
                        $result[] = $entry->getUserInfo();
                    } else {
                        $result[] = $entry;
                    }
                }
            }
            $GLOBALS['notification']->push($error, 'horde.warning');
        }

        return $result;
    }

    /**
     */
    function redirectMessage($to, $imp_compose, $headers, $contents, $encoding)
    {
        $recip = $imp_compose->recipientList(array('to' => $to));
        if (is_a($recip, 'PEAR_Error')) {
            return $recip;
        }
        $recipients = implode(', ', $recip['list']);

        $identity = &Identity::singleton(array('imp', 'imp'));
        $from_addr = $identity->getFromAddress();

        $headers->addResentHeaders($from_addr, $recip['header']['to']);

        /* We need to set the Return-Path header to the current user - see
           RFC 2821 [4.4]. */
        $headers->removeHeader('return-path');
        $headers->addHeader('Return-Path', $from_addr);

        $bodytext = $contents->getBody();
        $status = $imp_compose->sendMessage($recipients, $headers, $bodytext, $encoding);
        $error = is_a($status, 'PEAR_Error');

        /* Store history information. */
        if (!empty($GLOBALS['conf']['maillog']['use_maillog'])) {
            require_once IMP_BASE . '/lib/Maillog.php';
            IMP_Maillog::log('redirect', $headers->getValue('message-id'), $recipients);
        }

        if ($error) {
            Horde::logMessage($status->getMessage(), __FILE__, __LINE__, PEAR_LOG_ERR);
            return $status;
        }

        $entry = sprintf("%s Redirected message sent to %s from %s",
                         $_SERVER['REMOTE_ADDR'], $recipients, $_SESSION['imp']['user']);
        Horde::logMessage($entry, __FILE__, __LINE__, PEAR_LOG_INFO);

        if ($GLOBALS['conf']['sentmail']['driver'] != 'none') {
            require_once IMP_BASE . '/lib/Sentmail.php';
            $sentmail = IMP_Sentmail::factory();
            $sentmail->log('redirect', $headers->getValue('message-id'), $recipients);
        }

        return true;
    }

    /**
     */
    function getForwardData(&$imp_compose, &$imp_contents, $type, $index)
    {
        $fwd_msg = $imp_compose->forwardMessage($imp_contents, ($type == 'forwardbody'));
        if ($type == 'forwardall') {
            $imp_compose->attachIMAPMessage(array($index), $fwd_msg['headers']);
        } elseif ($type == 'forwardattachments') {
            $err = $imp_compose->attachFilesFromMessage($imp_contents, true);
            if (!empty($err)) {
                foreach ($err as $val) {
                    $GLOBALS['notification']->push($val, 'horde.warning');
                }
            }
        }

        return $fwd_msg;
    }

    /**
     */
    function attachAutoCompleter($lib, $fields)
    {
        /* Attach autocompleters to the compose form elements. */
        foreach ($fields as $val) {
            call_user_func_array(array($lib, 'factory'), array('ContactAutoCompleter', array('triggerId' => $val)));
        }
    }

    /**
     */
    function attachSpellChecker($lib, $add_br = false)
    {
        $br = ($add_br) ? '<br />' : '';
        $spell_img = Horde::img('spellcheck.png');
        $args = array(
            'id' => 'SpellCheckerObject',
            'targetId' => 'message',
            'triggerId' => 'spellcheck',
            'states' => array(
                'CheckSpelling' => $spell_img . $br . _("Check Spelling"),
                'Checking' => $spell_img . $br . _("Checking ..."),
                'ResumeEdit' => $spell_img . $br . _("Resume Editing"),
                'Error' => $spell_img . $br . _("Spell Check Failed")
            )
        );
        call_user_func_array(array($lib, 'factory'), array('SpellChecker', $args));
    }

}
