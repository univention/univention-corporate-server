            INTRODUCTION

This is an experimental binary distribution of OpenLDAP for 32-bit
Microsoft Windows systems (e.g., Windows 98, NT, 2000, XP).
I don't have any 64-bit Windows so I was not able to test it there...

*********************************************************************
For changes/bugfixes between different Win32 builds have a look at
   ChangeLog-Win32.txt
*********************************************************************

Here are some additional informations for the usage:

            STARTING FROM COMMANDLINE

Since you've gotten this far, all that's left to do is run the LDAP
server and connect to it with a client.  To run the server, adjust the
file slapd.conf if necessary, then go to a command prompt and do:
  C:\> cd \openldap
  C:\openldap> .\slapd -d 1

It will print a great deal of debugging effluvia on the console, at
which point you should be able to connect to the server with a client
program.  There is almost no Windows-specific documentation for
OpenLDAP right now, alas, so the standard documentation available at
openldap.org is your best bet on getting usage information for now.


            STARTING AS NT-SERVICE

If you like to start slapd as NT service go again to the command prompt
and do:
  C:\> cd \openldap
  C:\openldap> slapd install OpenLDAP-slapd "OpenLDAP Directory Service" auto
  C:\openldap> net start OpenLDAP-slapd

NOTE: the "slapd install" is only needed if you didn't choose the
 "create NT service" option during installation.
NOTE2: if you don't want it to start automatically after every restart
  remove the parameter "auto".
NOTE3: to remove an existing service do the following:
  C:\openldap> net stop OpenLDAP-slapd
  C:\openldap> slapd remove OpenLDAP-slapd


            PARAMETERS IN REGISTRY

The logic for the servers to search its parameters in the registry
has been changed. I (M.Mohr) think the new behaviour is cleaner
than that from previous versions.
If you start it from the COMMANDLINE (e.g. slapd.exe) it searches at
  HKLM\Software\OpenLDAP\<name>\Parameters
then at
  HKLM\Software\OpenLDAP\<name>
then at the obsoleted path (that's where previous versions looked at)
  HKLM\Software\<name>
then at
  HKLM\Software\OpenLDAP\Parameters
<name> is here the name of the executable (e.g. slapd) or the name
  which has been given as commandline parameter "-n"

If you use it as SERVICE it searches first at
  HKLM\System\CurrentControlSet\Services\<name>\Parameters
then at the same places as above.
<name> is here the name of the service or the name which has been
given as commandline parameter during installation of the service.
The default "OpenLDAP-slapd" for slapd.exe and "OpenLDAP-slurpd" for
slurpd.exe

Commandline parameters overwrite registry settings (e.g. "-d level"
  overwrites Registry-Value for "DebugLevel").
This is new behaviour; in previous versions registry settings
had been higher priority than commandline parameters.
I thought this was not very logical so I changed it :-)

I hope the new behaviours does fit everybody's needs.
If not tell me... :-)


            CAVEATS

This is currently hackerware, especially when you're building it from
source, so expect to have to do a little messing around to get it to
work.  Also, there is TLS/SSL support in this build, but there is no
SASL support.  It turns out everything is easier to build with MinGW,
except Cyrus SASL, which expects the Microsoft toolchain.  I'll have
it worked out one way or another soon.


            WHEN WILL FEATURE X BE READY

You're welcome to ask on the usual support channels, but I'll warn you
that I don't know, for most values of X.  If you want something to
happen (e.g., documentation, a certain software feature, etc.) by a
certain time, then the only way to guarantee it is to either do it
yourself or to hire me (or some other capable hacker) as a consultant
to do it for you.


            TROUBLESHOOTING

I have done almost no testing on this release, but people are
currently working with it, so it should get better pretty rapidly.
In the meantime, if you have problems or questions (about this port
in particular, not OpenLDAP in general), please discuss them on the
proper mailing list: see http://lucas.bergmans.us/hacks/openldap/.

-- 
Lucas Bergman <lucas@bergmans.us>
07 April 2004
updated by Matthias Mohr <Matthias@Mohrenclan.de>
21 October 2005

-- vi: set filetype=text ts=2 sts=2 sw=2 noai et ic:
