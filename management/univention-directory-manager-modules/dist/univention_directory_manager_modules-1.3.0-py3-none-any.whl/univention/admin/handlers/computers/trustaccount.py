# SPDX-FileCopyrightText: 2004-2026 Univention GmbH
# SPDX-License-Identifier: AGPL-3.0-only

"""|UDM| module for the trust accounts"""

from __future__ import annotations

from typing import Any

import univention.admin.filter
import univention.admin.handlers
import univention.admin.localization
import univention.admin.mapping
import univention.admin.password
import univention.admin.syntax
import univention.admin.uexceptions
from univention.admin.certificate import PKIIntegration, pki_option, pki_properties, pki_tab, register_pki_mapping
from univention.admin.guardian_roles import register_role_mapping, role_layout, role_properties
from univention.admin.layout import Group, Tab


translation = univention.admin.localization.translation('univention.admin.handlers.computers')
_ = translation.translate

module = 'computers/trustaccount'
operations = ['add', 'edit', 'remove', 'search', 'move']
docleanup = True
childs = False
short_description = _('Computer: Domain trust account')
object_name = _('Domain trust account')
object_name_plural = _('Domain trust accounts')
long_description = ''
# fmt: off
options = {
    'pki': pki_option(),
}
property_descriptions = dict({
    'name': univention.admin.property(
        short_description=_('Name'),
        long_description='',
        syntax=univention.admin.syntax.dnsName_umlauts,
        include_in_default_search=True,
        required=True,
        identifies=True,
    ),
    'description': univention.admin.property(
        short_description=_('Description'),
        long_description='',
        syntax=univention.admin.syntax.string,
        include_in_default_search=True,
    ),
    'password': univention.admin.property(
        short_description=_('Machine Password'),
        long_description='',
        syntax=univention.admin.syntax.passwd,
        required=True,
        dontsearch=True,
    ),
}, **pki_properties())

property_descriptions.update(role_properties())

layout = [
    Tab(_('General'), _('Basic values'), layout=[
        Group(_('Trust account'), layout=[
            ["name", "description"],
            "password",
        ]),
    ]),
    pki_tab(),
]

layout.append(role_layout())

mapping = univention.admin.mapping.mapping()
mapping.register('name', 'cn', None, univention.admin.mapping.ListToString)
mapping.register('description', 'description', None, univention.admin.mapping.ListToString)
register_pki_mapping(mapping)
register_role_mapping(mapping)
# fmt: on


class object(univention.admin.handlers.simpleLdap, PKIIntegration):
    module = module

    def open(self) -> None:
        super().open()
        self.pki_open()

        self.options = ['samba']  # FIXME: TODO
        self.modifypassword = 1
        if self.exists():
            self['password'] = '********'
            self.modifypassword = 0

        self.save()

    def getMachineSid(self, lo: univention.admin.uldap.access, position: univention.admin.uldap.position, uidNum: str, rid: str | None = None) -> str:
        # if rid is given, use it regardless of s4 connector
        if rid:
            searchResult = self.lo.authz_connection.search(filter='objectClass=sambaDomain', attr=['sambaSID'])
            domainsid = searchResult[0][1]['sambaSID'][0]
            sid = domainsid + '-' + rid
            return self.request_lock('sid', sid)
        else:
            # if no rid is given, create a domain sid or local sid if connector is present
            if self.s4connector_present:
                return 'S-1-4-%s' % uidNum
            else:
                num = uidNum
                while True:
                    try:
                        return self.request_lock('sid+user', num)
                    except univention.admin.uexceptions.noLock:
                        num = str(int(num) + 1)

    def _ldap_addlist(self) -> list[tuple[str, Any]]:
        acctFlags = univention.admin.samba.acctFlags(flags={'I': 1})

        al = super()._ldap_addlist()
        ocs = [b'top', b'person', b'sambaSamAccount']

        al.append(('sambaSID', [self.getMachineSid(self.lo, self.position, self.request_lock('uidNumber')).encode('ASCII')]))
        al.append(('sambaAcctFlags', [acctFlags.decode().encode('ASCII')]))
        al.append(('sn', self['name'].encode('UTF-8')))

        al.insert(0, ('objectClass', ocs))

        return al

    def _ldap_pre_modify(self) -> None:
        super()._ldap_pre_modify()
        if self.hasChanged('password'):
            if not self['password']:
                self.modifypassword = 0
            elif not self.info['password']:
                self.modifypassword = 0
            else:
                self.modifypassword = 1

    def _ldap_modlist(self) -> list[tuple[str, Any, Any]]:
        ml = super()._ldap_modlist()

        if self.hasChanged('name') and self['name']:
            requested_uid = '%s$' % self['name']
            try:
                ml.append(('uid', self.oldattr.get('uid', []), [self.request_lock('uid', requested_uid).encode('UTF-8')]))
            except univention.admin.uexceptions.noLock:
                raise univention.admin.uexceptions.uidAlreadyUsed(requested_uid)

        if self.modifypassword:
            password_nt, password_lm = univention.admin.password.ntlm(self['password'])
            ml.append(('sambaNTPassword', self.oldattr.get('sambaNTPassword', [b''])[0], password_nt.encode('ASCII')))
            ml.append(('sambaLMPassword', self.oldattr.get('sambaLMPassword', [b''])[0], password_lm.encode('ASCII')))

        return ml

    def _ldap_pre_remove(self) -> None:
        super()._ldap_pre_remove()
        if self.oldattr.get('uid'):
            self.alloc.append(('uid', self.oldattr['uid'][0].decode('UTF-8')))
        if self.oldattr.get('sambaSID'):
            self.alloc.append(('sid', self.oldattr['sambaSID'][0].decode('ASCII')))


def lookup(co, lo, filter_s, base='', superordinate=None, scope='sub', unique=False, required=False, timeout=-1, sizelimit=0, serverctrls=None, response=None):
    filter = univention.admin.filter.conjunction('&', [
        univention.admin.filter.expression('objectClass', 'sambaSamAccount'),
        univention.admin.filter.expression('sambaAcctFlags', '[I          ]'),
    ])  # fmt: skip

    if filter_s:
        filter_p = univention.admin.filter.parse(filter_s)
        univention.admin.filter.walk(filter_p, univention.admin.mapping.mapRewrite, arg=mapping)
        filter.expressions.append(filter_p)

    res: list[univention.admin.handlers.simpleLdap] = [
        object(co, lo, None, dn, attributes=attrs)
        for dn, attrs in lo.authz_connection.search(str(filter), base, scope, [], unique, required, timeout, sizelimit, serverctrls, response)
    ]
    return res


def identify(dn: str, attr: univention.admin.handlers._Attributes, canonical: bool = False) -> bool:
    return b'sambaSamAccount' in attr.get('objectClass', []) and b'[I          ]' in attr.get('sambaAcctFlags', [])
