define({
	root: {
		popupLabel: 'Show or hide columns'
	},
	es: true
});
