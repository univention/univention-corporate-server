define([
	'./functional/Keyboard'
], function(){});