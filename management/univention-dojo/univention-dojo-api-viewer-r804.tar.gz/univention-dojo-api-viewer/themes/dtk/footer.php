				<div class="innerBox">
					<span class="redundant">&copy;</span> The Dojo Foundation, All Rights Reserved.
				</div>

