<!-- 
Contents of the welcome tab pane; anything you need for SEO purposes (such as entry links, etc.)
should go here.
-->
<h1>Welcome to the Dojo Toolkit API Console</h1>
<p>
The request was for: <strong><?php echo $page; ?></strong> (version: <?php echo $version; ?>)
</p>
