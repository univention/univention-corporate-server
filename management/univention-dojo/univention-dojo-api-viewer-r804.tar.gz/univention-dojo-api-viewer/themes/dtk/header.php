				<div class="innerBox">
					<div class="logo"><a href="http://dojotoolkit.org/"><img alt="Dojo Toolkit" src="<?php echo $basePath; ?>themes/dtk/images/logo.png" /></a></div>
					<div class="navi">
						<ul id="nav">
							<li class="home"><a href="http://dojotoolkit.org/">Home</a></li>
							<li class="download"><a href="http://dojotoolkit.org/download/">Download</a></li>
							<li class="docs"><a href="http://dojotoolkit.org/documentation/">Documentation</a></li>
							<li class="community"><a href="http://dojotoolkit.org/community/">Community</a></li>
							<li class="about"><a href="http://dojotoolkit.org/about/">About</a></li>
							<!--<li class="more"><a href="#">More</a></li>-->
						</ul>
						 <div class="search">
							<div class="input">
								<input type="text" value="search"/>
							</div>
						</div>

					</div>
				</div>

