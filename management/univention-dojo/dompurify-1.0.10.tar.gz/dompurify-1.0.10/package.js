var miniExcludes = {
		"dompurify/README.md": 1,
		"dompurify/package": 1
	},
	isJsRe = /\.js$/;

var profile = {
	resourceTags: {
		miniExclude: function(filename, mid){
			return mid in miniExcludes;
		},

		amd: function(filename, mid){
			return isJsRe.test(filename);
		}
	}
};
