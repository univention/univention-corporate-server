define([
	"dojo/tests/_base/loader",
	"dojo/tests/_base/array",
	"dojo/tests/_base/Color",
	"dojo/tests/_base/lang",
	"dojo/tests/_base/declare",
	"dojo/tests/_base/connect",
	"dojo/tests/_base/Deferred",
	"dojo/tests/_base/json",
	"dojo/tests/_base/object",
	"dojo/has!host-browser?dojo/tests/_base/html",
	"dojo/has!host-browser?dojo/tests/_base/fx",
	"dojo/has!host-browser?dojo/tests/_base/query",
	"dojo/has!host-browser?dojo/tests/_base/xhr",
	"dojo/has!host-browser?dojo/tests/_base/window"], 1);

	// TODO: platform boot tests
	//dojo.platformRequire({
	//	browser: ["tests._base._loader.hostenv_browser"],
	//	rhino: ["tests._base._loader.hostenv_rhino"],
	//	spidermonkey: ["tests._base._loader.hostenv_spidermonkey"]
	//});
