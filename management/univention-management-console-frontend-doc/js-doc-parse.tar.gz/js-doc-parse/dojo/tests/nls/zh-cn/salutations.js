define(
//begin v1.x content
{
 'zh-cn': "汉语",
 hello: "你好"
}
//end v1.x content
);
