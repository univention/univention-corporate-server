define(
//begin v1.x content
{
 'zh-tw': "漢語",
 hello: "你好"
}
//end v1.x content
);
