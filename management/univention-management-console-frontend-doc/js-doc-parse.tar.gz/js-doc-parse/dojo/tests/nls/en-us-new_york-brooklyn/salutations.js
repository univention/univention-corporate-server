define(
//begin v1.x content
{
 hello: "Yo"
}
//end v1.x content
);
