define(
//begin v1.x content
{
 hello: "Aloha"
}
//end v1.x content
);
