define(
//begin v1.x content
{
 hello: "Howdy"
}
//end v1.x content
);
