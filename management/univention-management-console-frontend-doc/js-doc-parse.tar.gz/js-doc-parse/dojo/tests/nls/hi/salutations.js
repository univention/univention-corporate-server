define(
//begin v1.x content
{
 hi: "हिन्दी",
 hello: "नमस्ते"
}
//end v1.x content
);
