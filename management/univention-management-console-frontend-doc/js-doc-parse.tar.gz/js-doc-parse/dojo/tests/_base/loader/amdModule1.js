dojoCdnTestLog.push("defining-dojo.tests._base.loader.amdModule1");
define(["./amdModuleDep1"], function(){
	dojoCdnTestLog.push("factory-dojo.tests._base.loader.amdModule1");
	return {status:"OK"};
});
