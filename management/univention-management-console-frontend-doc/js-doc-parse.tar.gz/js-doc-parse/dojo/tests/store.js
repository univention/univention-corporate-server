define([
	"dojo/tests/store/Memory", 
	"dojo/tests/store/DataStore", 
	"dojo/tests/store/Observable", 
	"dojo/tests/store/Cache",
	"dojo/has!host-browser?dojo/tests/store/JsonRest"], 1);


