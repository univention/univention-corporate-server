define(
//begin v1.x content
{
	"quarters-format-abbr": [
		"Τ1",
		"Τ2",
		"Τ3",
		"Τ4"
	],
	"dateFormat-medium": "d MMM, y G",
	"dateFormatItem-MMMEd": "E, d MMM",
	"dateFormatItem-MEd": "E, d/M",
	"dateFormatItem-yMEd": "EEE, d/M/yyyy",
	"timeFormat-full": "h:mm:ss a zzzz",
	"dateFormatItem-Md": "d/M",
	"months-standAlone-narrow": [
		"Ι",
		"Φ",
		"Μ",
		"Α",
		"Μ",
		"Ι",
		"Ι",
		"Α",
		"Σ",
		"Ο",
		"Ν",
		"Δ"
	],
	"months-standAlone-wide": [
		"Ιανουάριος",
		"Φεβρουάριος",
		"Μάρτιος",
		"Απρίλιος",
		"Μάιος",
		"Ιούνιος",
		"Ιούλιος",
		"Αύγουστος",
		"Σεπτέμβριος",
		"Οκτώβριος",
		"Νοέμβριος",
		"Δεκέμβριος"
	],
	"dateFormatItem-EEEd": "EEE d",
	"days-standAlone-narrow": [
		"Κ",
		"Δ",
		"Τ",
		"Τ",
		"Π",
		"Π",
		"Σ"
	],
	"dayPeriods-format-wide-pm": "μ.μ.",
	"dayPeriods-format-wide-am": "π.μ.",
	"timeFormat-medium": "h:mm:ss a",
	"dateFormat-long": "d MMMM, y G",
	"dateFormat-short": "d/M/yyyy",
	"dateFormatItem-yMMMEd": "EEE, d MMM y",
	"months-format-wide": [
		"Ιανουαρίου",
		"Φεβρουαρίου",
		"Μαρτίου",
		"Απριλίου",
		"Μαΐου",
		"Ιουνίου",
		"Ιουλίου",
		"Αυγούστου",
		"Σεπτεμβρίου",
		"Οκτωβρίου",
		"Νοεμβρίου",
		"Δεκεμβρίου"
	],
	"dateFormatItem-yM": "M/yyyy",
	"timeFormat-short": "h:mm a",
	"months-format-abbr": [
		"Ιαν",
		"Φεβ",
		"Μαρ",
		"Απρ",
		"Μαϊ",
		"Ιουν",
		"Ιουλ",
		"Αυγ",
		"Σεπ",
		"Οκτ",
		"Νοε",
		"Δεκ"
	],
	"timeFormat-long": "h:mm:ss a z",
	"days-format-wide": [
		"Κυριακή",
		"Δευτέρα",
		"Τρίτη",
		"Τετάρτη",
		"Πέμπτη",
		"Παρασκευή",
		"Σάββατο"
	],
	"dateFormatItem-yMMM": "LLL y",
	"quarters-format-wide": [
		"1ο τρίμηνο",
		"2ο τρίμηνο",
		"3ο τρίμηνο",
		"4ο τρίμηνο"
	],
	"dateFormat-full": "EEEE, d MMMM, y G",
	"dateFormatItem-MMMd": "d MMM",
	"days-format-abbr": [
		"Κυρ",
		"Δευ",
		"Τρι",
		"Τετ",
		"Πεμ",
		"Παρ",
		"Σαβ"
	]
}
//end v1.x content
);