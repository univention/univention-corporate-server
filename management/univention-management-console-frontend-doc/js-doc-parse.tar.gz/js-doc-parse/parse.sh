#!/bin/bash
node dojo/dojo.js load=parse $@
