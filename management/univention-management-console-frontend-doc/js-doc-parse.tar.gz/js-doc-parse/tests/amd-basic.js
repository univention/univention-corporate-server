define([], function () {
	return {
		foo: 1
	};
})