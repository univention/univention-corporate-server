var a = function () { return }, b = '', c = 0

a + b
//++c

a + b
+ c

a
(b + c)

for (;;) {
	if (true) break
}