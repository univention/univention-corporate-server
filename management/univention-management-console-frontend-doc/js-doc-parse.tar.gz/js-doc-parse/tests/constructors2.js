var namespace = {
	A: function () {}
};

var a = new namespace.A('foo');