define('amd3', [ 'foo' ], function (foo) {
	return {
		foo: foo
	};
});