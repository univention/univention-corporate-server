define(function () {
	var foo = require('foo');
	return {
		foo: foo
	};
});