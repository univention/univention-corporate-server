define([ 'dojo/_base/kernel', 'dojo/_base/declare' ], function (dojo) {
	return dojo.declare(null, {
		postCreate: function () {}
	});
});