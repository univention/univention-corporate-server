/**
 * Ctor comments.
 */
function Ctor() {

}

Ctor.prototype = {
	constructor: Ctor,

	/**
	 * Foo comment.
	 */
	foo: 'asdf'
};

var a = new Ctor(foo);