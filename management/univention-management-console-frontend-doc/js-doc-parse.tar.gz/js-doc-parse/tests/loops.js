for (var i = 0, j, k; i < j, k; ++i);

for (i, j, k;;);

for (let letI = "let", letJ, letK;;);

for (var l in i);

for (let letL in i);

for (k in i);

while (i--);

do {
	i--;
} while (i);