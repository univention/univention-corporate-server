foo();

var a = "a";

{
	let b;
	b = a;
	let c;
}