/** Array a */
var array = [
	/** item 0 */ 'a',
	12,
	[ /** item 2.0 */ 'hello' ],
	[],
	function () { alert('function in array'); },
	/** item 4, empty with comment */ [],
	[]
];