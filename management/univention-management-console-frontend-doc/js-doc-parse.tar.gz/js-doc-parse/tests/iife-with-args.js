(function (d) {
    d.foo = 'bar';
})(dojo);