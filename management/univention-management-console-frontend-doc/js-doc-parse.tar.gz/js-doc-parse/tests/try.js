try {
	oops;
}
finally {
	oopsAgain;
}

try {
	oops;
}
catch (e) {
	throw e;
}

try {
	oops;
}
catch (e) {
	throw e;
}
finally {
	oopsAgain;
}