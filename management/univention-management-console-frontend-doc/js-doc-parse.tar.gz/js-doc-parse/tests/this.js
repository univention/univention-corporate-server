this.a = function () {
	this.foo = "yep";
};