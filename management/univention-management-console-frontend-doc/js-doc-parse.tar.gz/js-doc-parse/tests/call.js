function foo(a, b, c) {
	return a;
}

foo("pass", "fail", "fail");