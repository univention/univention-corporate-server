function A(lolhi){
	return lolhi;
}

var a = new A();