var foo = { x: "yep" }, bar = "x";

var res = foo[bar];