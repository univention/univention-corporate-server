var isGlobal;
let isGlobalLet;

function a(){
	var isFunctionVar;
	let isFunctionLet;

	{
		var isFunctionVar2;
		let isBlockLet;
	}
}