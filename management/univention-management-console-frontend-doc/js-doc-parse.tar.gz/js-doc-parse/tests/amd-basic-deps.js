define([ 'foo' ], function (foo) {
	return {
		foo: foo
	};
});