<?php
	$defVersion = "1.8";
	$dataDir = dirname(__FILE__) . "/data/";
	$defPage = "";
	$defTheme = "";
	$theme = "dtk";
	$modules = array(
		"dojo"=>-1, 
		"dijit"=>-1, 
		"dojox"=>-1, 
		"djConfig"=>-1
	 );
?>
