/*jshint jquery:true */
/*global foo, bar */

foo();
