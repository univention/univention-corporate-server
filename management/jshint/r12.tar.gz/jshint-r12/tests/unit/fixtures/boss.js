if (e = 1)
    doSomething();

while (obj = arr.next())
    doSomething();

for (var b; b = arr.next();)
    doSomething();

do {
    doSomething();
} while (b = arr.next());