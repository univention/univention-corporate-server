var x = 3;

try {
    throw "boom";
} catch (x) {}

console.log(x);
