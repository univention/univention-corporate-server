var a = "test maxlen";
var b = "test maxlen ";
var c = "test maxlen  ";