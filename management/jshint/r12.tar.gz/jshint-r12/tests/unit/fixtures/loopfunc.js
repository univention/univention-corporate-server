while (true) {
    var x = function () {};
}

for (var i = 0; i < 5; i++) {
    var y = function () {};
}

while (true) {
    function z() {}
}