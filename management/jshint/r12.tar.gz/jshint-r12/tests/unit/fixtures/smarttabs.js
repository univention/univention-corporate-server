/* This file contains mixed tabs and spaces for testing purposes */
function hello() {
	if (true &&
		  1 && "hai") {
  		console.log("hey");
	}
}
	/**
	 * Allowed space after tab before block comment
	 */

// function commentedOut() {
// 	console.log('space followed by tab after a // comment');
// }