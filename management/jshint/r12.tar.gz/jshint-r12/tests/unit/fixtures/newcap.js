var dog = new animal();
var cat = new Animal();

dog = animal();
cat = Animal();

/*global iAnimal*/

var rat = new iAnimal();
var bat = new myAnimal();

rat = iAnimal();
bat = myAnimal();
