// indent
if (true) {
	var x = 1;// tabbed indent
	if (true) {
	    var t = 324; // mixed indent /\t /
    	var s = 324; // mixed indent / \t/
    } // whitespace indent
}