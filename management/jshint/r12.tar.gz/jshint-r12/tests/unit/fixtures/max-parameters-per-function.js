function functionWithNoParameters() {
}

function functionWith3Parameters(param1, param2, param3) {
}
