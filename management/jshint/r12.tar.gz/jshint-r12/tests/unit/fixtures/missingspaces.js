var a = function() {};
var b=function (){};
var d= false;
function h(){
	return 1+ 0;
}
var e = 2+2;
var url = "/"+"uid"+"/likes?access_token="+"token";
