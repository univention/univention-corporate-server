ALTER TABLE turba_shares_groups CHANGE group_uid group_uid VARCHAR(255);
