ALTER TABLE turba_shares MODIFY share_owner VARCHAR2(255);
ALTER TABLE turba_shares_users MODIFY user_uid VARCHAR2(255);
ALTER TABLE turba_shares_groups MODIFY group_uid VARCHAR2(255);
