<?php

$conf['client']['addressbook'] = 'INBOX%2FClients';
$conf['shares']['source'] = 'kolab';
