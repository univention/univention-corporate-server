<?php
/**
 * @category Horde
 * @package Horde_View
 */

/**
 * @category Horde
 * @package Horde_View
 */
class Horde_View_Exception extends Exception {}
