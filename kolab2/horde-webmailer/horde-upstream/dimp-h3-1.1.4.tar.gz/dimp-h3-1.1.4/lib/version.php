<?php define('DIMP_VERSION', 'H3 (1.1.4)') ?>
