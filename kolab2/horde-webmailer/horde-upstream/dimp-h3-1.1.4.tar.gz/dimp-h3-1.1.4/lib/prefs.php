<?php

// Need to load IMP's configuration (it is used in IMP.php for JS/CSS stuff).
$GLOBALS['registry']->importConfig('imp');
