ALTER TABLE turba_shares_users ALTER share_id TYPE integer;       
ALTER TABLE turba_shares_groups ALTER share_id TYPE integer; 
ALTER TABLE turba_shares ALTER share_id TYPE integer;

