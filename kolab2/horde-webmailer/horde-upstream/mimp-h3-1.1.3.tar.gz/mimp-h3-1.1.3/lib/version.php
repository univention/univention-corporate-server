<?php define('MIMP_VERSION', 'H3 (1.1.3)') ?>
