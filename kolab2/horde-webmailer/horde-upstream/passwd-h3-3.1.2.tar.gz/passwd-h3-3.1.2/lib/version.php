<?php define('PASSWD_VERSION', 'H3 (3.1.2)') ?>
