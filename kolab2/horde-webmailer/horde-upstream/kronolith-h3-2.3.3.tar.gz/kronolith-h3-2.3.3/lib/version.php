<?php define('KRONOLITH_VERSION', 'H3 (2.3.3)') ?>
