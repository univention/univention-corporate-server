ALTER TABLE kronolith_shares ALTER share_owner TYPE VARCHAR(255);
ALTER TABLE kronolith_shares_users ALTER user_uid TYPE VARCHAR(255);
ALTER TABLE kronolith_shares_groups ALTER group_uid TYPE VARCHAR(255);
