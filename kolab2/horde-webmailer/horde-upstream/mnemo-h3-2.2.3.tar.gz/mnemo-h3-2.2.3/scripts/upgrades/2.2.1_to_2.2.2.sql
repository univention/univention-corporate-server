ALTER TABLE mnemo_shares_groups CHANGE group_uid group_uid VARCHAR(255);
