ALTER TABLE mnemo_shares_groups MODIFY group_uid VARCHAR2(255);
