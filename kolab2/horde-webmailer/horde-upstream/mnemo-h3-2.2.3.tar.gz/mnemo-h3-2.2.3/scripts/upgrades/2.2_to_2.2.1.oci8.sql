ALTER TABLE mnemo_shares MODIFY share_owner VARCHAR2(255);
ALTER TABLE mnemo_shares_users MODIFY user_uid VARCHAR2(255);
