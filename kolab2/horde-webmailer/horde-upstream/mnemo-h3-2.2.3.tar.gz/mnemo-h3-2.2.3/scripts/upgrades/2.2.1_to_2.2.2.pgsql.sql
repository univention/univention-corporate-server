ALTER TABLE mnemo_shares_groups ALTER group_uid TYPE VARCHAR(255);
