ALTER TABLE mnemo_shares ALTER share_owner TYPE VARCHAR(255);
ALTER TABLE mnemo_shares_users ALTER user_uid TYPE VARCHAR(255);
