<?php define('PASSWD_VERSION', 'H3 (3.0.1)') ?>
