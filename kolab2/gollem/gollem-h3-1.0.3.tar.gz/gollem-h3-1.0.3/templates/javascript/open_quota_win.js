function open_quota_win(args)
{
    var url = "<?php echo Horde::url($GLOBALS['registry']->applicationWebPath('%application%/quota.php', 'gollem')) ?>";
    if (url.indexOf('?') == -1) {
        var glue = '?';
    } else {
        var glue = '&';
    }
    var now = new Date();
    var name = "quota_window_" + now.getTime();
    if (args != "") {
        url = url + glue + args + "&uniq=" + now.getTime();
    } else {
        url = url + glue + "uniq=" + now.getTime();
    }
    var param = "toolbar=no,location=no,status=yes,scrollbars=yes,resizable=no,width=300,height=300,left=0,top=0";
    eval("name = window.open(url, name, param)");
    if (!eval("name.opener")) {
        eval("name.opener = self");
    }
}
