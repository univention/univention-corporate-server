function open_selectlist_win(formid, cacheid)
{
    var url = '<?php echo Util::addParameter(Horde::url($GLOBALS['registry']->get('webroot', 'gollem') . '/selectlist.php', true), 'formid', '', false) ?>' + formid + '&cacheid=' + cacheid;
    var now = new Date();
    var name = "selectlist_window_" + now.getTime();
    var param = "toolbar=no,location=no,status=yes,scrollbars=yes,resizable=no,width=300,height=500,left=0,top=0";
    eval("name = window.open(url, name, param)");
    if (!eval("name.opener")) {
        eval("name.opener = self");
    }
}
