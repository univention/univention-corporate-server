<?php define('GOLLEM_VERSION', 'H3 (1.0.3)') ?>
