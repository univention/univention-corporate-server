#include <xen/xmalloc.h>
#include <linux/gfp.h>
#include <asm/delay.h>
