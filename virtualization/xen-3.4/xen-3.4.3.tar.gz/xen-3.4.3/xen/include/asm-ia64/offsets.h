//dummy file to resolve non-arch-indep include
#ifndef __IA64_OFFSETS_H
#define __IA64_OFFSETS_H

#ifndef GENERATE_ASM_OFFSETS
#include <asm/asm-offsets.h>
#endif

#endif /* __IA64_OFFSETS_H */
