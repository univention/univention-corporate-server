#ifndef __ASM_IA64_HVM_VLAPIC_H__
#define __ASM_IA64_HVM_VLAPIC_H__

int vlapic_match_logical_addr(struct vlapic *vlapic, uint16_t dest);

#endif /* __ASM_IA64_HVM_VLAPIC_H__ */
