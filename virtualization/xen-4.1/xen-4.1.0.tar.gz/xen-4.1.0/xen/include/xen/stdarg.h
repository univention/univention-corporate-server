#if defined(__OpenBSD__)
#  include "/usr/include/stdarg.h"
#else
#  include <stdarg.h>
#endif
