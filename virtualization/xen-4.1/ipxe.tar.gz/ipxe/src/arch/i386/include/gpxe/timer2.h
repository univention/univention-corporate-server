#ifndef _GPXE_TIMER2_H
#define _GPXE_TIMER2_H

/** @file
 *
 * Timer chip control
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

extern void timer2_udelay ( unsigned long usecs );

#endif /* _GPXE_TIMER2_H */
