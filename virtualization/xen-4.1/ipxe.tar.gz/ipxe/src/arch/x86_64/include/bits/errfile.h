#ifndef _BITS_ERRFILE_H
#define _BITS_ERRFILE_H

/**
 * @addtogroup errfile Error file identifiers
 * @{
 */

/** @} */

#endif /* _BITS_ERRFILE_H */
