#include <gpxe/nap.h>

PROVIDE_NAP_INLINE ( null, cpu_nap );
